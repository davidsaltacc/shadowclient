package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_1542;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public abstract class ItemEntityRendererMixin {

    @Unique public class_1542 item;
    @Unique public final Quaternionf flat_rotation = class_7833.field_40714.rotation(1.57079633f);

    @Inject(method = "render(Lnet/minecraft/entity/ItemEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void onRender(class_1542 itemEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        item = itemEntity;
    }

    @Redirect(method = "render(Lnet/minecraft/entity/ItemEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V", ordinal = 0))
    private void onTranslate(class_4587 matrices, float x, float y, float z) {
        if (!ModuleManager.FlatItemsModule.enabled) {
            matrices.method_46416(x, y, z);
        }
    }

    @Redirect(method = "render(Lnet/minecraft/entity/ItemEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V", ordinal = 0))
    private void onRotate(class_4587 matrices, Quaternionf quaternion) {
        if (ModuleManager.FlatItemsModule.enabled) {
            float offset = item.field_7203;
            if (ModuleManager.FlatItemsModule.face()) {
                offset = ModuleManager.FlatItemsModule.getItemAngle(item, SCMain.mc.field_1724);
            }
            matrices.method_22907(flat_rotation);
            matrices.method_22907(class_7833.field_40718.rotation(offset));
        } else {
            matrices.method_22907(quaternion);
        }
    }
}
