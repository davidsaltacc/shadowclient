package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_1041;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(class_1041.class)
public abstract class WindowMixin {
    /** mixin, why
     * @author e
     * @reason e
     */
    @Overwrite
    public void setTitle(String title) {
        GLFW.glfwSetWindowTitle(((class_1041) (Object) this).method_4490(), SCMain.getWindowTitle() + " | " + title);
    }
}