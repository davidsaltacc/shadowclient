package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(targets = {
    "me.jellysquid.mods.sodium.client.render.chunk.compile.pipeline.BlockOcclusionCache", // > 5.0.0
    "me.jellysquid.mods.sodium.client.render.occlusion.BlockOcclusionCache"}, // < 5.0.0
    remap = false)
public abstract class Sodium_BlockOcclusionCacheMixin {
    @SuppressWarnings("UnresolvedMixinReference")
    @Inject(at = @At("HEAD"), method = "shouldDrawSide", cancellable = true, remap = false)
    private void shouldDrawSide(class_2680 state, class_1922 reader, class_2338 pos, class_2350 face, CallbackInfoReturnable<Boolean> cir) {
        ShouldDrawSideEvent event = new ShouldDrawSideEvent(state);

        EventManager.fireEvent(event);

        if (event.renderedSet) {
            cir.setReturnValue(event.rendered);
        }
    }
}