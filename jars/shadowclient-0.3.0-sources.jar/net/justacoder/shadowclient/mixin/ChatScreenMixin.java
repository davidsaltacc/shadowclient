package net.justacoder.shadowclient.mixin;

import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_408.class)
public abstract class ChatScreenMixin {

    @Shadow
    protected class_342 chatField;

}
