package net.justacoder.shadowclient.mixin;

import net.minecraft.class_2960;
import net.minecraft.class_377;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_377.class)
public interface FontStorageAccessor {

    @Accessor("id")
    class_2960 getId();

}
