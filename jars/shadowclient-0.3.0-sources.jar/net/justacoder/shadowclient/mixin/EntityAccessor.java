package net.justacoder.shadowclient.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1297.class)
public interface EntityAccessor {
    @Accessor("onGround")
    void setOnGround(boolean onGround);
}
