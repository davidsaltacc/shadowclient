package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.SetOpaqueCubeEvent;
import net.minecraft.class_2338;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_852.class)
public abstract class ChunkOcclusionDataBuilderMixin {
    @Inject(at = @At("HEAD"), method = "markClosed", cancellable = true)
    private void onMarkClosed(class_2338 pos, CallbackInfo ci) {
        SetOpaqueCubeEvent event = new SetOpaqueCubeEvent();
        EventManager.fireEvent(event);

        if (event.cancelled) {
            ci.cancel();
        }
    }
}
