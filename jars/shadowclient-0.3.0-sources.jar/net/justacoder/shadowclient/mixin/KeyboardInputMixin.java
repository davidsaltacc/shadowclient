package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public abstract class KeyboardInputMixin extends class_744 {

    @Inject(method = "tick", at = @At("TAIL"))
    private void forceForwardMovement(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        if (ModuleManager.AutoMoveModule.enabled) {
            this.field_3905 = slowDown ? slowDownFactor : 1f;
        }
    }

}
