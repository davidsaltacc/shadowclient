package net.justacoder.shadowclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Map;
import net.minecraft.class_304;

@Mixin(class_304.class)
public interface KeyBindingAccessor {
    @SuppressWarnings("SameReturnValue")
    @Accessor("CATEGORY_ORDER_MAP")
    static Map<String, Integer> getCategoryMap() {
        return null;
    }

}
