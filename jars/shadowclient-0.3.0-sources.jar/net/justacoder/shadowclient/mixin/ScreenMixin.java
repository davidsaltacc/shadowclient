package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ui.notifications.NotificationsManager;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public abstract class ScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        NotificationsManager.renderNotifications(context, mouseX, mouseY, delta);
    }

}
