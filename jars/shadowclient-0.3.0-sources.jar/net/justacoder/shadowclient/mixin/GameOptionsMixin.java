package net.justacoder.shadowclient.mixin;

import com.google.common.collect.Lists;
import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_304;
import net.minecraft.class_315;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import java.util.List;

@Mixin(class_315.class)
public abstract class GameOptionsMixin {
    @Mutable
    @Final
    @Shadow
    public class_304[] allKeys;

    @Inject(at = @At("HEAD"), method = "load()V")
    public void onLoad(CallbackInfo info) {
        List<class_304> binds = Lists.newArrayList(allKeys);
        binds.addAll(SCMain.keyBindings);
        allKeys = binds.toArray(new class_304[0]);
    }
}
