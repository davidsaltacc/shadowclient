package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(
    targets = {"me.jellysquid.mods.sodium.client.render.chunk.compile.pipeline.FluidRenderer"},
    remap = false
)
public abstract class Sodium_FluidRendererMixin {

    @SuppressWarnings("UnresolvedMixinReference")
    @Inject(method = "isSideExposed", at = @At("HEAD"), cancellable = true)
    private void modifyIsSideExposed(class_1920 world, int x, int y, int z, class_2350 dir, float height, CallbackInfoReturnable<Boolean> cir) {

        class_2338 pos = new class_2338(x, y, z);
        ShouldDrawSideEvent evt = new ShouldDrawSideEvent(world.method_8320(pos));

        EventManager.fireEvent(evt);

        if (evt.renderedSet) {
            cir.setReturnValue(evt.rendered);
        }
    }

}
