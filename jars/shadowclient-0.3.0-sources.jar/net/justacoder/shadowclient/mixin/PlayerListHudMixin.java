package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_124;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;

@Mixin(class_355.class)
public abstract class PlayerListHudMixin {

    @Redirect(method = "getPlayerName", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/PlayerListHud;applyGameModeFormatting(Lnet/minecraft/client/network/PlayerListEntry;Lnet/minecraft/text/MutableText;)Lnet/minecraft/text/Text;"))
    private class_2561 onApplyGameModeFormatting(class_355 instance, class_640 entry, class_5250 name) {

        if (ModuleManager.BetterPingDisplayModule.enabled) {
            name = class_5250.method_43477(class_2561.method_30163("[" + entry.method_2959() + "ms] " + name.getString()).method_10851());
        }

        return entry.method_2958() == class_1934.field_9219 ? name.method_27692(class_124.field_1056) : name;
    }

}
