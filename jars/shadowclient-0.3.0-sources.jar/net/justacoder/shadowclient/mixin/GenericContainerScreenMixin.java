package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.player.cheststeal.button.CustomButtonWidget;
import net.justacoder.shadowclient.main.util.JavaUtils;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_465;
import net.minecraft.class_476;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_476.class)
public abstract class GenericContainerScreenMixin
    extends class_465<class_1707> {

    @Shadow
    @Final
    private int rows;

    @Override
    protected void method_25426() {
        super.method_25426();

        method_37063(CustomButtonWidget.newButton(field_2776 + field_2792 - 55, field_2800 + 4, 50, 12, "Steal", b -> steal()));
    }

    @Unique
    public void steal() {
        run(() -> clickSlots(0, rows * 9));
    }

    @Unique
    public void run(Runnable r) {
        Thread thread = new Thread(() -> {
            try { r.run(); } catch(Exception e) {
                SCMain.error(JavaUtils.stackTraceFromThrowable(e));
            }
        });
        thread.setName("ChestSteal Thread");
        thread.start();
    }

    @Unique
    private void clickSlots(int from, int to) {
        for(int i = from; i < to; i++) {
            class_1735 slot = field_2797.field_7761.get(i);
            if (slot.method_7677().method_7960()) {
                continue;
            }

            try { Thread.sleep(ModuleManager.ChestStealModule.getDelay()); }
            catch (Exception e) { SCMain.error(JavaUtils.stackTraceFromThrowable(e)); }

            if (field_22787.field_1755 == null) {
                break;
            }

            method_2383(slot, slot.field_7874, 0, class_1713.field_7794);
        }
    }

    public GenericContainerScreenMixin(class_1707 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }
}