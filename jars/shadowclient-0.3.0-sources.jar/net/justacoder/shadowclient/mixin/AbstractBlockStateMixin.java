package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.GetAmbientOcclusionLightLevelEvent;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public abstract class AbstractBlockStateMixin {
    @Inject(at = @At("HEAD"), method = "getAmbientOcclusionLightLevel", cancellable = true)
    private void onGetAmbientOcclusionLightLevel(class_1922 blockView, class_2338 blockPos, CallbackInfoReturnable<Float> cir) {
        GetAmbientOcclusionLightLevelEvent event = new GetAmbientOcclusionLightLevelEvent();

        EventManager.fireEvent(event);

        if (event.set) {
            cir.setReturnValue((float) event.lightLevel);
        }
    }
}
