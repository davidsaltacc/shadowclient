package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_5635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5635.class)
public abstract class PowderSnowBlockMixin {

    @Inject(at = @At("HEAD"), method = "canWalkOnPowderSnow", cancellable = true)
    private static void injected(class_1297 entity, CallbackInfoReturnable<Boolean> cir)
    {
        if (!ModuleManager.PowderSnowWalkModule.enabled) {
            return;
        }

        if (entity != class_310.method_1551().field_1724) {
            return;
        }

        cir.setReturnValue(true);
    }
}
