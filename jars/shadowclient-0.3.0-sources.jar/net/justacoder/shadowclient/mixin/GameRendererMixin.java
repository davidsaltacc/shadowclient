package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.mixininterface.IGameRenderer;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_757.class)
public abstract class GameRendererMixin implements IGameRenderer {

    @Shadow
    void loadPostProcessor(class_2960 id) {
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public void loadShader(@Nullable class_2960 id) {
        if (id != null) {
            loadPostProcessor(id);
        } else {
            ((class_757) (Object) this).method_3207();
        }
    }

    @Inject(at = @At("HEAD"), method = "tiltViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V", cancellable = true)
    private void onTiltViewWhenHurt(class_4587 matrixStack, float f, CallbackInfo ci) {
        if (ModuleManager.NoTiltOnHurtModule.enabled) {
            ci.cancel();
        }
    }

    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F", ordinal = 0), method = "renderWorld(FJLnet/minecraft/client/util/math/MatrixStack;)V")
    private float nauseaLerp(float delta, float start, float end) {
        if (ModuleManager.NoWobbleModule.enabled) {
            return 0;
        }

        return class_3532.method_16439(delta, start, end);
    }

    @Inject(at = @At("HEAD"), method = "getNightVisionStrength(Lnet/minecraft/entity/LivingEntity;F)F", cancellable = true)
    private static void onGetNightVisionStrength(class_1309 entity, float tickDelta, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.NightVisionModule.enabled || ModuleManager.XrayModule.enabled) {
            cir.setReturnValue(1f);
        }
    }

    @Inject(method = "renderHand", at = @At("HEAD"), cancellable = true)
    private void renderHand(class_4587 matrices, class_4184 camera, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.FreecamModule.enabled) {
            ci.cancel();
        }
    }

    @Inject(method = "getFov", at = @At("HEAD"), cancellable = true)
    private void getFov(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        if (ModuleManager.ZoomModule.enabled) {
            cir.setReturnValue(ModuleManager.ZoomModule.FOV.doubleValue());
        }
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void bobView(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.NoBobModule.enabled) {
            ci.cancel();
        }
    }

}
