package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.player.Reach;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Inject(at = @At("HEAD"), method = "getReachDistance", cancellable = true)
    private void onGetReachDistance(CallbackInfoReturnable<Float> ci) {
        Reach reach = ModuleManager.ReachModule;

        if (reach.enabled) {
            ci.setReturnValue(reach.distance());
        }
    }

    @Inject(at = @At("HEAD"), method = "hasExtendedReach", cancellable = true)
    private void hasExtendedReach(CallbackInfoReturnable<Boolean> cir) {
        Reach reach = ModuleManager.ReachModule;

        if (reach.enabled) {
            cir.setReturnValue(true);
        }
    }
}
