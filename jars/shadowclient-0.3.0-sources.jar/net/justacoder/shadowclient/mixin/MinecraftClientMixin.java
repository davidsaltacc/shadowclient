package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ui.CustomFont;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_4011;
import net.minecraft.class_4341;
import net.minecraft.class_542;
import net.minecraft.class_6683;
import net.minecraft.client.ClientBrandRetriever;
import net.justacoder.shadowclient.main.config.SCSettings;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.PostTickEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.other.UnfocusedFPS;
import net.justacoder.shadowclient.main.module.modules.render.EntitiesESP;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {

    @Shadow public abstract boolean isWindowFocused();
    @Shadow @Final public class_315 options;

    /** mixin won't shut. IDK why.
     * @author ...
     * @reason ...
     */
    @Overwrite
    public static class_6683 getModStatus() {
        if (SCSettings.getSetting("VanillaSpoof").booleanValue()) {
            return new class_6683(class_6683.class_6684.field_35174, "Client jar signature and brand is untouched");
        }
        return class_6683.method_39031("vanilla", ClientBrandRetriever::getClientModName, "Client", class_310.class);
    }

    @Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;startMonitor(ZLnet/minecraft/util/TickDurationMonitor;)Lnet/minecraft/util/profiler/Profiler;", shift = At.Shift.AFTER))
    private void injectedPreTick(CallbackInfo ci) {
        if (((class_310) (Object) this).field_1687 != null) {
            EventManager.fireEvent(new PreTickEvent());
        }
    }

    @Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;endMonitor(ZLnet/minecraft/util/TickDurationMonitor;)V"))
    private void injectedPostTick(CallbackInfo ci) {
        if (((class_310) (Object) this).field_1687 != null) {
            EventManager.fireEvent(new PostTickEvent());
        }
    }

    @Inject(method = "hasOutline", at = @At(value = "HEAD"), cancellable = true)
    private void injected(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {

        EntitiesESP entitiesEspModule = ModuleManager.EntitiesESPModule;

        if (!entitiesEspModule.enabled) {
            cir.setReturnValue(cir.getReturnValue());
            return;
        }

        if (entity instanceof class_1657 && entitiesEspModule.DrawPlayerEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1569 && entitiesEspModule.DrawHostileEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1296 && entitiesEspModule.DrawPassiveEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1421 && entitiesEspModule.DrawAmbientEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (!(entity instanceof class_1657) && !(entity instanceof class_1569) && !(entity instanceof class_1296) && !(entity instanceof class_1421) && entitiesEspModule.DrawOtherEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else {
            cir.setReturnValue(cir.getReturnValue());
        }

    }

    @Inject(method = "onInitFinished", at = @At("HEAD"))
    private void onInitFinished(class_4341 realms, class_4011 reload, class_542.class_8495 quickPlay, CallbackInfo ci) {
        ModuleManager.getAllModules().forEach((n, m) -> m.postInit());
    }

    @Inject(method = "getFramerateLimit", at = @At("HEAD"), cancellable = true)
    private void onGetFramerateLimit(CallbackInfoReturnable<Integer> cir) {
        UnfocusedFPS ufps = ModuleManager.UnfocusedFPSModule;
        if (ufps.enabled && !isWindowFocused()) {
            cir.setReturnValue(Math.min(ufps.getFps(), options.method_42524().method_41753()));
        }
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;initFont(Z)V", shift = At.Shift.AFTER))
    private void createTTFRenderer(class_542 args, CallbackInfo ci) {
        CustomFont.initTextRenderer();
    }
}
