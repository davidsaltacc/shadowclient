package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.mixininterface.ISimpleOption;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import java.util.Objects;
import java.util.function.Consumer;

@Mixin(class_7172.class)
public abstract class SimpleOptionMixin<T> implements ISimpleOption<T> {

    @Shadow
    T value;

    @Shadow
    @Final
    private Consumer<T> changeCallback;

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public void forceSet(T newValue) {
        if (!SCMain.mc.method_22108()) {
            value = newValue;
            return;
        }

        if (!Objects.equals(value, newValue)) {
            value = newValue;
            changeCallback.accept(value);
        }
    }
}
