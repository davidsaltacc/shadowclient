package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.minecraft.class_1093;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.List;

@Mixin(class_1093.class)
public abstract class BasicBakedModelMixin {
    @Inject(at = @At("HEAD"), method = "getQuads", cancellable = true)
    private void onGetQuads(@Nullable class_2680 state, @Nullable class_2350 face, class_5819 random, CallbackInfoReturnable<List<class_777>> cir) {
        if (face != null || state == null) {
            return;
        }

        ShouldDrawSideEvent event = new ShouldDrawSideEvent(state);
        EventManager.fireEvent(event);

        if (!event.rendered && event.renderedSet) {
            cir.setReturnValue(List.of());
        }
    }
}
