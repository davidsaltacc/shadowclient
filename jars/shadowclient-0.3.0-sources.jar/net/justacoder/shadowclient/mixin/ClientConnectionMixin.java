package net.justacoder.shadowclient.mixin;

import io.netty.channel.ChannelHandlerContext;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.PacketRecievedEvent;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;


@Mixin(class_2535.class)
public abstract class ClientConnectionMixin {
    @Inject(method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/ClientConnection;handlePacket(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/listener/PacketListener;)V", ordinal = 0), cancellable = true)
    private void onChannelRead0(ChannelHandlerContext channelHandlerContext, class_2596<?> packet, CallbackInfo ci) {
        PacketRecievedEvent event = new PacketRecievedEvent(packet);
        EventManager.fireEvent(event);

        if (event.cancelled) {
            ci.cancel();
        }

    }
}
