package net.justacoder.shadowclient.mixin;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(
    targets = {"me.pepperbell.continuity.client.model.CullingCache"},
    remap = false
)
public abstract class Continuity_CullingCacheMixin {

    @SuppressWarnings("UnresolvedMixinReference")
    @Inject(method = "shouldCull(Lnet/minecraft/world/BlockRenderView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Direction;)Z", at = @At("HEAD"), cancellable = true)
    private void shouldCull(class_1920 blockView, class_2338 pos, class_2680 state, class_2350 cullFace, CallbackInfoReturnable<Boolean> cir) {

        // ShouldDrawSideEvent evt = new ShouldDrawSideEvent(state);

        // EventManager.fireEvent(evt);

        // if (evt.renderedSet) {
        //     cir.setReturnValue(!evt.rendered);
        // }



        // TODO REPRODUCE THAT DAMN ISSUE WITH CONTINUITY HERE
    }

}
