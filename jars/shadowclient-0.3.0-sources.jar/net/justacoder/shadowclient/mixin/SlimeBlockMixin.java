package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_243;
import net.minecraft.class_2490;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_2490.class)
public abstract class SlimeBlockMixin {
    @Redirect(method = "onSteppedOn", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/Vec3d;multiply(DDD)Lnet/minecraft/util/math/Vec3d;"))
    private class_243 onMultiplyVelocity(class_243 velocity, double x, double y, double z) {
        if (ModuleManager.NoSlowdownModule.enabled) {
            return velocity;
        }
        return velocity.method_18805(x, y, z);
    }
}
