package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.mixininterface.IItemEntity;
import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin implements IItemEntity {
    @Mutable
    @Shadow
    @Final
    public float uniqueOffset;

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public void setUniqueOffset(float offset) {
        uniqueOffset = offset;
    }
}
