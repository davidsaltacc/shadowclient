package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_1268;
import net.minecraft.class_1536;
import net.minecraft.class_2940;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1536.class)
public abstract class FishingBobberEntityMixin {

    @Shadow
    private boolean caughtFish;

    @Inject(method = "onTrackedDataSet", at = @At("TAIL"))
    private void injected(class_2940<?> data, CallbackInfo ci) {
        if (caughtFish && ModuleManager.AutoFishModule.enabled) {
            ModuleManager.AutoFishModule.setRecastRodCountdown(20);
            class_310 mc = class_310.method_1551();
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
        }
    }

}
