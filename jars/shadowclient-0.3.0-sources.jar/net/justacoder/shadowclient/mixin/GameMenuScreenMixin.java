package net.justacoder.shadowclient.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {

    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

}
