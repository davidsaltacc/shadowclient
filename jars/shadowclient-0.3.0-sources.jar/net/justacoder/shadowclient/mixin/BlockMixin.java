package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public abstract class BlockMixin {
    @Inject(at = @At("HEAD"), method = "getVelocityMultiplier", cancellable = true)
    private void onGetVelocityMultiplier(CallbackInfoReturnable<Float> cir) {
        if (!ModuleManager.NoSlowdownModule.enabled) {
            return;
        }

        if (cir.getReturnValueF() < 1) {
            cir.setReturnValue(1f);
        }
    }

    @Inject(at = @At("HEAD"), method = "shouldDrawSide", cancellable = true)
    private static void shouldDrawSide(class_2680 state, class_1922 world, class_2338 pos, class_2350 side, class_2338 otherPos, CallbackInfoReturnable<Boolean> cir) {
        ShouldDrawSideEvent event = new ShouldDrawSideEvent(state);

        EventManager.fireEvent(event);

        if (event.renderedSet) {
            cir.setReturnValue(event.rendered);
        }
    }
}
