package net.justacoder.shadowclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_377;
import net.minecraft.class_378;

@Mixin(class_378.class)
public interface FontManagerAccessor {

    @Accessor("fontStorages")
    Map<class_2960, class_377> getFontStorages();

    @Accessor("missingStorage")
    class_377 getMissingStorage();

}
