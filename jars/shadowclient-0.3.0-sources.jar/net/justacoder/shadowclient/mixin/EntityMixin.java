package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.VelocityFromEntityEvent;
import net.justacoder.shadowclient.main.event.events.VelocityFromFluidEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.util.ColorUtils;
import net.justacoder.shadowclient.mixininterface.IEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.concurrent.atomic.AtomicInteger;

@Mixin(class_1297.class)
public abstract class EntityMixin implements IEntity {

    @Final
    @Shadow
    private static AtomicInteger CURRENT_ID;

    @Inject(method = "getTeamColorValue", at = @At("HEAD"), cancellable = true)
    private void injected(CallbackInfoReturnable<Integer> cir) {
        if (ModuleManager.EntitiesESPModule.enabled) {
            int[] colors = ModuleManager.EntitiesESPModule.getColor((class_1297) (Object) this);

            int color = ColorUtils.RGB2int(colors[0], colors[1], colors[2]);

            cir.setReturnValue(color);
        }
    }

    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V", opcode = Opcodes.INVOKEVIRTUAL, ordinal = 0), method = "updateMovementInFluid(Lnet/minecraft/registry/tag/TagKey;D)Z")
    private void setVelocityFromFluid(class_1297 entity, class_243 velocity) {
        VelocityFromFluidEvent event = new VelocityFromFluidEvent((class_1297) (Object) this);
        EventManager.fireEvent(event);

        if (!event.cancelled) {
            entity.method_18799(velocity);
        }
    }

    @Inject(at = @At("HEAD"), method = "pushAwayFrom(Lnet/minecraft/entity/Entity;)V", cancellable = true)
    private void onPushAwayFrom(class_1297 entity, CallbackInfo ci) {

        VelocityFromEntityEvent evt = new VelocityFromEntityEvent((class_1297) (Object) this);

        EventManager.fireEvent(evt);

        if (evt.cancelled) {
            ci.cancel();
        }
    }


    @Inject(at = @At("RETURN"), method = "isInvisibleTo(Lnet/minecraft/entity/player/PlayerEntity;)Z", cancellable = true)
    private void onIsInvisibleTo(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ()) {
            return;
        }

        if (ModuleManager.SeeInvisiblesModule.visible((class_1297) (Object) this)) {
            cir.setReturnValue(false);
        }
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    public AtomicInteger getCurrentId() {
        return CURRENT_ID;
    }
}
