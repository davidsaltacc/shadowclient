package net.justacoder.shadowclient.mixininterface;

import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface IGameRenderer {
    void loadShader(@Nullable class_2960 id);
}
