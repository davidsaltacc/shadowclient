package net.justacoder.shadowclient.mixininterface;

import net.minecraft.class_7172;

public interface ISimpleOption<T> {
    void forceSet(T value);


    @SuppressWarnings("unchecked")
    static <T> ISimpleOption<T> getFromOption(class_7172<T> option) {
        return (ISimpleOption<T>) (Object) option;
    }
}
