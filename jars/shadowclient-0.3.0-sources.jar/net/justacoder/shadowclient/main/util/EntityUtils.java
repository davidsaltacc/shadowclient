package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.mixin.EntityAccessor;
import net.minecraft.class_1297;

public abstract class EntityUtils {

    public static void setOnGround(class_1297 e, boolean onGround) {

        ((EntityAccessor) e).setOnGround(onGround);

    }

}
