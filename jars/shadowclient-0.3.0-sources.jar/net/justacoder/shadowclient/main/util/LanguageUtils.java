package net.justacoder.shadowclient.main.util;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonParseException;
import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_2477;
import net.minecraft.class_2583;
import net.minecraft.class_5223;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import java.io.IOException;
import java.io.InputStream;
import java.util.IllegalFormatException;
import java.util.Optional;
import java.util.function.BiConsumer;

public abstract class LanguageUtils {

    private static class_2477 instance;

    public static class_2477 create() {
        ImmutableMap.Builder<String, String> builder = ImmutableMap.builder();
        BiConsumer<String, String> biConsumer = builder::put;
        LanguageUtils.load(biConsumer, "/assets/shadowclient/lang/en_us.json");
        final ImmutableMap<String, String> map = builder.build();
        return new class_2477(){
            @Override
            public String method_4679(String key, String fallback) {
                return map.getOrDefault(key, fallback);
            }
            @Override
            public boolean method_4678(String key) {
                return map.containsKey(key);
            }
            @Override
            public boolean method_29428() {
                return false;
            }
            @Override
            public class_5481 method_30934(class_5348 text) {
                return visitor -> text.method_27658((style, string) -> class_5223.method_27479(string, style, visitor) ? Optional.empty() : class_5348.field_25309, class_2583.field_24360).isPresent();
            }
        };
    }

    public static void setInstance(class_2477 lang) {
        instance = lang;
    }

    private static void load(BiConsumer<String, String> entryConsumer, String path) {
        try (InputStream inputStream = class_2477.class.getResourceAsStream(path)){
            class_2477.method_29425(inputStream, entryConsumer);
        } catch (JsonParseException | IOException e) {
            SCMain.error("Could not load language file: ");
            SCMain.error(JavaUtils.stackTraceFromThrowable(e));
        }
    }

    public static class_2477 getInstance() {
        return instance;
    }

    public static String translate(String key, Object ... args) {
        String string = instance.method_48307(key);
        try {
            return String.format(string, args);
        } catch (IllegalFormatException illegalFormatException) {
            return "Format error: " + string;
        }
    }

    public static boolean hasTranslation(String key) {
        return instance.method_4678(key);
    }

}
