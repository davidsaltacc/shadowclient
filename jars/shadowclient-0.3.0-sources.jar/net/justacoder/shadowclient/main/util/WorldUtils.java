package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_1297;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;

public abstract class WorldUtils {
    public static boolean lineOfSight(class_243 from, class_243 to) {
        return raycast(from, to).method_17783() == class_239.class_240.field_1333;
    }
    public static boolean lineOfSight(class_1297 from, class_243 to) {
        return lineOfSight(from.method_33571(), to);
    }
    public static boolean lineOfSight(class_243 from, class_1297 to) {
        return lineOfSight(from, to.method_33571());
    }
    public static boolean lineOfSight(class_1297 from, class_1297 to) {
        return lineOfSight(from.method_33571(), to.method_33571());
    }

    public static class_239 raycast(class_243 from, class_243 to) {
        class_3959 context = new class_3959(from, to, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, SCMain.mc.field_1724);
        return SCMain.mc.field_1687.method_17742(context);
    }
}
