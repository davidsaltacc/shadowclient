package net.justacoder.shadowclient.main.ui.notifications;

import net.justacoder.shadowclient.main.ui.CustomFont;
import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class Notification {

    public String title;
    public List<String> desc;

    public class_310 mc;

    public int width = -999;
    public int height = -999;

    public int offX;
    public int offY;

    public Notification(String title, List<String> desc) {
        this.title = title;
        this.desc = desc;
        this.mc = SCMain.mc;
    }
    public Notification(String title, String desc) {
        this.title = title;
        this.desc = List.of(desc);
        this.mc = SCMain.mc;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta, int offsetX, int offsetY) {
        offX = offsetX;
        offY = offsetY;
        boolean hovered = isHovered(mouseX, mouseY, offsetX, offsetY);
        context.method_25294(offsetX, offsetY, offsetX + getWidth(), offsetY + getHeight(), hovered ? Colors.NOTIFICATION_HOVERED.color : Colors.NOTIFICATION_NORMAL.color);
        context.method_25303(CustomFont.renderer, title, offsetX + 5, offsetY + 5, Colors.TEXT_NORMAL.color);
        context.method_25292(offsetX + 5, offsetX + getWidth() - 5, offsetY + 10 + CustomFont.renderer.field_2000, Colors.HORIZONTAL_LINE.color);
        AtomicInteger offset = new AtomicInteger(15 + CustomFont.renderer.field_2000); // java this is annoying
        desc.forEach((line) -> {
            context.method_25303(CustomFont.renderer, line, offsetX + 5, offsetY + offset.get(), Colors.TEXT_NORMAL.color);
            offset.addAndGet(5 + CustomFont.renderer.field_2000);
        });
        context.method_25292(offsetX + 5, offsetX + getWidth() - 5, offsetY + offset.get(), Colors.HORIZONTAL_LINE.color);
        context.method_25303(CustomFont.renderer, "Click to Dismiss.", offsetX + 5, offsetY + offset.get() + 5, Colors.TEXT_DISABLED.color);
    }

    public int getHeight() {
        if (height == -999) {
            height = CustomFont.renderer.field_2000 + 10 +          // title
                (CustomFont.renderer.field_2000 + 5) * (desc.size() // desc
                + 1) + 10;                                          // dismiss text
        }
        return height;
    }
    public int getWidth() {
        if (width == -999) {
            int[] longest = {0};
            desc.forEach((line) -> {
                int w = CustomFont.renderer.method_1727(line);
                if (w > longest[0]) {
                    longest[0] = w;
                }
            });
            width = longest[0] + 10;
        }
        return width;
    }

    public boolean isHovered(int mouseX, int mouseY, int offsetX, int offsetY) {
        return mouseX > offsetX && mouseX < offsetX + getWidth() && mouseY > offsetY && mouseY < offsetY + getHeight();
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isHovered(mouseX, mouseY, offX, offY) && button == 0) {
            NotificationsManager.dismissNotification(this);
        }
    }
}
