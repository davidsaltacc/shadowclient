package net.justacoder.shadowclient.main.ui.clickgui.settings.clickgui.components;

import net.justacoder.shadowclient.main.ui.font.SCFont;
import net.minecraft.class_332;
import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.main.setting.settings.StringSetting;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;
import net.justacoder.shadowclient.main.ui.clickgui.ModuleButton;
import net.justacoder.shadowclient.main.ui.clickgui.settings.clickgui.SettingComponent;
import org.lwjgl.glfw.GLFW;

public class TextSetting extends SettingComponent {

    private final StringSetting stringSetting;
    private final int offset;
    private final String placeholder;

    public boolean captureKeyPresses;

    public TextSetting(Setting setting, ModuleButton parent, int offset) {
        super(setting, parent, offset);
        this.stringSetting = (StringSetting) setting;
        this.offset = offset;
        this.placeholder = setting.name;
        this.captureKeyPresses = false;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX > parent.parent.x && mouseX < parent.parent.x + parent.parent.width && mouseY > parent.parent.y + parent.offset + offset && mouseY < parent.parent.y + offset + parent.offset + parent.parent.height;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (isHovered(mouseX, mouseY)) {
            context.method_25294(parent.parent.x, parent.parent.y + parent.offset + offset, parent.parent.x + parent.parent.width, parent.parent.y + parent.offset + offset + parent.parent.height, Colors.MODULE_BUTTON_HOVERED.color);
        } else {
            context.method_25294(parent.parent.x, parent.parent.y + parent.offset + offset, parent.parent.x + parent.parent.width, parent.parent.y + parent.offset + offset + parent.parent.height, Colors.MODULE_BUTTON_NORMAL.color);
        }
        int textOffset = (int) ((float) parent.parent.height / 2 - SCFont.getHeight() / 2);
        SCFont.renderString(context, stringSetting.stringValue().isEmpty() ? placeholder :  stringSetting.stringValue().toLowerCase(), parent.parent.x + textOffset, parent.parent.y + parent.offset + offset + textOffset, stringSetting.stringValue().isEmpty() ? Colors.TEXT_DISABLED.color : Colors.TEXT_NORMAL.color);
    }

    public void mouseClicked(double mouseX, double mouseY, int button) {
        captureKeyPresses = isHovered(mouseX, mouseY);
    }

    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (captureKeyPresses) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (stringSetting.stringValue().length() > 0) {
                    stringSetting.setStringValue(stringSetting.stringValue().substring(0, stringSetting.stringValue().length() - 1));
                }
                return;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                captureKeyPresses = false;
                return;
            }
            stringSetting.setStringValue(stringSetting.stringValue() + (char) keyCode);
        }
    }
}
