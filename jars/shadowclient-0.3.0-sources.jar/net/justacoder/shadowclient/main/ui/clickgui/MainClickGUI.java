package net.justacoder.shadowclient.main.ui.clickgui;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.config.Config;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.ui.clickgui.settings.clickgui.components.TextSetting;
import net.justacoder.shadowclient.main.ui.clickgui.text.TextField;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainClickGUI extends ClickGUI {

    public final List<Frame> frames;

    public Frame searchFrame;
    public boolean searching;
    public String searchingFor;

    public final class_310 mc = class_310.method_1551();

    public MainClickGUI() {
        super("ClickGUI");

        frames = new ArrayList<>();
        searching = false;
        searchingFor = "";

        int offset = 5;
        for (ModuleCategory category : ModuleCategory.values()) {
            if (category.hiddenFromMain) {
                continue;
            }
            frames.add(Frame.create(category, offset, 5, 100, 13));
            offset += 105;
        }

        searchFrame = Frame.createWithoutAddingModules(ModuleCategory.SEARCH, offset, 5, 100, 12);
        frames.add(searchFrame);
        searchFrame.children.add(new TextField(searchFrame, 12, "textfield.placeholder.find_module"));
    }

    public void repositionFramesProperly() {

        if (!Config.resetUi) {
            return;
        }

        int screenWidth = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor()).width() / (mc.field_1690.method_42474().method_41753() == 0 ? 2 : mc.field_1690.method_42474().method_41753());
        int columns = (int) Math.floor((float) (screenWidth / 2.) / 105);

        int[] columnsY = new int[columns];
        Arrays.fill(columnsY, 5);

        for (int index = 0; index < frames.size(); index++) {
            int xCol = index % columns;
            Frame frame = frames.get(index);
            if (columnsY[xCol] == 5) {
                frame.y = columnsY[xCol];
                columnsY[xCol] += frame.getHeight() + 5;
                frame.x = 5 + xCol * 105;
            } else {
                int minY = (int) 1e7;
                int minYIndex = -1;
                for (int ind = 0; ind < columns; ind++) {
                    int newY = columnsY[ind] + frame.getHeight();
                    if (newY < minY) {
                        minY = newY;
                        minYIndex = ind;
                    }
                }
                frame.y = columnsY[minYIndex];
                columnsY[minYIndex] += frame.getHeight() + 5;
                frame.x = 5 + minYIndex * 105;
            }
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {

        for (Frame frame : frames) {
            frame.render(context, mouseX, mouseY, delta);
            frame.updatePosition(mouseX, mouseY);
        }
        for (Frame frame : frames) {
            frame.renderDescriptions(context, mouseX, mouseY, delta);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {

        for (Frame frame : frames) {
            frame.mouseClicked(mouseX, mouseY, button);
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {

        for (Frame frame : frames) {
            frame.mouseReleased(mouseX, mouseY, button);
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25422() {
        if (ModuleManager.isConfiguringKeyBinds()) {
            return false;
        }
        return super.method_25422();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {

        if (ModuleManager.isConfiguringKeyBinds()) {
            if (SCMain.ToggleGUIKeyBinding.method_1417(keyCode, scanCode)) {
                ModuleManager.endKeybindConfiguration();
                ModuleManager.ConfigureKeybindingsModule.setDisabled();
                SCMain.mc.method_1507(null);
                return true;
            }
            if (ModuleManager.getConfiguringKeyBinding() != null) {
                int code = keyCode == GLFW.GLFW_KEY_ESCAPE ? GLFW.GLFW_KEY_UNKNOWN : keyCode;
                ModuleManager.getConfiguringKeyBinding().method_1422(class_3675.class_307.field_1668.method_1447(code));
                ModuleManager.getConfiguringKeyBindingModule().reloadKeybindTranslation();
                class_304.method_1426();
                ModuleManager.setConfiguringKeyBinding(null, null);
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        searching = !((TextField) searchFrame.children.get(0)).getText().isEmpty();

        if (searching) {
            searchingFor = ((TextField) searchFrame.children.get(0)).getText();
        }

        for (Frame frame : frames) {
            frame.keyPressed(keyCode, scanCode, modifiers);
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public List<FrameChild> getAllTextFields() {
        List<FrameChild> textFields = new ArrayList<>();
        for (Frame frame : frames) {
            textFields.addAll(frame.getAllTextFields());
        }
        return textFields;
    }

    public boolean isAnyTextFieldCapturing() {
        List<FrameChild> allTextFields = getAllTextFields();
        for (FrameChild textField : allTextFields) {
            if (textField.getClass() == TextField.class) {
                if (((TextField) textField).captureKeyPresses) {
                    return true;
                }
            }
            if (textField.getClass() == TextSetting.class) {
                if (((TextSetting) textField).captureKeyPresses) {
                    return true;
                }
            }
        }
        return false;
    }
}
