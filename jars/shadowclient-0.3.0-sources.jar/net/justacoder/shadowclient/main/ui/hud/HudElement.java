package net.justacoder.shadowclient.main.ui.hud;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class HudElement {
    public boolean shouldBeRendered;
    private String textContent;
    private final class_310 mc = SCMain.mc;

    public HudElement(boolean rendered, String text) {
        this.shouldBeRendered = rendered;
        this.textContent = text;
    }

    public void shouldBeRendered(boolean rendered) {
        this.shouldBeRendered = rendered;
    }
    public void setTextContent(String text) {
        this.textContent = text;
    }

    public void render(class_332 context, float tickDelta, int offset) {
        context.method_25294(2, 2 + offset, 3 + mc.field_1772.method_1727(this.textContent), 2 + offset + getHeight(), Colors.HUD_ELEMENT_BACKGROUND.color);
        context.method_51433(mc.field_1772, this.textContent, 3, 3 + offset, Colors.HUD_ELEMENT_TEXT.color, false);
    }

    public void render(class_332 context, float tickDelta, int offset, boolean rightSide) {
        if (!rightSide) {
            render(context, tickDelta, offset);
            return;
        }
        int width = context.method_51421();
        context.method_25294(width - 3 - mc.field_1772.method_1727(this.textContent), 2 + offset, width - 2, 2 + offset + getHeight(), Colors.HUD_ELEMENT_BACKGROUND.color);
        context.method_51433(mc.field_1772, this.textContent, width - mc.field_1772.method_1727(this.textContent) - 2, 3 + offset, Colors.HUD_ELEMENT_TEXT.color, false);
    }

    public int getHeight() {
        return mc.field_1772.field_2000;
    }
}
