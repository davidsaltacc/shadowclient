package net.justacoder.shadowclient.main.ui;

import net.justacoder.shadowclient.mixin.FontManagerAccessor;
import net.justacoder.shadowclient.mixin.MinecraftClientAccessor;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3545;
import net.minecraft.class_377;
import net.minecraft.client.font.*;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class CustomFont {

    private static final class_310 mc = class_310.method_1551();
    public static class_327 renderer = null;

    public static class_3545<class_327, Boolean> getTextRenderer() {
        FontManagerAccessor fma = ((FontManagerAccessor) ((MinecraftClientAccessor) mc).getFontManager());
        AtomicBoolean d = new AtomicBoolean(false);
        class_327 tr = new class_327(id -> {
            class_377 storage = fma.getFontStorages().getOrDefault(new class_2960("arial"), fma.getFontStorages().getOrDefault(new class_2960("default"), fma.getMissingStorage()));
            if (storage == fma.getFontStorages().get(new class_2960("default"))) {
                d.set(true);
            }
            return storage;
        }, true);
        return new class_3545<>(tr, d.get());
    }

    public static void initTextRenderer() {
        renderer = mc.field_1772;
        //Pair<TextRenderer, Boolean> textRendererAndDefault = getTextRenderer();
        //renderer = textRendererAndDefault.getLeft();
        //if (textRendererAndDefault.getRight()) {
        //    SCMain.error("Error initializing TTF renderer, defaulting to minecraft font");
        //}
    }
}
