package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2586;

public class RenderBlockEntityEvent extends Event {
    public class_2586 blockEntity;

    public RenderBlockEntityEvent(class_2586 be) {
        blockEntity = be;
    }
}
