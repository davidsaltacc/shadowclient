package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_4587;

public class Render3DEvent extends Event {
    public final class_4587 matrices;
    public final float tickDelta;
    public Render3DEvent(class_4587 matrices, float tickDelta) {
        this.matrices = matrices;
        this.tickDelta = tickDelta;
    }
}
