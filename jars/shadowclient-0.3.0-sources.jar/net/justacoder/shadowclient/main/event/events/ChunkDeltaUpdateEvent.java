package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import java.util.Map;

public class ChunkDeltaUpdateEvent extends Event {
    public final Map<class_2338, class_2680> delta;

    public ChunkDeltaUpdateEvent(Map<class_2338, class_2680> delta) {
        this.delta = delta;
    }
}
