package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_1282;

public class DamageEvent extends Event {
    public class_1282 source;
    public float amount;

    public DamageEvent(class_1282 src, float amt) {
        this.source = src;
        this.amount = amt;
    }
}
