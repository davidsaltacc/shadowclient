package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2596;

public class PacketRecievedEvent extends Event {
    public final class_2596<?> packet;
    public PacketRecievedEvent(class_2596<?> packet) {
        this.packet = packet;
    }
}
