package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2596;

public class PacketSentEvent extends Event {
    public final class_2596<?> packet;
    public PacketSentEvent(class_2596<?> packet) {
        this.packet = packet;
    }
}
