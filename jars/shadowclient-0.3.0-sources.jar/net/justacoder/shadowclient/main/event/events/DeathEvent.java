package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

public class DeathEvent extends Event {
    public @Nullable class_243 pos;

    public DeathEvent(@Nullable class_243 pos) {
        this.pos = pos;
    }
}
