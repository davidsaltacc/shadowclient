package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_1297;

public class VelocityFromFluidEvent extends Event {
    public final class_1297 entity;
    public VelocityFromFluidEvent(class_1297 entity) {
        this.entity = entity;
    }
}