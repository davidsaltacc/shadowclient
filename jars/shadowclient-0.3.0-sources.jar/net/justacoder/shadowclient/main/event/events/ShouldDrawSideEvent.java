package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2680;

public class ShouldDrawSideEvent extends Event {
    public boolean renderedSet = false;
    public boolean rendered;

    public class_2680 state;

    public ShouldDrawSideEvent(class_2680 s) {
        state = s;
    }

    public void setRendered(boolean r) {
        rendered = r;
        renderedSet = true;
    }

    public void unsetRendered() {
        renderedSet = false;
    }
}
