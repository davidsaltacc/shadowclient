package net.justacoder.shadowclient.main.module.modules.other;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.Hidden;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PacketRecievedEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_2828;
import java.util.ArrayList;
import java.util.List;

@Hidden
@SearchTags({"blink"})
@EventListener({PacketRecievedEvent.class})
public class Blink extends Module { // TODO fix
    public Blink() {
        super("blink", ModuleCategory.OTHER);
    }

    public List<class_2828> packets = new ArrayList<>();

    @Override
    public void onEvent(Event event) {
        if (!(event instanceof PacketRecievedEvent)) {
            return;
        }
        if (!(((PacketRecievedEvent) event).packet instanceof class_2828)) {
            return;
        }

        if (packets.size() > 50) {
            packets.forEach(packet -> mc.field_1724.field_3944.method_2883(packet));
            packets.clear();
            return;
        }

        packets.add((class_2828) ((PacketRecievedEvent) event).packet);
        event.cancel();
    }
}
