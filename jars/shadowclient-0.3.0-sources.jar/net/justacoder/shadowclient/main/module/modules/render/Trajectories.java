package net.justacoder.shadowclient.main.module.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1811;
import net.minecraft.class_1823;
import net.minecraft.class_1835;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4537;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.client.render.*;
import net.minecraft.item.*;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.Render3DEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.util.PlayerUtils;
import net.justacoder.shadowclient.main.util.RenderUtils;
import net.justacoder.shadowclient.main.util.WorldUtils;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import java.util.ArrayList;
import java.util.function.Predicate;

@EventListener({Render3DEvent.class})
@SearchTags({"trajectories", "bow aim laser", "aim assist"})
public class Trajectories extends Module {
    public Trajectories() {
        super("trajectories", ModuleCategory.RENDER);
    }

    public ArrayList<class_243> trajPath;
    public class_239.class_240 trajHit;

    public final class_238 endBox = new class_238(0, 0, 0, 1, 1, 1);

    @Override
    public void onEvent(Event event) {
        Render3DEvent evt = (Render3DEvent) event;

        evt.matrices.method_22903();

        getTrajectory(evt.tickDelta);

        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(false);

        drawLine(evt.matrices, trajPath);
        
        if (!trajPath.isEmpty()) {
            drawEnd(evt.matrices, trajPath.get(trajPath.size() - 1));
        }

        RenderSystem.setShaderColor(1, 1, 1, 1);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDepthMask(true);
        evt.matrices.method_22909();

    }

    public void getTrajectory(float delta) {

        trajHit = class_239.class_240.field_1333;
        trajPath = new ArrayList<>();

        class_1792 item = mc.field_1724.method_6047().method_7909(); // todo offhand too

        if (!(item instanceof class_1811 || item instanceof class_1823 || item instanceof class_1771 || item instanceof class_1776 || item instanceof class_4537 || item instanceof class_1787 || item instanceof class_1835)) {
            return;
        }

        double power;

        if (!(item instanceof class_1811)) {
            power = 1.5;
        } else {
            power = (72000 - mc.field_1724.method_6014()) / 20F;
            power = power * power + power * 2F;

            if (power > 3 || power <= 0.3F) {
                power = 3;
            }
        }

        double gravity;

        if (item instanceof class_1811) {
            gravity = 0.05;
        } else if (item instanceof class_4537) {
            gravity = 0.4;
        } else if (item instanceof class_1787) {
            gravity = 0.15;
        } else if (item instanceof class_1835) {
            gravity = 0.015;
        } else {
            gravity = 0.03;
        }

        double yaw = Math.toRadians(mc.field_1724.method_36454());
        double pitch = Math.toRadians(mc.field_1724.method_36455());

        class_243 arrowPos = new class_243(class_3532.method_16436(delta, mc.field_1724.field_6038, mc.field_1724.method_23317()),
            class_3532.method_16436(delta, mc.field_1724.field_5971, mc.field_1724.method_23318()),
            class_3532.method_16436(delta, mc.field_1724.field_5989, mc.field_1724.method_23321())).method_1019(PlayerUtils.getHandOffset(class_1268.field_5808, yaw));

        double cospitch = Math.cos(pitch);
        class_243 arrowMotion = new class_243(-Math.sin(yaw) * cospitch, -Math.sin(pitch), Math.cos(yaw) * cospitch).method_1029().method_1021(power);

        for (int i = 0; i < 1000; i++) {
            trajPath.add(arrowPos);

            arrowPos = arrowPos.method_1019(arrowMotion.method_1021(0.1));

            arrowMotion = arrowMotion.method_1021(0.999);

            arrowMotion = arrowMotion.method_1031(0, -gravity * 0.1, 0);

            class_243 lastPos = trajPath.size() > 1 ? trajPath.get(trajPath.size() - 2) : mc.field_1724.method_33571();

            class_239 result = item instanceof class_1787 ? WorldUtils.raycastFluidsSolid(lastPos, arrowPos) : WorldUtils.raycast(lastPos, arrowPos);

            if (result.method_17783() != class_239.class_240.field_1333) {
                trajHit = class_239.class_240.field_1332;
                trajPath.set(trajPath.size() - 1, result.method_17784());
                break;
            }

            class_238 box = new class_238(lastPos, arrowPos);
            Predicate<class_1297> predicate = e -> !e.method_7325() && e.method_5863();
            double maxD = 4096;
            class_3966 result1 = class_1675.method_18075(mc.field_1724, lastPos, arrowPos, box, predicate, maxD);

            if (result1 != null && result1.method_17783() != class_239.class_240.field_1333) {
                trajHit = class_239.class_240.field_1331;
                trajPath.set(trajPath.size() - 1, result1.method_17784());
                break;
            }
        }
        
    }

    public void drawLine(class_4587 matrices, ArrayList<class_243> path) {
        class_243 camPos = mc.method_31975().field_4344.method_19326();
        Matrix4f matrix = matrices.method_23760().method_23761();
        class_289 tessellator = RenderSystem.renderThreadTesselator();
        class_287 bufferBuilder = tessellator.method_1349();
        RenderSystem.setShader(class_757::method_34539);

        bufferBuilder.method_1328(class_293.class_5596.field_29345, class_290.field_1592);

        if (trajHit == class_239.class_240.field_1333) {
            RenderSystem.setShaderColor(1f, 1f, 1f, 0.5f);
        } else if (trajHit == class_239.class_240.field_1331) {
            RenderSystem.setShaderColor(1f, 0.1f, 0.1f, 0.5f);
        } else if (trajHit == class_239.class_240.field_1332) {
            RenderSystem.setShaderColor(0.1f, 0.3f, 1f, 0.5f);
        }

        path.forEach(point -> bufferBuilder.method_22918(matrix, (float) (point.field_1352 - camPos.field_1352), (float) (point.field_1351 - camPos.field_1351), (float) (point.field_1350 - camPos.field_1350)).method_1344());

        tessellator.method_1350();

    }

    public void drawEnd(class_4587 matrices, class_243 pos) {
        class_243 camPos = mc.method_31975().field_4344.method_19326();
        double renderX = pos.field_1352 - camPos.field_1352;
        double renderY = pos.field_1351 - camPos.field_1351;
        double renderZ = pos.field_1350 - camPos.field_1350;

        matrices.method_22903();
        matrices.method_22904(renderX - 0.5, renderY - 0.5, renderZ - 0.5);

        if (trajHit == class_239.class_240.field_1333) {
            RenderSystem.setShaderColor(1f, 1f, 1f, 0.5f);
        } else if (trajHit == class_239.class_240.field_1331) {
            RenderSystem.setShaderColor(1f, 0.1f, 0.1f, 0.5f);
        } else if (trajHit == class_239.class_240.field_1332) {
            RenderSystem.setShaderColor(0.1f, 0.3f, 1f, 0.5f);
        }

        RenderUtils.drawOutlinedBox(endBox, matrices);

        matrices.method_22909();

    }

}
