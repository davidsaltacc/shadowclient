package net.justacoder.shadowclient.main.module.modules.world;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.DeathEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.util.ChatUtils;
import net.minecraft.class_243;
import org.jetbrains.annotations.Nullable;

@EventListener({DeathEvent.class})
@SearchTags({"death coords", "death notification", "death coordinates"})
public class DeathNotification extends Module {
    public DeathNotification() {
        super("deathnotification", "Death Notification", "Tells you the coordinates of your death.", ModuleCategory.WORLD);
    }

    @Override
    public void onEvent(Event event) {
        @Nullable class_243 pos = ((DeathEvent) event).pos;
        if (pos == null) {
            ChatUtils.sendMessageClient("You died. Death Location could not be resolved.");
            return;
        }
        ChatUtils.sendMessageClient("You died at " + (int) pos.field_1352 + ", " + (int) pos.field_1351 + ", " + (int) pos.field_1350 + ".");
    }
}
