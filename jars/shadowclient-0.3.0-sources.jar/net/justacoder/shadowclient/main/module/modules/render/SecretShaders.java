package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import net.justacoder.shadowclient.main.util.RenderUtils;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

@EventListener({PreTickEvent.class})
@SearchTags({"shaders", "effects", "vfx", "special effects"})
public class SecretShaders extends Module {

    private Shaders currentShader;
    private class_437 currentScreen;

    public final EnumSetting<Shaders> SHADER = new EnumSetting<>("ID", Shaders.NONE);

    public SecretShaders() {
        super("secretshaders", ModuleCategory.FUN);

        addSetting(SHADER);
    }

    @Override
    public void onEnable() {
        currentShader = Shaders.NONE;
        currentScreen = mc.field_1755;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.field_1773 != null) {
            RenderUtils.loadShader(null);
        }
        super.onDisable();
    }

    @Override
    public void onEvent(Event event) {
        boolean newScreen = false;

        if (currentScreen != mc.field_1755) {
            currentScreen = mc.field_1755;
            newScreen = true;
        }
        if (currentShader != SHADER.getEnumValue() || newScreen) {
            RenderUtils.loadShader(SHADER.getEnumValue().getId());
            currentShader = SHADER.getEnumValue();
        }
    }

    public enum Shaders { // I wonder why they wasted so much time just to make unused shaders...
        NONE("NONE", null), // wow, they made a lot of shaders
        NOTCH("Notch", new class_2960("shaders/post/notch.json")),
        FXAA("FXAA", new class_2960("shaders/post/fxaa.json")),
        ART("Art", new class_2960("shaders/post/art.json")),
        BUMPY("Bumpy", new class_2960("shaders/post/bumpy.json")),
        BLOBS2("Blobs 2", new class_2960("shaders/post/blobs2.json")),
        PENCIL("Pencil", new class_2960("shaders/post/pencil.json")),
        COLOR_CONVOLVE("ColorConvolve", new class_2960("shaders/post/color_convolve.json")),
        DECONVERGE("Deconverge", new class_2960("shaders/post/deconverge.json")),
        FLIP("Flip", new class_2960("shaders/post/flip.json")),
        INVERT("Invert", new class_2960("shaders/post/invert.json")),
        NTSC("NTSC", new class_2960("shaders/post/ntsc.json")),
        OUTLINE("Outline", new class_2960("shaders/post/outline.json")),
        PHOSPHOR("Phosphor", new class_2960("shaders/post/phosphor.json")),
        SCAN_PINCUSHION("Scan Pincushion", new class_2960("shaders/post/scan_pincushion.json")),
        SOBEL("Sobel", new class_2960("shaders/post/sobel.json")),
        BITS("Bits", new class_2960("shaders/post/bits.json")),
        DESATURATE("Desaturate", new class_2960("shaders/post/desaturate.json")),
        GREEN("Green", new class_2960("shaders/post/green.json")),
        BLUR("Blur", new class_2960("shaders/post/blur.json")),
        WOBBLE("Wobble", new class_2960("shaders/post/wobble.json")),
        BLOBS("Blobs", new class_2960("shaders/post/blobs.json")),
        ANTIALIAS("AntiAlias", new class_2960("shaders/post/antialias.json")),
        CREEPER("Creeper", new class_2960("shaders/post/creeper.json")),
        SPIDER("Spider", new class_2960("shaders/post/spider.json"));

        final String name;
        final @Nullable class_2960 id;

        Shaders(String name, @Nullable class_2960 id) {
            this.name = name;
            this.id = id;
        }

        @Override
        public String toString() {
            return this.name;
        }
        public @Nullable class_2960 getId() {
            return this.id;
        }
    }
}
