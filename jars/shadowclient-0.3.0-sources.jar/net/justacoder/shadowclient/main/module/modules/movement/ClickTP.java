package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

@EventListener({PreTickEvent.class})
@SearchTags({"clicktp", "click teleport"})
public class ClickTP extends Module {

    public NumberSetting MAX_DISTANCE = new NumberSetting("Max Distance: ", 1, 100, 10, 2);

    public ClickTP() {
        super("clicktp", "ClickTP", "Teleports you to wherever you click (sprint key + use key).", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEvent(Event event) {
        if (mc.field_1724.method_6115()) {
            return;
        }
        if (mc.field_1724.method_6030() != class_1799.field_8037) {
            return;
        }

        if (mc.field_1690.field_1867.method_1434() && mc.field_1690.field_1904.method_1434()) {
            class_3965 result = (class_3965) mc.field_1724.method_5745(MAX_DISTANCE.floatValue(), 1f / 20f, false);

            class_2338 pos = result.method_17777();
            class_2350 dir = result.method_17780();

            mc.field_1724.method_33574(new class_243(pos.method_10263() + 0.5f + dir.method_10148(), pos.method_10264() + 1f, pos.method_10260() + 0.5f + dir.method_10165()));
        }
    }
}
