package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.Render3DEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.util.RenderUtils;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_243;

@EventListener({Render3DEvent.class})
@SearchTags({"tracers", "lines", "entity tracers"})
public class Tracers extends Module {

    public final BooleanSetting DrawPlayerEntityTracers = new BooleanSetting("Players", true);
    public final BooleanSetting DrawHostileEntityTracers = new BooleanSetting("Hostiles", true);
    public final BooleanSetting DrawPassiveEntityTracers = new BooleanSetting("Passives", false);
    public final BooleanSetting DrawAmbientEntityTracers = new BooleanSetting("Ambients", false);
    public final BooleanSetting DrawOtherEntityTracers = new BooleanSetting("Others", true);

    public final float tracerAlpha = 0.6f;

    public final float maxRange = Float.MAX_VALUE;

    public Tracers() {
        super("tracers", "Tracers", "Draws a visible line to every loaded entity.", ModuleCategory.RENDER);

        addSettings(DrawPlayerEntityTracers, DrawHostileEntityTracers, DrawPassiveEntityTracers, DrawAmbientEntityTracers, DrawOtherEntityTracers);
    }

    public float[] getColor(class_1297 entity) {
        float[] color;
        if (entity instanceof class_1657) {
            color = new float[]{1f, 0f, 0f, DrawPlayerEntityTracers.booleanValue() ? tracerAlpha : 0f};
        } else if (entity instanceof class_1569) {
            color = new float[]{1f, 0.5f, 0f, DrawHostileEntityTracers.booleanValue() ? tracerAlpha : 0f};
        } else if (entity instanceof class_1296) {
            color = new float[]{0f, 1f, 0f, DrawPassiveEntityTracers.booleanValue() ? tracerAlpha : 0f};
        } else if (entity instanceof class_1421) {
            color = new float[]{0f, 0f, 0.85f, DrawAmbientEntityTracers.booleanValue() ? tracerAlpha : 0f};
        } else {
            color = new float[]{0f, 1f, 1f, DrawOtherEntityTracers.booleanValue() ? tracerAlpha : 0f};
        }
        return color;
    }

    @Override
    public void onEvent(Event event) {
        for (class_1297 entity : mc.field_1687.method_18112()) {

            if (entity == mc.field_1724) {
                continue;
            }
            if (mc.field_1724.method_5739(entity) > maxRange) {
                continue;
            }

            float[] col = getColor(entity);

            class_243 vec = entity.method_19538().method_1020(RenderUtils.getInterpolationOffset(entity));
            class_243 vec2 = new class_243(0, 0, 75).method_1037(-(float) Math.toRadians(mc.field_1773.method_19418().method_19329())).method_1024(-(float) Math.toRadians(mc.field_1773.method_19418().method_19330())).method_1019(mc.field_1719.method_33571());

            RenderUtils.drawLine(vec2.field_1352, vec2.field_1351, vec2.field_1350, vec.field_1352, vec.field_1351, vec.field_1350, col, 1);
            RenderUtils.drawLine(vec.field_1352, vec.field_1351, vec.field_1350, vec.field_1352, vec.field_1351 + entity.method_17682() * 0.9, vec.field_1350, col, 1);

        }
    }

}
