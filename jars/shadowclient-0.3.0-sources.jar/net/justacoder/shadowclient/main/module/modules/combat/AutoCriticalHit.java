package net.justacoder.shadowclient.main.module.modules.combat;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_2828;
import net.minecraft.class_3966;

@EventListener({PreTickEvent.class})
@SearchTags({"autocrit", "criticals", "automatical crit", "auto critical hit"})
public class AutoCriticalHit extends Module {

    public AutoCriticalHit() {
        super("autocrit", "Criticals", "Automatically land critical hits every time. ", ModuleCategory.COMBAT);
    }

    @Override
    public void onEvent(Event event) {
        if (!mc.field_1690.field_1886.method_1434()) {
            return;
        }
        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1331 || !(((class_3966) mc.field_1765).method_17782() instanceof class_1309)) {
            return;
        }
        if (!mc.field_1724.method_24828()) {
            return;
        }
        if (mc.field_1724.method_5799() || mc.field_1724.method_5771()) {
            return;
        }

        mc.field_1724.field_3944.method_2883(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 0.0625d, mc.field_1724.method_23321(), true));
        mc.field_1724.field_3944.method_2883(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), false));
        mc.field_1724.field_3944.method_2883(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 1.1E-5d, mc.field_1724.method_23321(), false));
        mc.field_1724.field_3944.method_2883(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), false));
    }
}
