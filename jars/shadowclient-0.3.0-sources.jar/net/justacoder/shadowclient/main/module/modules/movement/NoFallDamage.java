package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_2828;

@EventListener({PreTickEvent.class})
@SearchTags({"anti fall damage", "no fall damage", "no fall dmg", "no falling damage", "nofalldamage"})
public class NoFallDamage extends Module {
    public NoFallDamage() {
        super("nofall", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEvent(Event event) {

        if (mc.field_1724.method_6128()) {
            return;
        }
        if (mc.field_1724.field_6017 <= 2) {
            return;
        }
        if (mc.field_1724.method_18798().field_1351 > -0.5) {
            return;
        }

        mc.field_1724.field_3944.method_2883(new class_2828.class_5911(true));
    }
}
