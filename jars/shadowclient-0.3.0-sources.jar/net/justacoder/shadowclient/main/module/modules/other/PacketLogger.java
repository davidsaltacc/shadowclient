package net.justacoder.shadowclient.main.module.modules.other;

import net.minecraft.*;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.play.*;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PacketRecievedEvent;
import net.justacoder.shadowclient.main.event.events.PacketSentEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import net.justacoder.shadowclient.main.setting.settings.StringSetting;
import net.justacoder.shadowclient.main.util.ChatUtils;

@EventListener({PacketSentEvent.class, PacketRecievedEvent.class})
@SearchTags({"packet logger"})
public class PacketLogger extends Module {

    public final EnumSetting<Mode> MODE = new EnumSetting<>("Mode", Mode.ALL);
    public final StringSetting FILTER = new StringSetting("Filter");
    public final EnumSetting<FMode> FMODE = new EnumSetting<>("Filter Mode", FMode.WHITELIST);

    public PacketLogger() {
        super("packetlogger", "Packet Log", "See what packets are being sent between you and the server. ", ModuleCategory.OTHER);
        addSettings(MODE, FILTER, FMODE);
    }

    public String cleanClassName(class_2596<?> cl) {
        return translate(cl);
    }

    public boolean filter(String text) {
        if (text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.BLACKLIST) {
            return true;
        }
        return !text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.WHITELIST;
    }

    public void send(String text) {
        if (!FILTER.stringValue().isEmpty()) {
            if (filter(text)) {
                return;
            }
        }
        ChatUtils.sendMessageClient(text);
    }

    @Override
    public void onEvent(Event event) {
        if (MODE.getEnumValue() == Mode.ALL) {
            if (event instanceof PacketRecievedEvent) {
                send(ChatUtils.Formattings.ITALIC + "RECEIVED " + ChatUtils.Formattings.RESET + cleanClassName(((PacketRecievedEvent) event).packet));
                return;
            }
            send(ChatUtils.Formattings.ITALIC + "SENT " + ChatUtils.Formattings.RESET + cleanClassName(((PacketSentEvent) event).packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.RECEIVED && event instanceof PacketRecievedEvent) {
            send(ChatUtils.Formattings.ITALIC + "RECEIVED " + ChatUtils.Formattings.RESET + cleanClassName(((PacketRecievedEvent) event).packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.SENT && event instanceof PacketSentEvent) {
            send(ChatUtils.Formattings.ITALIC + "SENT " + ChatUtils.Formattings.RESET + cleanClassName(((PacketSentEvent) event).packet));
        }
    }

    public enum Mode {
        ALL("All"),
        RECEIVED("Received"),
        SENT("Sent");


        final String name;
        Mode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }

    public enum FMode {
        BLACKLIST("Blacklist"),
        WHITELIST("Whitelist");


        final String name;
        FMode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }

    public String translate(class_2596<?> in) { // this cant be real lol (it will just print "class_NNNN" else) TODO test
        if (in instanceof class_2859) { return "AdvancementTabPacket"; }
        if (in instanceof class_2836) { return "BoatPaddleStatePacket"; }
        if (in instanceof class_2820) { return "BookUpdatePacket"; }
        if (in instanceof class_2811) { return "ButtonClickPacket"; }
        if (in instanceof class_2797) { return "ChatMessagePacket"; }
        if (in instanceof class_2813) { return "ClickSlotPacket"; }
        if (in instanceof class_2848) { return "ClientCommandPacket"; }
        if (in instanceof class_2803) { return "ClientSettingsPacket"; }
        if (in instanceof class_2799) { return "ClientStatusPacket"; }
        if (in instanceof class_2815) { return "CloseHandledScreenPacket"; }
        if (in instanceof class_7472) { return "CommandExecutionPacket"; }
        if (in instanceof class_2840) { return "CraftRequestPacket"; }
        if (in instanceof class_2873) { return "CreativeInventoryActionPacket"; }
        if (in instanceof class_2817) { return "CustomPayloadPacket"; }
        if (in instanceof class_2879) { return "HandSwingPacket"; }
        if (in instanceof class_5194) { return "JigsawGeneratingPacket"; }
        if (in instanceof class_2827) { return "KeepAlivePacket"; }
        if (in instanceof class_7640) { return "MessageAcknowledgementPacket"; }
        if (in instanceof class_2838) { return "PickFromInventoryPacket"; }
        if (in instanceof class_2846) { return "PlayerActionPacket"; }
        if (in instanceof class_2851) { return "PlayerInputPacket"; }
        if (in instanceof class_2885) { return "PlayerInteractBlockPacket"; }
        if (in instanceof class_2824) { return "PlayerInteractEntityPacket"; }
        if (in instanceof class_2886) { return "PlayerInteractItemPacket"; }
        if (in instanceof class_2828.class_2830) { return "PlayerMovePacket.Full"; }
        if (in instanceof class_2828.class_2831) { return "PlayerMovePacket.LookAndOnGround"; }
        if (in instanceof class_2828.class_5911) { return "PlayerMovePacket.OnGroundOnly"; }
        if (in instanceof class_2828.class_2829) { return "PlayerMovePacket.PositionAndOnGround"; }
        if (in instanceof class_7861) { return "PlayerSessionPacket"; }
        if (in instanceof class_6374) { return "PlayPongPacket"; }
        if (in instanceof class_2795) { return "QueryBlockNbtPacket"; }
        if (in instanceof class_2822) { return "QueryEntityNbtPacket"; }
        if (in instanceof class_2853) { return "RecipeBookDataPacket"; }
        if (in instanceof class_2855) { return "RenameItemPacket"; }
        if (in instanceof class_2805) { return "RequestCommandCompletionsPacket"; }
        if (in instanceof class_2856) { return "ResourcePackStatusPacket"; }
        if (in instanceof class_2863) { return "SelectMerchantTradePacket"; }
        if (in instanceof class_2884) { return "SpectatorTeleportPacket"; }
        if (in instanceof class_2793) { return "TeleportConfirmPacket"; }
        if (in instanceof class_2866) { return "UpdateBeaconPacket"; }
        if (in instanceof class_2870) { return "UpdateCommandBlockPacket"; }
        if (in instanceof class_4210) { return "UpdateDifficultyPacket"; }
        if (in instanceof class_4211) { return "UpdateDifficultyLockPacket"; }
        if (in instanceof class_3753) { return "UpdateJigsawPacket"; }
        if (in instanceof class_2842) { return "UpdatePlayerAbilitiesPacket"; }
        if (in instanceof class_2868) { return "UpdateSelectedSlotPacket"; }
        if (in instanceof class_2877) { return "UpdateSignPacket"; }
        if (in instanceof class_2875) { return "UpdateStructureBlockPacket"; }
        if (in instanceof class_2833) { return "VehicleMovePacket"; }

        if (in instanceof class_2779) { return "AdvancementUpdatePacket"; }
        if (in instanceof class_2620) { return "BlockBreakingProgressPacket"; }
        if (in instanceof class_2622) { return "BlockEntityUpdatePacket"; }
        if (in instanceof class_2623) { return "BlockEventPacket"; }
        if (in instanceof class_2626) { return "BlockUpdatePacket"; }
        if (in instanceof class_2629) { return "BossBarPacket"; }
        if (in instanceof class_8042) { return "BundlePacket"; }
        if (in instanceof class_7438) { return "ChatMessagePacket"; }
        if (in instanceof class_7597) { return "ChatSuggestionsPacket"; }
        if (in instanceof class_8212) { return "ChunkBiomeDataPacket"; }
        if (in instanceof class_2672) { return "ChunkDataPacket"; }
        if (in instanceof class_2637) { return "ChunkDeltaUpdatePacket"; }
        if (in instanceof class_4273) { return "ChunkLoadDistancePacket"; }
        if (in instanceof class_4282) { return "ChunkRenderDistancePacket"; }
        if (in instanceof class_5888) { return "ClearTitlePacket"; }
        if (in instanceof class_2645) { return "CloseScreenPacket"; }
        if (in instanceof class_2639) { return "CommandSuggestionsPacket"; }
        if (in instanceof class_2641) { return "CommandTreePacket"; }
        if (in instanceof class_2656) { return "CooldownUpdatePacket"; }
        if (in instanceof class_2695) { return "CraftFailedResponsePacket"; }
        if (in instanceof class_2658) { return "CustomPayloadPacket"; }
        if (in instanceof class_8043) { return "DamageTiltPacket"; }
        if (in instanceof class_5892) { return "DeathMessagePacket"; }
        if (in instanceof class_2632) { return "DifficultyPacket"; }
        if (in instanceof class_2661) { return "DisconnectPacket"; }
        if (in instanceof class_5890) { return "EndCombatPacket"; }
        if (in instanceof class_5891) { return "EnterCombatPacket"; }
        if (in instanceof class_2716) { return "EntitiesDestroyPacket"; }
        if (in instanceof class_2616) { return "EntityAnimationPacket"; }
        if (in instanceof class_2740) { return "EntityAttachPacket"; }
        if (in instanceof class_2781) { return "EntityAttributesPacket"; }
        if (in instanceof class_8143) { return "EntityDamagePacket"; }
        if (in instanceof class_2744) { return "EntityEquipmentUpdatePacket"; }
        if (in instanceof class_2752) { return "EntityPassengersSetPacket"; }
        if (in instanceof class_2777) { return "EntityPositionPacket"; }
        if (in instanceof class_2684.class_2685) { return "EntityPacket.MoveRelative"; }
        if (in instanceof class_2684.class_2687) { return "EntityPacket.Rotate"; }
        if (in instanceof class_2684.class_2686) { return "EntityPacket.RotateAndMoveRelative"; }
        if (in instanceof class_2726) { return "EntitySetHeadYawPacket"; }
        if (in instanceof class_2604) { return "EntitySpawnPacket"; }
        if (in instanceof class_2783) { return "EntityStatusEffectPacket"; }
        if (in instanceof class_2663) { return "EntityStatusPacket"; }
        if (in instanceof class_2739) { return "EntityTrackerUpdatePacket"; }
        if (in instanceof class_2743) { return "EntityVelocityUpdatePacket"; }
        if (in instanceof class_2748) { return "ExperienceBarUpdatePacket"; }
        if (in instanceof class_2606) { return "ExperienceOrbSpawnPacket"; }
        if (in instanceof class_2664) { return "ExplosionPacket"; }
        if (in instanceof class_7832) { return "FeaturesPacket"; }
        if (in instanceof class_2678) { return "GameJoinPacket"; }
        if (in instanceof class_7439) { return "GameMessagePacket"; }
        if (in instanceof class_2668) { return "GameStateChangePacket"; }
        if (in instanceof class_2749) { return "HealthUpdatePacket"; }
        if (in instanceof class_2649) { return "InventoryPacket"; }
        if (in instanceof class_2775) { return "ItemPickupAnimationPacket"; }
        if (in instanceof class_2670) { return "KeepAlivePacket"; }
        if (in instanceof class_2676) { return "LightUpdatePacket"; }
        if (in instanceof class_2707) { return "LookAtPacket"; }
        if (in instanceof class_2683) { return "MapUpdatePacket"; }
        if (in instanceof class_2774) { return "NbtQueryResponsePacket"; }
        if (in instanceof class_2648) { return "OpenHorseScreenPacket"; }
        if (in instanceof class_3944) { return "OpenScreenPacket"; }
        if (in instanceof class_3895) { return "OpenWrittenBookPacket"; }
        if (in instanceof class_5894) { return "OverlayMessagePacket"; }
        if (in instanceof class_2675) { return "ParticlePacket"; }
        if (in instanceof class_2696) { return "PlayerAbilitiesPacket"; }
        if (in instanceof class_4463) { return "PlayerActionResponsePacket"; }
        if (in instanceof class_2772) { return "PlayerListHeaderPacket"; }
        if (in instanceof class_2703) { return "PlayerListPacket"; }
        if (in instanceof class_2708) { return "PlayerPositionLookPacket"; }
        if (in instanceof class_7828) { return "PlayerRemovePacket"; }
        if (in instanceof class_2724) { return "PlayerRespawnPacket"; }
        if (in instanceof class_2759) { return "PlayerSpawnPositionPacket"; }
        if (in instanceof class_2613) { return "PlayerSpawnPacket"; }
        if (in instanceof class_6373) { return "PlayPingPacket"; }
        if (in instanceof class_2765) { return "PlaySoundFromEntityPacket"; }
        if (in instanceof class_2767) { return "PlaySoundPacket"; }
        if (in instanceof class_7827) { return "ProfilelessChatMessagePacket"; }
        if (in instanceof class_2718) { return "RemoveEntityStatusEffectPacket"; }
        if (in instanceof class_7617) { return "RemoveMessagePackage"; }
        if (in instanceof class_2720) { return "ResourcePackSendPacket"; }
        if (in instanceof class_2736) { return "ScoreboardDisplayPacket"; }
        if (in instanceof class_2751) { return "ScoreboardObjectiveUpdatePacket"; }
        if (in instanceof class_2757) { return "ScoreboardPlayerUpdatePacket"; }
        if (in instanceof class_2651) { return "ScreenHandlerPropertyUpdatePacket"; }
        if (in instanceof class_2653) { return "ScreenHandlerSlotUpdatePacket"; }
        if (in instanceof class_2729) { return "SelectAdvancementTabPacket"; }
        if (in instanceof class_7495) { return "ServerMetadataPacket"; }
        if (in instanceof class_2734) { return "SetCameraEntityPacket"; }
        if (in instanceof class_3943) { return "SetTradeOffersPacket"; }
        if (in instanceof class_2693) { return "SignEditorOpenPacket"; }
        if (in instanceof class_6682) { return "SimulationDistancePacket"; }
        if (in instanceof class_2617) { return "StatisticsPacket"; }
        if (in instanceof class_2770) { return "StopSoundPacket"; }
        if (in instanceof class_5903) { return "SubtitlePacket"; }
        if (in instanceof class_2788) { return "SynchroniseRecipesPacket"; }
        if (in instanceof class_2790) { return "SynchroniseTagsPacket"; }
        if (in instanceof class_5900) { return "TeamPacket"; }
        if (in instanceof class_5905) { return "TitleFadePacket"; }
        if (in instanceof class_5904) { return "TitlePacket"; }
        if (in instanceof class_2666) { return "UnloadChunkPacket"; }
        if (in instanceof class_2713) { return "UnlockRecipesPacket"; }
        if (in instanceof class_2735) { return "UpdateSelectedSlotPacket"; }
        if (in instanceof class_2692) { return "VehicleMovePacket"; }
        if (in instanceof class_5895) { return "WorldBorderCenterChangedPacket"; }
        if (in instanceof class_5889) { return "WorldBorderInitializePacket"; }
        if (in instanceof class_5896) { return "WorldBorderInterpolateSizePacket"; }
        if (in instanceof class_5897) { return "WorldBorderSizeChangedPacket"; }
        if (in instanceof class_5899) { return "WorldBorderWarningBlocksChangedPacket"; }
        if (in instanceof class_5898) { return "WorldBorderWarningTimeChangedPacket"; }
        if (in instanceof class_2673) { return "WorldEventPacket"; }
        if (in instanceof class_2761) { return "WorldTimeUpdatePacket"; }

        return "Packet";
    }
}
