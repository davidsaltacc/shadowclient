package net.justacoder.shadowclient.main.module.modules.render;

import net.minecraft.block.*;
import net.minecraft.class_1944;
import net.minecraft.class_2189;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_259;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_2771;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.Render3DEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.util.RenderUtils;

@EventListener({Render3DEvent.class})
@SearchTags({"lightoverlay", "light overlay", "spawn indicator"})
public class LightOverlay extends Module {

    public NumberSetting RADIUS = new NumberSetting("Radius", 1, 25, 10, 0);
    public NumberSetting VRADIUS = new NumberSetting("Vertical Radius", 1, 25, 1, 0);

    public LightOverlay() {
        super("lightoverlay", "Light Overlay", "Renders an overlay on blocks indicating if mobs can/will spawn.", ModuleCategory.RENDER);

        addSettings(RADIUS, VRADIUS);
    }

    @Override
    public void onEvent(Event event) {
        int plx = mc.field_1724.method_31477();
        int ply = mc.field_1724.method_31478();
        int plz = mc.field_1724.method_31479();

        int radius = RADIUS.intValue();
        int vradius = VRADIUS.intValue();

        int minX = plx - radius;
        int maxX = plx + radius;
        int minZ = plz - radius;
        int maxZ = plz + radius;
        int minY = Math.max(mc.field_1687.method_31607(), ply - vradius);
        int maxY = Math.min(ply + vradius, mc.field_1687.method_31600());

        for (int y = minY; y <= maxY; y++) {
            for (int x = minX; x <= maxX; x++) {
                for (int z = minZ; z <= maxZ; z++) {
                    class_2338 pos = new class_2338(x, y, z);
                    class_2680 state = mc.field_1687.method_8320(pos);
                    int spawnPossible = spawnPossible(pos, state);
                    renderBlockOverlay(pos, spawnPossible);
                }
            }
        }
    }

    public void renderBlockOverlay(class_2338 pos, int level) { // todo maybe render text showing light level somehow?
        if (level == -1) {
            return;
        }
        float x = pos.method_10263();
        float y = pos.method_10264() + 0.008f;
        float z = pos.method_10260();
        float[] color;
        if (level == 1) {
            color = new float[]{1f, 1f, 0f, 1f};
        } else if (level == 2) {
            color = new float[]{1f, 0f, 0f, 1f};
        } else {
            color = new float[]{0f, 1f, 0f, 1f};
        }
        RenderUtils.drawLine(x, y, z, x, y, z + 1, color, 1, true);
        RenderUtils.drawLine(x, y, z + 1, x + 1, y, z + 1, color, 1, true);
        RenderUtils.drawLine(x + 1, y, z + 1, x + 1, y, z, color, 1, true);
        RenderUtils.drawLine(x + 1, y, z, x, y, z, color, 1, true);
    }

    public int spawnPossible(class_2338 pos, class_2680 state) { // -1 = do not render, 0 = never, 1 = possible, 2 = always
        if (!(state.method_26204() instanceof class_2189)) {
            return -1;
        }
        class_2338 down = pos.method_10074();
        class_2680 dState = mc.field_1687.method_8320(down);
        if (dState.method_26204() instanceof class_2189) {
            return -1;
        }
        if (dState.method_26204() == class_2246.field_9987) {
            return -1;
        }
        if (!top(dState)) {
            if (dState.method_26220(mc.field_1687, down) != class_259.method_1077()) {
                return -1;
            }
            if (dState.method_26167(mc.field_1687, down)) {
                return -1;
            }
        }
        if (mc.field_1687.method_22346(pos, 0) <= 0) {
            return 2;
        } else if (mc.field_1687.method_8314(class_1944.field_9282, pos) <= 0) {
            return 1;
        }
        return 0;
    }

    public boolean top(class_2680 state) {
        if (state.method_26204() instanceof class_2482 && state.method_11654(class_2482.field_11501) == class_2771.field_12679) {
            return true;
        } else {
            return state.method_26204() instanceof class_2510 && state.method_11654(class_2510.field_11572) == class_2760.field_12619;
        }
    }
}
