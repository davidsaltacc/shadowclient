package net.justacoder.shadowclient.main.module.modules.fun;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_2828;
import net.minecraft.class_5819;

@EventListener({PreTickEvent.class})
@SearchTags({"derpy", "head shake", "retarded"})
public class Derpy extends Module {

    private final class_5819 random = class_5819.method_43047();

    public Derpy() {
        super("derpy", ModuleCategory.FUN);
    }

    @Override
    public void onEvent(Event event) {

        float yaw = mc.field_1724.method_36454() + random.method_43057() * 360F - 180F;
        float pitch = random.method_43057() * 180F - 90F;

        mc.field_1724.field_3944.method_2883(new class_2828.class_2831(yaw, pitch, mc.field_1724.method_24828()));
    }
}
