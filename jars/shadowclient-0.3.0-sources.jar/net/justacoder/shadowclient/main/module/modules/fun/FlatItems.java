package net.justacoder.shadowclient.main.module.modules.fun;

import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_243;

@SearchTags({"flat items", "item physics", "flatitems"})
public class FlatItems extends Module {

    public BooleanSetting FACE_PLAYER = new BooleanSetting("Items Face you", false);

    public FlatItems() {
        super("flatitems", ModuleCategory.FUN);

        addSetting(FACE_PLAYER);
    }

    public float getItemAngle(class_1542 itemEntity, class_1657 playerEntity) {
        class_243 iPos = itemEntity.method_19538();
        class_243 pPos = playerEntity.method_19538();
        double diffX = iPos.field_1352 - pPos.field_1352;
        double diffZ = iPos.field_1350 - pPos.field_1350;
        return (float) Math.atan2(diffZ, diffX) - (float) Math.PI / 2;
    }

    public boolean face() {
        return FACE_PLAYER.booleanValue();
    }
}
