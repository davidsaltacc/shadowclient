package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Pseudo
@Mixin(
    targets = {
            "net.caffeinemc.mods.sodium.client.render.chunk.compile.pipeline.DefaultFluidRenderer", // > v6
            "me.jellysquid.mods.sodium.client.render.chunk.compile.pipeline.FluidRenderer" // < v6
    },
    remap = false
)
public abstract class Sodium_FluidRendererMixin {

    @SuppressWarnings("UnresolvedMixinReference")
    @Inject(method = "isSideExposed", at = @At("HEAD"), cancellable = true)
    private void modifyIsSideExposed(class_1920 world, int x, int y, int z, class_2350 dir, float height, CallbackInfoReturnable<Boolean> cir) {

        class_2680 state = world.method_8320(new class_2338(x, y, z));
        class_2680 state2 = world.method_8320(new class_2338(x, y, z).method_10093(dir));
        ShouldDrawSideEvent evt = new ShouldDrawSideEvent(state);

        EventManager.fireEvent(evt);

        if (evt.renderedSet) {
            cir.setReturnValue(evt.rendered && !state.method_26227().method_15772().method_15780(state2.method_26227().method_15772()));
        }
    }

    @SuppressWarnings("UnresolvedMixinReference")
    @Inject(method = "isFullBlockFluidOccluded", at = @At("HEAD"), cancellable = true)
    private void modifyIsFullBlockFluidOccluded(class_1920 world, class_2338 pos, class_2350 dir, class_2680 state, class_3610 fluidState, CallbackInfoReturnable<Boolean> cir) {

        ShouldDrawSideEvent evt = new ShouldDrawSideEvent(state);

        EventManager.fireEvent(evt);

        if (evt.renderedSet) {
            cir.setReturnValue(!evt.rendered);
        }

    }

}
