package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.world.WeatherControl;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2874;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.function.Supplier;

@Mixin(class_638.class)
public abstract class ClientWorldMixin extends class_1937 implements class_1936 {

    protected ClientWorldMixin(class_5269 properties, class_5321<class_1937> registryRef, class_5455 registryManager, class_6880<class_2874> dimensionEntry, boolean isClient, boolean debugWorld, long seed, int maxChainedNeighborUpdates) {
        super(properties, registryRef, registryManager, dimensionEntry, isClient, debugWorld, seed, maxChainedNeighborUpdates);
    }

    @Inject(method = "getBlockParticle", at = @At("HEAD"), cancellable = true)
    private void onGetBlockParticle(CallbackInfoReturnable<class_2248> cir) {
        if (ModuleManager.RenderBarriersModule.enabled) {
            cir.setReturnValue(class_2246.field_10499);
        }
    }

    @Override
    public float method_8430(float delta) {
        if (ModuleManager.WeatherControlModule.rainDisabled()) {
            return 0f;
        }
        return super.method_8430(delta);
    }

    @Override
    public float method_30274(float tickDelta) {
        WeatherControl weatherControl = ModuleManager.WeatherControlModule;

        long timeOfDay = weatherControl.timeChanged() ? weatherControl.getTime() : method_8401().method_217();

        return method_8597().method_28528(timeOfDay);
    }

    @Override
    public int method_30273() {
        WeatherControl weatherControl = ModuleManager.WeatherControlModule;

        if (weatherControl.moonChanged()) {
            return weatherControl.getMoon();
        }

        return method_8597().method_28531(method_30271());
    }

}
