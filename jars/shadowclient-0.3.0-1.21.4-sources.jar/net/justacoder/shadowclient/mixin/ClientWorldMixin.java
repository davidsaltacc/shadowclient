package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.util.MixinSharedValues;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2874;
import net.minecraft.class_3610;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.world.*;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.world.WeatherControl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_638.class)
public abstract class ClientWorldMixin extends class_1937 implements class_1936 {

    protected ClientWorldMixin(class_5269 properties, class_5321<class_1937> registryRef, class_5455 registryManager, class_6880<class_2874> dimensionEntry, boolean isClient, boolean debugWorld, long seed, int maxChainedNeighborUpdates) {
        super(properties, registryRef, registryManager, dimensionEntry, isClient, debugWorld, seed, maxChainedNeighborUpdates);
    }

    @Inject(method = "getBlockParticle", at = @At("HEAD"), cancellable = true)
    private void onGetBlockParticle(CallbackInfoReturnable<class_2248> cir) {
        if (ModuleManager.RenderBarriersModule.enabled) {
            cir.setReturnValue(class_2246.field_10499);
        }
    }

    @Override
    public float method_8430(float delta) {
        if (ModuleManager.WeatherControlModule.rainDisabled()) {
            return 0f;
        }
        return super.method_8430(delta);
    }

    @Override
    public float method_30274(float tickDelta) {
        WeatherControl weatherControl = ModuleManager.WeatherControlModule;

        long timeOfDay = weatherControl.timeChanged() ? weatherControl.getTime() : method_8401().method_217();

        return method_8597().method_28528(timeOfDay);
    }

    @Override
    public int method_30273() {
        WeatherControl weatherControl = ModuleManager.WeatherControlModule;

        if (weatherControl.moonChanged()) {
            return weatherControl.getMoon();
        }

        return method_8597().method_28531(method_30271());
    }

    @Override
    public class_3965 method_17742(class_3959 context) {
        return class_1922.method_17744(context.method_17750(), context.method_17747(), context, (innerContext, pos) -> { // sadly can't just override a lambda, and injecting into an interface isn't supported either. a full override is necessary
            class_2680 blockState = this.method_8320(pos);
            class_3610 fluidState = this.method_8316(pos);
            if (MixinSharedValues.ignoreSolidBlocksRaycasting && !blockState.method_31709()) {
                return null;
            }
            class_243 vec3d = innerContext.method_17750();
            class_243 vec3d2 = innerContext.method_17747();
            class_265 voxelShape = innerContext.method_17748(blockState, this, pos);
            class_3965 blockHitResult = this.method_17745(vec3d, vec3d2, pos, voxelShape, blockState);
            class_265 voxelShape2 = innerContext.method_17749(fluidState, this, pos);
            class_3965 blockHitResult2 = voxelShape2.method_1092(vec3d, vec3d2, pos);
            double d = blockHitResult == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult.method_17784());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : innerContext.method_17750().method_1025(blockHitResult2.method_17784());
            return d <= e ? blockHitResult : blockHitResult2;
        }, innerContext -> {
            class_243 vec3d = innerContext.method_17750().method_1020(innerContext.method_17747());
            return class_3965.method_17778(innerContext.method_17747(), class_2350.method_10142(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350), class_2338.method_49638(innerContext.method_17747()));
        });
    }
}
