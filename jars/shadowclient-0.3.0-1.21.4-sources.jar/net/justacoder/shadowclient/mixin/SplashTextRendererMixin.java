package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.config.SCSettings;
import net.justacoder.shadowclient.main.ui.SCSplashTexts;
import net.minecraft.class_156;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_7833;
import net.minecraft.class_8519;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8519.class)
public abstract class SplashTextRendererMixin {

    @Unique
    private String customText;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void setCustomText(String text, CallbackInfo ci) {
        customText = SCSplashTexts.getRandom();
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void addSplashText(class_332 context, int screenWidth, class_327 textRenderer, int alpha, CallbackInfo ci) {

        if (SCSettings.VanillaSpoof.booleanValue()) {
            return;
        }

        context.method_51448().method_22903();
        context.method_51448().method_46416(screenWidth / 2.0f + 123.0f + 10.f, 69.0f + 10.f, 0.0f);
        context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(-20.0f));
        float f = 1.8f - class_3532.method_15379(class_3532.method_15374((class_156.method_658() % 1000L) / 1000.0f * (float) (Math.PI * 2) + (float) Math.PI / 2.f) * 0.1f);
        f = f * 75.f / (textRenderer.method_1727(customText) + 32);
        context.method_51448().method_22905(f, f, f);
        context.method_25300(textRenderer, customText, 0, -8, 16776960 | alpha);
        context.method_51448().method_22909();

    }

}
