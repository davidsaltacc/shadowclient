package net.justacoder.shadowclient.mixin;

import net.minecraft.class_304;
import net.minecraft.class_459;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_459.class_462.class)
public interface KeyBindingEntryAccessor {

    @Accessor("binding")
    public class_304 getBinding();

}
