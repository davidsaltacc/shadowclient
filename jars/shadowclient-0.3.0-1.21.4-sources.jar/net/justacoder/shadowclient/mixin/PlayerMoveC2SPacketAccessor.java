package net.justacoder.shadowclient.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2828.class)
public interface PlayerMoveC2SPacketAccessor {

    @Accessor("onGround")
    public void setOnGround(boolean onGround);

}
