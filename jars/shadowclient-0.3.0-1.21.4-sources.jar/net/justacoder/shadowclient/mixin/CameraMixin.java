package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.render.ExtendedCameraDistance;
import net.justacoder.shadowclient.main.module.modules.render.Freecam;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_4184.class)
public abstract class CameraMixin {

    @Inject(at = @At("HEAD"), method = "clipToSpace", cancellable = true)
    private void onClipToSpace(float desiredCameraDistance, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.CameraNoclipModule.enabled) {
            cir.setReturnValue(desiredCameraDistance);
        }
    }

    @ModifyArg(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;clipToSpace(F)F"))
    private float onClipToSpace(float desiredCameraDistance) {
        ExtendedCameraDistance ecd = ModuleManager.ExtendedCameraDistanceModule;
        if (ecd.enabled) {
            return ecd.getDistance();
        }
        return desiredCameraDistance;
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"))
    private void onUpdateSetPosArgs(Args args) {
        Freecam freecam = ModuleManager.FreecamModule;

        if (freecam.enabled) {
            args.set(0, freecam.getX());
            args.set(1, freecam.getY());
            args.set(2, freecam.getZ());
        }
    }

    @ModifyArgs(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
    private void onUpdateSetRotationArgs(Args args) {
        Freecam freecam = ModuleManager.FreecamModule;

        if (freecam.enabled) {
            args.set(0, (float) freecam.getYaw());
            args.set(1, (float) freecam.getPitch());
        }
    }

    @Inject(method = "getSubmersionType", at = @At("HEAD"), cancellable = true)
    private void onGetSubmersionType(CallbackInfoReturnable<class_5636> cir) {
        if (ModuleManager.NoOverlayModule.enabled) {
            cir.setReturnValue(class_5636.field_27888);
        }
    }
}
