package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_10039;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public abstract class ItemEntityRendererMixin {

    @Unique public class_10039 item;
    @Unique public final Quaternionf flatRotation = class_7833.field_40714.rotation(1.57079633f);

    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void onRender(class_10039 itemEntityRenderState, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo ci) {
        item = itemEntityRenderState;
    }

    @Redirect(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V", ordinal = 0))
    private void onTranslate(class_4587 matrices, float x, float y, float z) {
        if (!ModuleManager.FlatItemsModule.enabled) {
            matrices.method_46416(x, y, z);
        }
    }

    @Redirect(method = "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;multiply(Lorg/joml/Quaternionf;)V", ordinal = 0))
    private void onRotate(class_4587 matrices, Quaternionf quaternion) {
        if (ModuleManager.FlatItemsModule.enabled) {
            float offset = item.field_53435;
            if (ModuleManager.FlatItemsModule.face()) {
                offset = ModuleManager.FlatItemsModule.getItemAngle(item, ShadowClientMain.mc.field_1724);
            }
            matrices.method_22907(flatRotation);
            matrices.method_22907(class_7833.field_40718.rotation(offset));
        } else {
            matrices.method_22907(quaternion);
        }
    }
}
