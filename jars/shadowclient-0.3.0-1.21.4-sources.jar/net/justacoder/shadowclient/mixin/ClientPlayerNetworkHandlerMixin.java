package net.justacoder.shadowclient.mixin;

import com.mojang.brigadier.ParseResults;
import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.command.CommandManager;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ChunkDeltaUpdateEvent;
import net.justacoder.shadowclient.main.event.events.PacketSentEvent;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2637;
import net.minecraft.class_2678;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_7633;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Mixin(class_634.class)
public abstract class ClientPlayerNetworkHandlerMixin extends class_8673 implements class_2602, class_7633 {

    @Shadow protected abstract ParseResults<class_2172> parse(String command);

    protected ClientPlayerNetworkHandlerMixin(class_310 client, class_2535 connection, class_8675 connectionState) {
        super(client, connection, connectionState);
    }

    @Inject(method = "sendChatMessage", at = @At("HEAD"), locals = LocalCapture.CAPTURE_FAILHARD, cancellable = true)
    public void sendMessage(String content, CallbackInfo ci) {
        if (SCMain.interceptMessage(content)) {
            CommandManager.execute(content);
            ci.cancel();
        }
    }

    @Inject(method = "onGameJoin", at = @At(value = "TAIL"))
    private void onGameJoined(class_2678 packet, CallbackInfo ci) {
        SCMain.onWorldJoined();
    }

    @Override
    public void method_52787(class_2596<?> packet) {
        PacketSentEvent event = new PacketSentEvent(packet);
        EventManager.fireEvent(event);
        if (event.cancelled) {
            return;
        }
        super.method_52787(packet);
    }

    @Inject(method = "onChunkDeltaUpdate", at = @At("HEAD"))
    private void onChunkDeltaData(class_2637 packet, CallbackInfo ci) {
        Map<class_2338, class_2680> delta = new ConcurrentHashMap<>();
        packet.method_30621(delta::put);
        EventManager.fireEvent(new ChunkDeltaUpdateEvent(delta));
    }

}
