package net.justacoder.shadowclient.mixin;

import net.minecraft.class_287;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_287.class)
public interface BufferBuilderAccessor {

    @Accessor("vertexCount")
    public int getVertexCount();

}
