package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ui.notifications.push.PushNotificationManager;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.ui.hud.HudRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
    private void onRenderOverlay(class_332 context, class_2960 texture, float opacity, CallbackInfo ci) {
        if (texture == null || !"textures/misc/pumpkinblur.png".equals(texture.method_12832())) {
            return;
        }

        if (ModuleManager.NoPumkinModule.enabled) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (ShadowClientMain.mc.field_1755 == null && !((DebugHudAccessor) ShadowClientMain.mc.method_53526()).debugEnabled() && class_310.method_1498()) {
            PushNotificationManager.renderNotifications(context, tickCounter.method_60637(false));
            if (ModuleManager.ShadowHudModule.enabled) {
                HudRenderer.onHudRender(context, tickCounter.method_60637(false));
            }
        }
    }

    @Inject(method = "renderMainHud", at = @At("HEAD"), cancellable = true)
    private void beforeRenderMainHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (ModuleManager.FreecamModule.enabled) {
            ci.cancel();
        }
    }

    @Inject(method = "renderExperienceLevel", at = @At("HEAD"), cancellable = true)
    private void beforeRenderExpLevel(class_332 context, class_9779 tickCounter, CallbackInfo ci) { // why does the experience level get drawn separately
        if (ModuleManager.FreecamModule.enabled) {
            ci.cancel();
        }
    }
}
