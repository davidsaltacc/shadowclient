package net.justacoder.shadowclient.mixin;

import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_340.class)
public interface DebugHudAccessor {

    @Accessor("showDebugHud")
    boolean debugEnabled();

}
