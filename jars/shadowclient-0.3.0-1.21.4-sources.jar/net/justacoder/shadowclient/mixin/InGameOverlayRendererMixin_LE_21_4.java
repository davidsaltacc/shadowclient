package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.annotations.VersionDependentMixin;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@VersionDependentMixin(mcVersionPredicate = ">=1.21.4")
@Mixin(class_4603.class)
public abstract class InGameOverlayRendererMixin_LE_21_4 {

    @Inject(method = "renderUnderwaterOverlay", at = @At("HEAD"), cancellable = true)
    private static void onRenderUnderwaterOverlay(class_310 client, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
        if (ModuleManager.NoOverlayModule.enabled) {
            ci.cancel();
        }
    }

}
