package net.justacoder.shadowclient.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.justacoder.shadowclient.main.util.MixinSharedValues;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.mixininterface.IGameRenderer;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_757.class)
public abstract class GameRendererMixin implements IGameRenderer {

    @Shadow private void setPostProcessor(class_2960 id) {}
    @Shadow private static class_239 ensureTargetInRange(class_239 hitResult, class_243 cameraPos, double interactionRange) { return null; }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public void loadShader(@Nullable class_2960 id) {
        if (id != null) {
            setPostProcessor(id);
        } else {
            ((class_757) (Object) this).method_62905();
        }
    }

    @Inject(at = @At("HEAD"), method = "tiltViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V", cancellable = true)
    private void onTiltViewWhenHurt(class_4587 matrixStack, float f, CallbackInfo ci) {
        if (ModuleManager.NoTiltOnHurtModule.enabled) {
            ci.cancel();
        }
    }

    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F", ordinal = 0), method = "renderWorld")
    private float nauseaLerp(float delta, float start, float end) {
        if (ModuleManager.NoWobbleModule.enabled) {
            return 0;
        }

        return class_3532.method_16439(delta, start, end);
    }

    @Inject(at = @At("HEAD"), method = "getNightVisionStrength(Lnet/minecraft/entity/LivingEntity;F)F", cancellable = true)
    private static void onGetNightVisionStrength(class_1309 entity, float tickDelta, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.NightVisionModule.enabled || ModuleManager.XrayModule.enabled) {
            cir.setReturnValue(1f);
        }
    }

    @Inject(method = "renderHand", at = @At("HEAD"), cancellable = true)
    private void renderHand(class_4184 camera, float tickDelta, Matrix4f matrix4f, CallbackInfo ci) {
        if (ModuleManager.FreecamModule.enabled) {
            ci.cancel();
        }
    }

    @Inject(method = "getFov", at = @At("HEAD"), cancellable = true)
    private void getFov(class_4184 camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        if (ModuleManager.ZoomModule.enabled) {
            cir.setReturnValue(ModuleManager.ZoomModule.FOV.floatValue());
        }
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void bobView(class_4587 matrices, float tickDelta, CallbackInfo ci) {
        if (ModuleManager.NoBobModule.enabled) {
            ci.cancel();
        }
    }

    @Redirect(method = "findCrosshairTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;raycast(DFZ)Lnet/minecraft/util/hit/HitResult;"))
    private class_239 changeCrosshairTarget(class_1297 camEntity, double maxDistance, float tickDelta, boolean includeFluids) {
        if (ModuleManager.WallInteractModule.enabled) {
            MixinSharedValues.ignoreSolidBlocksRaycasting = true;
            class_239 result = camEntity.method_5745(maxDistance, tickDelta, includeFluids);
            MixinSharedValues.ignoreSolidBlocksRaycasting = false;
            return result;
        }
        return camEntity.method_5745(maxDistance, tickDelta, includeFluids);
    }

    @Inject(method = "findCrosshairTarget", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/projectile/ProjectileUtil;raycast(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/EntityHitResult;", shift = At.Shift.AFTER), cancellable = true)
    private void changeCrosshairTarget2(class_1297 camera, double blockInteractionRange, double entityInteractionRange, float tickDelta, CallbackInfoReturnable<class_239> cir, @Local class_239 hitResult, @Local(ordinal = 0) class_243 vec3d, @Local(ordinal = 2) class_243 vec3d3, @Local class_238 box) {
        class_3966 entityHitResult = class_1675.method_18075(camera, vec3d, vec3d3, box, class_1301.field_52443, class_3532.method_33723(Math.max(blockInteractionRange, entityInteractionRange)));
        if (ModuleManager.WallInteractModule.enabled && hitResult.method_17783() == class_239.class_240.field_1333 && entityHitResult == null) {
            cir.setReturnValue(ensureTargetInRange(camera.method_5745(Math.max(blockInteractionRange, entityInteractionRange), tickDelta, false), camera.method_5836(tickDelta), blockInteractionRange));
        }
    }

}
