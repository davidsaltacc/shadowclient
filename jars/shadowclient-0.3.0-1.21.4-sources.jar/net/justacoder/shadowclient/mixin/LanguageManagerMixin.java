package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_1076;
import net.minecraft.class_3300;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1076.class)
public abstract class LanguageManagerMixin {

    @Inject(method = "reload", at = @At("RETURN"))
    private void onLanguageReloaded(class_3300 manager, CallbackInfo ci) {
        ShadowClientMain.reloadTranslations();
    }

}
