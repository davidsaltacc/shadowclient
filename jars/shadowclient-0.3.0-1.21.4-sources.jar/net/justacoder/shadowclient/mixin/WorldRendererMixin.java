package net.justacoder.shadowclient.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.RenderEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.render.BufferBuilderProvider;
import net.justacoder.shadowclient.main.render.Renderer;
import net.minecraft.class_1297;
import net.minecraft.class_3695;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import net.minecraft.class_9925;
import net.minecraft.class_9958;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {

    @Unique private class_4587 stack;
    @Unique private float delta;

    @Inject(method = "method_62214", at = @At("TAIL"))
    private void afterRenderMain(class_9958 fog, class_9779 renderTickCounter, class_4184 camera, class_3695 profiler, Matrix4f matrix4f, Matrix4f matrix4f2, class_9925 handle, class_9925 handle2, class_9925 handle3, class_9925 handle4, boolean bl, class_4604 frustum, class_9925 handle5, CallbackInfo ci, @Local class_4587 stack, @Local float delta) {
        this.stack = stack;
        this.delta = delta;
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void afterRender(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        BufferBuilderProvider provider = BufferBuilderProvider.getInstance();
        EventManager.fireEvent(new RenderEvent(new Renderer(provider, stack, delta)));
        provider.draw();
    }

    @ModifyArg(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/BackgroundRenderer;applyFog(Lnet/minecraft/client/render/Camera;Lnet/minecraft/client/render/BackgroundRenderer$FogType;Lorg/joml/Vector4f;FZF)Lnet/minecraft/client/render/Fog;"), index = 3)
    private float spoofFogDist(float viewDistance) {
        return ModuleManager.SpoofRenderDistanceModule.getDistanceBlocks((int) viewDistance);
    }

    @Inject(method = "getEntitiesToRender", at = @At("RETURN"))
    private void renderPlayerInFreecam(class_4184 camera, class_4604 frustum, List<class_1297> output, CallbackInfoReturnable<Boolean> cir) {
        if (ModuleManager.FreecamModule.enabled && !output.contains(ShadowClientMain.mc.field_1724)) {
            output.add(ShadowClientMain.mc.field_1724);
        }
    }

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSpectator()Z"))
    private boolean spoofSpectatorMode(class_746 instance) {
        if (ModuleManager.FreecamModule.enabled) {
            return true;
        }
        return instance.method_7325();
    }

}
