package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.config.SCSettings;
import net.minecraft.class_1041;
import net.justacoder.shadowclient.main.SCMain;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1041.class)
public abstract class WindowMixin {

    @Inject(method = "setTitle", at = @At("HEAD"), cancellable = true)
    public void setTitle(String title, CallbackInfo ci) {
        GLFW.glfwSetWindowTitle(((class_1041) (Object) this).method_4490(), SCSettings.VanillaSpoof.booleanValue() ? title : SCMain.getWindowTitle() + " | " + title);
        ci.cancel();
    }

}