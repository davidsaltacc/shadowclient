package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_310;
import net.minecraft.class_350;
import net.minecraft.class_4265;
import net.minecraft.class_459;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_459.class)
public abstract class ControlsListWidgetMixin extends class_4265<class_459.class_461> {

    public ControlsListWidgetMixin(class_310 minecraftClient, int i, int j, int k, int l) {
        super(minecraftClient, i, j, k, l);
    }

    @Redirect(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/option/ControlsListWidget;addEntry(Lnet/minecraft/client/gui/widget/EntryListWidget$Entry;)I"))
    private int redirectAddEntry(class_459 instance, class_350.class_351<class_459.class_461> entry) {
        return addEntryCustom((class_459.class_461) entry);
    }

    @Unique
    @SuppressWarnings("RedundantCast")
    private int addEntryCustom(class_459.class_461 entry) {
        if (entry instanceof class_459.class_462) {
            if (!SCMain.moduleKeyBindings.contains(((KeyBindingEntryAccessor) (class_459.class_462) entry).getBinding())) {
                method_25396().add(entry);
            }
            return this.method_25396().size() - 1;
        }
        this.method_25396().add(entry);
        return this.method_25396().size() - 1;
    }

}
