package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.ShouldDrawSideEvent;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_775;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_775.class)
public abstract class FluidRendererMixin {

    @Shadow
    protected static boolean isSameFluid(class_3610 a, class_3610 b) { return false; }

    @Inject(method = "shouldRenderSide", at = @At("HEAD"), cancellable = true)
    private static void modifyShouldRenderSide(class_3610 fluidState, class_2680 blockState, class_2350 direction, class_3610 fluidState2, CallbackInfoReturnable<Boolean> cir) {

        ShouldDrawSideEvent evt = new ShouldDrawSideEvent(blockState);

        EventManager.fireEvent(evt);

        if (evt.renderedSet) {
            cir.setReturnValue(evt.rendered && !isSameFluid(fluidState, fluidState2));
        }

    }

    @Inject(method = "method_3344", at = @At("HEAD"), cancellable = true)
    private static void modifyShouldRenderSide2(class_2350 direction, float f, class_2680 blockState, CallbackInfoReturnable<Boolean> cir) {

        ShouldDrawSideEvent evt = new ShouldDrawSideEvent(blockState);

        EventManager.fireEvent(evt);

        if (evt.renderedSet) {
            cir.setReturnValue(evt.rendered);
        }

    }

}
