package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.DeathEvent;
import net.minecraft.class_418;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_418.class)
public abstract class DeathScreenMixin {
    @Inject(at = @At(value = "TAIL"), method = "init")
    private void injected(CallbackInfo ci) {
        EventManager.fireEvent(new DeathEvent(ShadowClientMain.mc.field_1724 == null ? null : ShadowClientMain.mc.field_1724.method_19538()));
    }
}
