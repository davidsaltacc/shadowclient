package net.justacoder.shadowclient.mixin;

import net.minecraft.class_332;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_332.class)
public interface DrawContextAccessor {

    @Accessor("vertexConsumers")
    public class_4597.class_4598 getVertexConsumers();

}
