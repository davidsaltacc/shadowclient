package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_1937;
import net.minecraft.class_4076;
import net.minecraft.class_769;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_769.class)
public abstract class BuiltChunkStorageMixin {

    @Shadow @Final protected class_1937 world;
    @Shadow private class_4076 sectionPos;
    @Shadow private int viewDistance;

    @Inject(method = "isSectionWithinViewDistance", at = @At("HEAD"), cancellable = true)
    private void changeViewDistance(int sectionX, int sectionY, int sectionZ, CallbackInfoReturnable<Boolean> cir) {
        int spoofedViewDistance = ModuleManager.SpoofRenderDistanceModule.getDistanceChunks(viewDistance);
        if (sectionY >= world.method_32891() && sectionY <= this.world.method_31597()) {
            cir.setReturnValue(sectionX >= sectionPos.method_18674() - spoofedViewDistance && sectionX <= this.sectionPos.method_18674() + spoofedViewDistance && sectionZ >= this.sectionPos.method_18687() - spoofedViewDistance && sectionZ <= this.sectionPos.method_18687() + spoofedViewDistance);
        } else {
            cir.setReturnValue(false);
        }
    }

}
