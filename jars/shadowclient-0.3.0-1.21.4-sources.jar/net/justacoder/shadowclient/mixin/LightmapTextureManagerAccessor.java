package net.justacoder.shadowclient.mixin;

import net.minecraft.class_765;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_765.class)
public interface LightmapTextureManagerAccessor {

    @Accessor("dirty")
    public void markDirty(boolean dirty);

}
