package net.justacoder.shadowclient.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_4538;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_898.class)
public abstract class EntityRenderDispatcherMixin {

    @Shadow
    private static void renderShadow(class_4587 matrices, class_4597 vertexConsumers, class_10017 renderState, float opacity, float tickDelta, class_4538 world, float radius) {}

    @Redirect(method = "render(Lnet/minecraft/entity/Entity;DDDFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/EntityRenderer;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/EntityRenderDispatcher;renderShadow(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/render/entity/state/EntityRenderState;FFLnet/minecraft/world/WorldView;F)V"))
    private void onRenderShadow(class_4587 matrices, class_4597 vertexConsumers, class_10017 renderState, float opacity, float tickDelta, class_4538 world, float radius, @Local(argsOnly = true) class_1297 entity) {
        if (entity instanceof class_1542 && ModuleManager.FlatItemsModule.enabled) {
            return;
        }
        renderShadow(matrices, vertexConsumers, renderState, opacity, tickDelta, world, radius);
    }
}
