package net.justacoder.shadowclient.mixin;

import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_761.class)
public interface WorldRendererAccessor {
    @Accessor
    int getRenderedEntitiesCount();
}
