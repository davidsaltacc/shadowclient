package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.annotations.VersionDependentMixin;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.RenderEvent;
import net.justacoder.shadowclient.main.render.BufferBuilderProvider;
import net.justacoder.shadowclient.main.render.Renderer;
import net.justacoder.shadowclient.main.util.MixinSharedValues;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@VersionDependentMixin(mcVersionPredicate = "<1.21.4")
@Mixin(class_761.class)
public abstract class WorldRendererMixin_S_21_4 {

    @Inject(method = "render", at = @At("TAIL"))
    private void afterRender(class_9922 allocator, class_9779 tickCounter, boolean renderBlockOutline, class_4184 camera, class_757 gameRenderer, class_765 lightmapTextureManager, Matrix4f positionMatrix, Matrix4f projectionMatrix, CallbackInfo ci) {
        BufferBuilderProvider provider = BufferBuilderProvider.getInstance();
        EventManager.fireEvent(new RenderEvent(new Renderer(provider, MixinSharedValues.worldRendererStack, MixinSharedValues.worldRendererDelta)));
        provider.draw();
    }

}
