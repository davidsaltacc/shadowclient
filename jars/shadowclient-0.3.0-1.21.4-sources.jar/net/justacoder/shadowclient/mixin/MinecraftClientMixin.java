package net.justacoder.shadowclient.mixin;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.config.Config;
import net.justacoder.shadowclient.main.event.events.PerspectiveChangeEvent;
import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.ui.clickgui.MainClickGUI;
import net.justacoder.shadowclient.main.ui.font.Font;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_437;
import net.minecraft.class_542;
import net.minecraft.class_6683;
import net.minecraft.client.ClientBrandRetriever;
import net.justacoder.shadowclient.main.config.ShadowClientSettings;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.PostTickEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.modules.render.EntitiesESP;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {

    @Shadow @Final public class_315 options;
    @Shadow @Nullable public class_437 currentScreen;

    /**
     * @author ...
     * @reason ...
     */
    @Overwrite
    public static class_6683 getModStatus() {
        Setting setting = ShadowClientSettings.getSetting("VanillaSpoof");
        if (setting != null && ((BooleanSetting) setting).booleanValue()) {
            return new class_6683(class_6683.class_6684.field_35174, "Client jar signature and brand is untouched");
        }
        return class_6683.method_39031("vanilla", ClientBrandRetriever::getClientModName, "Client", class_310.class);
    }

    @Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;startMonitor(ZLnet/minecraft/util/TickDurationMonitor;)Lnet/minecraft/util/profiler/Profiler;", shift = At.Shift.AFTER))
    private void injectedPreTick(CallbackInfo ci) {
        if (((class_310) (Object) this).field_1687 != null) {
            EventManager.fireEvent(new PreTickEvent());
        }
    }

    @Inject(method = "run", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;endMonitor(ZLnet/minecraft/util/TickDurationMonitor;)V"))
    private void injectedPostTick(CallbackInfo ci) {
        if (((class_310) (Object) this).field_1687 != null) {
            EventManager.fireEvent(new PostTickEvent());
        }
    }

    @Inject(method = "hasOutline", at = @At(value = "HEAD"), cancellable = true)
    private void injected(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {

        EntitiesESP entitiesEspModule = ModuleManager.EntitiesESPModule;

        if (!entitiesEspModule.enabled) {
            cir.setReturnValue(cir.getReturnValue());
            return;
        }

        if (entity instanceof class_1657 && entitiesEspModule.drawPlayerEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1569 && entitiesEspModule.drawHostileEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1296 && entitiesEspModule.drawPassiveEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (entity instanceof class_1421 && entitiesEspModule.drawAmbientEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else if (!(entity instanceof class_1657) && !(entity instanceof class_1569) && !(entity instanceof class_1296) && !(entity instanceof class_1421) && entitiesEspModule.drawOtherEntityOutlines.booleanValue()) {
            cir.setReturnValue(true);
        } else {
            cir.setReturnValue(cir.getReturnValue());
        }

    }

    @Inject(method = "method_29338", at = @At("HEAD"))
    private void onInitFinished(CallbackInfo ci) {
        ModuleManager.getAllModules().forEach((n, m) -> m.postInit());
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;onFontOptionsChanged()V", shift = At.Shift.AFTER))
    private void initCustomFont(class_542 args, CallbackInfo ci) {
        ShadowClientMain.guiScaleOption = ShadowClientMain.mc.field_1690.method_42474();
        Font.initializeFont();
    }

    @Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/MinecraftClient;onWindowFocusChanged(Z)V", shift = At.Shift.AFTER))
    private void repositionFramesProperly(class_542 args, CallbackInfo ci) {
        if (!Config.configLoaded || Config.resetUi) {
            ShadowClientMain.clickGui.repositionFramesProperly();
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"))
    private void onScreenSet(class_437 screen, CallbackInfo ci) {
        if (currentScreen instanceof MainClickGUI && !(screen instanceof MainClickGUI)) {
            ShadowClientMain.mainClickGUIClosed();
        }
    }

    @Inject(method = "handleInputEvents", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/GameRenderer;onCameraEntitySet(Lnet/minecraft/entity/Entity;)V", shift = At.Shift.AFTER))
    private void afterCameraEntitySet(CallbackInfo ci) {
        EventManager.fireEvent(new PerspectiveChangeEvent());
    }

    @Redirect(method = "handleInputEvents", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/option/KeyBinding;wasPressed()Z", ordinal = 0))
    private boolean disallowPerspectiveChange(class_304 instance) {
        if (ModuleManager.FreecamModule.enabled) {
            return false;
        }
        return instance.method_1436();
    }

}
