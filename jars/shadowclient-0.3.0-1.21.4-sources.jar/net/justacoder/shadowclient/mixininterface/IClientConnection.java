package net.justacoder.shadowclient.mixininterface;

import io.netty.channel.ChannelHandlerContext;
import net.minecraft.class_2596;

public interface IClientConnection {

    void createEventsForIncoming(boolean create);
    void createEventsForOutgoing(boolean create);

    void invokeChannelRead0(ChannelHandlerContext channelHandlerContext, class_2596<?> packet) throws Exception;

}
