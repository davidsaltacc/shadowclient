package net.justacoder.shadowclient.main.module;

import net.justacoder.shadowclient.main.annotations.NoChatMessages;
import net.justacoder.shadowclient.main.annotations.NotKeybindable;
import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.annotations.OneClick;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.main.ui.clickgui.ModuleButton;
import net.minecraft.class_1074;
import net.minecraft.class_304;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    public final ModuleCategory category;
    public final String moduleName;
    public final String[] searchTags;
    public String friendlyName;
    public String description;

    public ModuleButton moduleButton = null;

    public class_304 keyBinding;
    public String keyBindingName;

    public boolean enabled;

    public List<Setting> getSettings() {
        return settings;
    }

    public void addSetting(Setting setting) {
        settings.add(setting);
    }

    public void addSettings(Setting...settings) {
        for (Setting setting : settings) {
            addSetting(setting);
        }
    }

    public final List<Setting> settings = new ArrayList<>();

    public final class_310 mc = class_310.method_1551();

    public Module(String name, ModuleCategory category, String[] searchTags) {
        this.moduleName = name;
        this.category = category;
        this.searchTags = searchTags;
        this.friendlyName = "";
        this.description = "";
    }

    public void setEnabled() {
        this.enabled = true;
        this.onEnable();
        if (this.getClass().isAnnotationPresent(OneClick.class)) {
            setDisabled();
        }
    }
    public void setDisabled() {
        this.enabled = false;
        this.onDisable();
    }

    public void setEnabled(boolean event) {
        if (event) {
            this.onEnable();
        }
        this.enabled = true;
    }
    public void setDisabled(boolean event) {
        if (event) {
            this.onDisable();
        }
        this.enabled = false;
    }

    public boolean showMessage = true;

    public void setEnabled(boolean event, boolean message) {
        if (event) {
            boolean msgOld = showMessage;
            showMessage = message;
            this.onEnable();
            showMessage = msgOld;
        }
        this.enabled = true;
    }
    public void setDisabled(boolean event, boolean message) {
        if (event) {
            boolean msgOld = showMessage;
            showMessage = message;
            this.onDisable();
            showMessage = msgOld;
        }
        this.enabled = false;
    }

    public void toggle() {
        if (enabled) {
            setDisabled();
            return;
        }
        setEnabled();
    }

    public void onEnable() {
        if (showMessage && !this.getClass().isAnnotationPresent(OneClick.class) && !this.getClass().isAnnotationPresent(NoChatMessages.class)) {
            ShadowClientMain.moduleToggleChatMessage(friendlyName, true);
        }
    }
    public void onDisable() {
        if (showMessage && !this.getClass().isAnnotationPresent(OneClick.class) && !this.getClass().isAnnotationPresent(NoChatMessages.class)) {
            ShadowClientMain.moduleToggleChatMessage(friendlyName, false);
        }
    }
    public void onEvent(Event event) {}

    public void postInit() {}

    public void reloadTranslations() {
        this.friendlyName = class_1074.method_4662("module.shadowclient." + this.moduleName);
        this.description = class_1074.method_4662("module.description.shadowclient." + this.moduleName);
        reloadKeybindTranslation();
    }

    public void reloadKeybindTranslation() {
        if (!this.getClass().isAnnotationPresent(NotKeybindable.class)) {
            this.keyBindingName = this.keyBinding.method_1415() ? class_1074.method_4662("name.shadowclient.none") : this.keyBinding.method_16007().getString();
        }
    }

}
