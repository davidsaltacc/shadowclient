package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.event.events.MouseClickedEvent;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.util.BypassUtils;
import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;

@EventListener({MouseClickedEvent.class})
public class ClickTP extends Module {

    public NumberSetting MAX_DISTANCE = new NumberSetting(new TranslatableString("setting.module.shadowclient.clicktp.distance"), 1, 100, 10, 2, MathUtils.Easing.EASE_IN_QUADRATIC);

    public ClickTP() {
        super("clicktp", ModuleCategory.MOVEMENT, new String[]{"clicktp", "click teleport"});

        addSetting(MAX_DISTANCE);
    }

    @Override
    public void onEvent(Event event) {

        if (mc.field_1724.method_6115()) {
            return;
        }
        if (mc.field_1724.method_6030() != class_1799.field_8037) {
            return;
        }

        class_239 hitResult = mc.field_1724.method_5745(MAX_DISTANCE.doubleValueEased(), 1 / 20f, false);
        class_2338 pos = ((class_3965) hitResult).method_17777();

        if (mc.field_1690.field_1867.method_1434() && mc.field_1690.field_1904.method_1433(((MouseClickedEvent) event).button) && hitResult.method_17783() == class_239.class_240.field_1332) {
            BypassUtils.sendFiveMovementPackets();
            mc.field_1724.method_33574(pos.method_46558());
        }

    }
}
