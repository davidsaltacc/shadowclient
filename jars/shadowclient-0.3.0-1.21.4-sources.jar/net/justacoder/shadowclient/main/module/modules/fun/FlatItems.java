package net.justacoder.shadowclient.main.module.modules.fun;

import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.minecraft.class_10039;
import net.minecraft.class_1657;
import net.minecraft.class_243;

public class FlatItems extends Module {

    public BooleanSetting FACE_PLAYER = new BooleanSetting("Items face you", false);

    public FlatItems() {
        super("flatitems", ModuleCategory.FUN, new String[]{"flat items", "item physics", "flatitems"});

        addSetting(FACE_PLAYER);
    }

    public float getItemAngle(class_10039 itemEntity, class_1657 playerEntity) {
        class_243 pPos = playerEntity.method_19538();
        double diffX = itemEntity.field_53325 - pPos.field_1352;
        double diffZ = itemEntity.field_53327 - pPos.field_1350;
        return (float) Math.atan2(diffZ, diffX) - (float) Math.PI / 2;
    }

    public boolean face() {
        return FACE_PLAYER.booleanValue();
    }
}
