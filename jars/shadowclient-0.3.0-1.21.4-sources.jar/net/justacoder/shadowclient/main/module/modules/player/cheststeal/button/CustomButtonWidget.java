package net.justacoder.shadowclient.main.module.modules.player.cheststeal.button;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;

public class CustomButtonWidget extends class_4185 { // just a custom button class to be able to disable rendering without mixins
    protected CustomButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress, class_7841 narrationSupplier) {
        super(x, y, width, height, message, onPress, narrationSupplier);
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        if (ModuleManager.ChestStealModule.enabled) {
            super.method_48579(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public void method_25306() {
        if (ModuleManager.ChestStealModule.enabled) {
            super.method_25306();
        }
    }

    public static CustomButtonWidget newButton(int x, int y, int width, int height, String text, class_4241 action) {
        return new CustomButtonWidget(x, y, width, height, class_2561.method_30163(text), action, field_40754);
    }
}
