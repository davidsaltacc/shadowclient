package net.justacoder.shadowclient.main.module.modules.player;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1268;

@EventListener({PreTickEvent.class})
@SearchTags({"automatically fish", "autofish", "auto fish", "fish", "auto fish hack"})
public class AutoFish extends Module {
    public AutoFish() {
        super("autofish", ModuleCategory.PLAYER);
    }


    public int recastRodCountdown = -1;

    @Override
    public void onEvent(Event event) {

        if (recastRodCountdown > 0) {
            recastRodCountdown--;
        }

        if (recastRodCountdown == 0 && this.enabled) {
            mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
            recastRodCountdown = -1;
        }

    }

    public void setRecastRodCountdown(int countdown) {
        recastRodCountdown = countdown;
    }
}
