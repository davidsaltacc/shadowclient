package net.justacoder.shadowclient.main.module.modules.player;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1661;

@EventListener({PreTickEvent.class})
@SearchTags({"hotbar cycle", "switch", "autohotbarcycle"})
public class AutoHotbarCycle extends Module {

    public AutoHotbarCycle() {
        super("autohotbarcycle", ModuleCategory.PLAYER);
    }

    @Override
    public void onEvent(Event event) {
        class_1661 inv = mc.field_1724.method_31548();

        if (inv.field_7545 == 8) {
            inv.field_7545 = 0;
            return;
        }
        inv.field_7545++;
    }
}
