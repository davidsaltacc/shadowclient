package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;

@EventListener({PreTickEvent.class})
public class AutoSwim extends Module {
    public AutoSwim() {
        super("autoswim", ModuleCategory.MOVEMENT, new String[]{"fish", "autoswim", "auto swim", "automatically swim", "easy swim"});
    }

    @Override
    public void onEvent(Event event) {

        if(mc.field_1724.field_5976 || mc.field_1724.method_5715()) {
            return;
        }

        if(!mc.field_1724.method_5799()) {
            return;
        }

        if(mc.field_1724.field_6250 > 0) {
            mc.field_1724.method_5728(true);
        }
    }
}
