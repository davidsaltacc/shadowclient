package net.justacoder.shadowclient.main.module.modules.world;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.util.MathUtils;

@DoNotSaveState
@SearchTags({"timer", "timer hack", "timerhack", "speedup", "speed up"})
public class Timer extends Module {

    public final NumberSetting MULTIPLIER = new NumberSetting("Multiplier", 0.1f, 10f, 2f, 1, MathUtils.Easing.EASE_IN_QUADRATIC);

    public Timer() {
        super("timer", ModuleCategory.WORLD);

        addSetting(MULTIPLIER);
    }

    public float getMultiplier() {
        return this.enabled ? MULTIPLIER.floatValue() : 1f;
    }
}
