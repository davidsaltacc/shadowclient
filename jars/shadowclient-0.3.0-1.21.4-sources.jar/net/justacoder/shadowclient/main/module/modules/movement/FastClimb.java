package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_243;

@EventListener({PreTickEvent.class})
@SearchTags({"fastclimb", "fast climbing", "climb fast", "speed climb"})
public class FastClimb extends Module {
    public FastClimb() {
        super("fastclimb", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEvent(Event event) {

        if (!mc.field_1724.method_6101() || !mc.field_1724.field_5976) {
            return;
        }

        if (mc.field_1724.field_3913.field_3905 == 0 && mc.field_1724.field_3913.field_3907 == 0 && mc.field_1724.method_18798().field_1351 <= 0) {
            return;
        }

        class_243 velocity = mc.field_1724.method_18798();
        mc.field_1724.method_18800(velocity.field_1352, 0.2872, velocity.field_1350);

    }
}
