package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.ClipAtLedgeEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.module.ModuleManager;

@EventListener({ClipAtLedgeEvent.class})
public class SafeWalk extends Module {
    public SafeWalk() {
        super("safewalk", ModuleCategory.MOVEMENT, new String[]{"safe walk", "safewalk", "auto sneak", "autosneak"});
    }

    @Override
    public void onEnable() {
        ModuleManager.StepUpModule.setDisabled(true, false); // incompatible
        super.onEnable();
    }

    @Override
    public void onEvent(Event event) {
        if (!(event instanceof ClipAtLedgeEvent evt)) {
            return;
        }

        if (mc.field_1724.method_5715()) {
            return;
        }

        evt.setClip();
    }
}
