package net.justacoder.shadowclient.main.module.modules.player;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1297;
import net.minecraft.class_1560;
import net.minecraft.class_2828;
import net.minecraft.class_3532;

@EventListener({PreTickEvent.class})
@SearchTags({"enderman look", "endermen magnet", "enderman", "look at enderman", "look", "magnet", "enderman magnet", "look at endermen"})
public class EndermanMagnet extends Module {

    public EndermanMagnet() {
        super("endermanlook", ModuleCategory.OTHER);

    }

    @Override
    public void onEvent(Event event) {

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1560 enderman)) {
                continue;
            }
            if (enderman.method_7028() || !enderman.method_5805() || !mc.field_1724.method_6057(enderman)) {
                continue;
            }
            double y = enderman.method_23320();
            double diffX = entity.method_23317() - mc.field_1724.method_23317();
            double diffY = y - (mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()));
            double diffZ = entity.method_23321() - mc.field_1724.method_23321();
            double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            mc.field_1724.field_3944.method_52787(new class_2828.class_2831(
                mc.field_1724.method_36454() + class_3532.method_15393((float) Math.toDegrees(Math.atan2(enderman.method_23321() - mc.field_1724.method_23321(), enderman.method_23317() - mc.field_1724.method_23317())) - 90f - mc.field_1724.method_36454()),
                mc.field_1724.method_36455() + class_3532.method_15393((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)) - mc.field_1724.method_36455()),
                mc.field_1724.method_24828(),
                mc.field_1724.field_5976
            ));
            break;
        }

    }

}
