package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

@EventListener({ PreTickEvent.class })
public class StepDown extends Module {

    public StepDown() {
        super("stepdown", ModuleCategory.MOVEMENT, new String[]{ "stepdown", "step down", "fastfall", "fast fall", "gravity" });

        addSetting(MAX_DISTANCE);
    }

    private static final NumberSetting MAX_DISTANCE = new NumberSetting(TranslatableString.of("setting.module.shadowclient.stepup.max_distance"), 1, 10, 1, 0);

    @Override
    public void onEvent(Event event) {

        if (mc.field_1724.method_24828() || mc.field_1724.method_5681() || mc.field_1724.method_6128() || mc.field_1724.field_5960 || mc.field_1724.method_31549().field_7479) {
            return;
        }

        if (mc.field_1724.method_18798().field_1351 > 0.1) {
            return;
        }

        class_3965 result0 = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_19538(), mc.field_1724.method_19538().method_1031(0, -MAX_DISTANCE.doubleValue(), 0), class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724));

        if (result0.method_17783() == class_239.class_240.field_1333) {
            return;
        }

        float mxD = (float) Math.floor(mc.field_1724.method_19538().field_1351 - result0.method_17784().field_1351 + 0.1);
        float mnD = mxD - 0.1f;

        class_3965 result = mc.field_1687.method_17742(new class_3959(mc.field_1724.method_19538().method_1031(0, -mnD, 0), mc.field_1724.method_19538().method_1031(0, -mxD, 0), class_3959.class_3960.field_17558, class_3959.class_242.field_1347, mc.field_1724));

        if (result.method_17783() != class_239.class_240.field_1333 && !result.method_17781() && mc.field_1687.method_18026(mc.field_1724.method_5829().method_989(0., result.method_17784().field_1351 - mc.field_1724.method_19538().field_1351, 0.))) {
            class_243 pos = result.method_17784();
            ShadowClientMain.mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), true, mc.field_1724.field_5976));
            ShadowClientMain.mc.method_1562().method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), (mc.field_1724.method_23318() + pos.field_1351) / 2, mc.field_1724.method_23321(), true, mc.field_1724.field_5976));
            mc.field_1724.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
            ShadowClientMain.mc.method_1562().method_52787(new class_2828.class_2829(pos.field_1352, pos.field_1351, pos.field_1350, true, mc.field_1724.field_5976));
        }

    }

}
