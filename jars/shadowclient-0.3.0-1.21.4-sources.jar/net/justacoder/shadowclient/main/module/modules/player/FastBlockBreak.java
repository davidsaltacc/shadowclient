package net.justacoder.shadowclient.main.module.modules.player;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

@DoNotSaveState
@EventListener({PreTickEvent.class})
public class FastBlockBreak extends Module {
    public FastBlockBreak() {
        super("fastbreak", ModuleCategory.PLAYER, new String[]{"fastblockbreak", "fastbreak", "fast block break", "fast break", "block break", "speed break"});
    }

    @Override
    public void onEvent(Event event) {
        if (!(event instanceof PreTickEvent)) {
            return;
        }

        class_1293 haste = mc.field_1724.method_6112(class_1294.field_5917);

        if (haste == null || haste.method_5578() <= 1) {
            mc.field_1724.method_26082(new class_1293(class_1294.field_5917, -1, 1, false, false, false), null);
        }
    }

    public void removeHaste() {
        class_1293 haste = mc.field_1724.method_6112(class_1294.field_5917);
        if (haste != null && !haste.method_5592()) {
            mc.field_1724.method_6016(class_1294.field_5917);
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 != null) {
            removeHaste();
        }
        super.onDisable();
    }
}
