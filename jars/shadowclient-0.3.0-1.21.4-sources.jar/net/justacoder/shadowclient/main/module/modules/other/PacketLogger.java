package net.justacoder.shadowclient.main.module.modules.other;

import net.justacoder.shadowclient.main.setting.SettingEnum;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.ui.notifications.push.PushNotification;
import net.justacoder.shadowclient.main.ui.notifications.push.PushNotificationManager;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PacketReceivedEvent;
import net.justacoder.shadowclient.main.event.events.PacketSentEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import net.justacoder.shadowclient.main.setting.settings.StringSetting;
import net.justacoder.shadowclient.main.util.ChatUtils;
import net.minecraft.class_2596;

@EventListener({PacketSentEvent.class, PacketReceivedEvent.class})
public class PacketLogger extends Module {

    public final EnumSetting<Mode> MODE = new EnumSetting<>(TranslatableString.of("setting.module.shadowclient.packetlogger.mode"), Mode.ALL);
    public final StringSetting FILTER = new StringSetting(TranslatableString.of("setting.module.shadowclient.packetlogger.filter"));
    public final EnumSetting<FMode> FMODE = new EnumSetting<>(TranslatableString.of("setting.module.shadowclient.packetlogger.filter_mode"), FMode.WHITELIST);

    public PacketLogger() {
        super("packetlogger", ModuleCategory.OTHER, new String[]{"packet logger", "packetlogger"});
        addSettings(MODE, FILTER, FMODE);
    }

    private static final TranslatableString SENT_TEXT = TranslatableString.of("name.shadowclient.module.packetlogger.sent");
    private static final TranslatableString RECEIVED_TEXT = TranslatableString.of("name.shadowclient.module.packetlogger.received");

    public String packetName(class_2596<?> cl) {
        return cl.method_65080().comp_2231().method_12832();
    }

    public boolean filter(String text) {
        if (text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.BLACKLIST) {
            return true;
        }
        return !text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.WHITELIST;
    }

    public void send(String text) {
        if (!FILTER.stringValue().isEmpty() && filter(text)) {
            return;
        }

        PushNotificationManager.addNotification(new PushNotification(text));
    }

    @Override
    public void onEvent(Event event) {
        if (MODE.getEnumValue() == Mode.ALL) {
            if (event instanceof PacketReceivedEvent evt) {
                send(RECEIVED_TEXT.getTranslation() + " " + packetName(evt.packet));
                return;
            }
            send(SENT_TEXT.getTranslation() + " " + packetName(((PacketSentEvent) event).packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.RECEIVED && event instanceof PacketReceivedEvent evt) {
            send(RECEIVED_TEXT.getTranslation() + " " + packetName(evt.packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.SENT && event instanceof PacketSentEvent evt) {
            send(SENT_TEXT.getTranslation() + " " + packetName(evt.packet));
        }
    }

    public enum Mode implements SettingEnum {
        ALL("name.settingenum.shadowclient.packetlogger.mode.all"),
        RECEIVED("name.settingenum.shadowclient.packetlogger.mode.received"),
        SENT("name.settingenum.shadowclient.packetlogger.mode.sent");


        private TranslatableString fullName;
        Mode(String key) {
            this.fullName = TranslatableString.of(key);
        }

        @Override
        public TranslatableString fullName() {
            return fullName;
        }
    }

    public enum FMode implements SettingEnum {
        BLACKLIST("name.settingenum.shadowclient.packetlogger.fmode.blacklist"),
        WHITELIST("name.settingenum.shadowclient.packetlogger.fmode.whitelist");


        private TranslatableString fullName;
        FMode(String key) {
            this.fullName = TranslatableString.of(key);
        }

        @Override
        public TranslatableString fullName() {
            return fullName;
        }
    }

}
