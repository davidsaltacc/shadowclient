package net.justacoder.shadowclient.main.module.modules.other;

import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.minecraft.*;
import net.minecraft.network.packet.c2s.common.*;
import net.minecraft.network.packet.c2s.play.*;
import net.minecraft.network.packet.s2c.common.*;
import net.minecraft.network.packet.s2c.config.*;
import net.minecraft.network.packet.s2c.login.*;
import net.minecraft.network.packet.s2c.play.*;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PacketReceivedEvent;
import net.justacoder.shadowclient.main.event.events.PacketSentEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import net.justacoder.shadowclient.main.setting.settings.StringSetting;
import net.justacoder.shadowclient.main.util.ChatUtils;

@EventListener({PacketSentEvent.class, PacketReceivedEvent.class})
public class PacketLogger extends Module {

    public final EnumSetting<Mode> MODE = new EnumSetting<>(new TranslatableString("setting.module.shadowclient.packetlogger.mode"), Mode.ALL);
    public final StringSetting FILTER = new StringSetting(new TranslatableString("setting.module.shadowclient.packetlogger.filter"));
    public final EnumSetting<FMode> FMODE = new EnumSetting<>(new TranslatableString("setting.module.shadowclient.packetlogger.filter_mode"), FMode.WHITELIST);

    public PacketLogger() {
        super("packetlogger", ModuleCategory.OTHER, new String[]{"packet logger", "packetlogger"});
        addSettings(MODE, FILTER, FMODE);
    }

    public String cleanClassName(class_2596<?> cl) {
        return translate(cl);
    }

    public boolean filter(String text) {
        if (text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.BLACKLIST) {
            return true;
        }
        return !text.toLowerCase().contains(FILTER.stringValue().toLowerCase()) && FMODE.getEnumValue() == FMode.WHITELIST;
    }

    public void send(String text) {
        if (!FILTER.stringValue().isEmpty()) {
            if (filter(text)) {
                return;
            }
        }
        ChatUtils.sendMessageClient(text);
    }

    @Override
    public void onEvent(Event event) {
        if (MODE.getEnumValue() == Mode.ALL) {
            if (event instanceof PacketReceivedEvent) {
                send(ChatUtils.Formattings.ITALIC + "RECEIVED " + ChatUtils.Formattings.RESET + cleanClassName(((PacketReceivedEvent) event).packet));
                return;
            }
            send(ChatUtils.Formattings.ITALIC + "SENT " + ChatUtils.Formattings.RESET + cleanClassName(((PacketSentEvent) event).packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.RECEIVED && event instanceof PacketReceivedEvent) {
            send(ChatUtils.Formattings.ITALIC + "RECEIVED " + ChatUtils.Formattings.RESET + cleanClassName(((PacketReceivedEvent) event).packet));
            return;
        }
        if (MODE.getEnumValue() == Mode.SENT && event instanceof PacketSentEvent) {
            send(ChatUtils.Formattings.ITALIC + "SENT " + ChatUtils.Formattings.RESET + cleanClassName(((PacketSentEvent) event).packet));
        }
    }

    public enum Mode {
        ALL("All"),
        RECEIVED("Received"),
        SENT("Sent");


        final String name;
        Mode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }

    public enum FMode {
        BLACKLIST("Blacklist"),
        WHITELIST("Whitelist");


        final String name;
        FMode(String name) {
            this.name = name;
        }

        @Override
        public String toString() {
            return this.name;
        }
    }

    public String translate(class_2596<?> in) {

        if (in instanceof class_2803) { return "common.ClientOptions"; }
        if (in instanceof class_6374) { return "common.CommonPong"; }
        if (in instanceof class_9091) { return "common.CookieResponse"; }
        if (in instanceof class_2817) { return "common.CustomPayload"; }
        if (in instanceof class_2827) { return "common.KeepAlive"; }
        if (in instanceof class_2856) { return "common.ResourcePackStatus"; }

        if (in instanceof class_8736) { return "config.Ready"; }
        if (in instanceof class_9220) { return "config.SelectKnownPacks"; }

        if (in instanceof class_2889) { return "handshake.Handshake"; }

        if (in instanceof class_8593) { return "login.EnterConfiguration"; }
        if (in instanceof class_2915) { return "login.LoginHello"; }
        if (in instanceof class_2917) { return "login.LoginKey"; }
        if (in instanceof class_2913) { return "login.LoginQueryResponse"; }

        if (in instanceof class_8590) { return "play.AcknowledgeChunks"; }
        if (in instanceof class_8591) { return "play.AcknowledgeReconfiguration"; }
        if (in instanceof class_2859) { return "play.AdvancementTab"; }
        if (in instanceof class_2836) { return "play.BoatPaddleState"; }
        if (in instanceof class_2820) { return "play.BookUpdate"; }
        if (in instanceof class_2811) { return "play.ButtonClick"; }
        if (in instanceof class_9449) { return "play.ChatCommandSigned"; }
        if (in instanceof class_2797) { return "play.ChatMessage"; }
        if (in instanceof class_2813) { return "play.ClickSlot"; }
        if (in instanceof class_2848) { return "play.ClientCommand"; }
        if (in instanceof class_2799) { return "play.ClientStatus"; }
        if (in instanceof class_2815) { return "play.CloseHandledScreen"; }
        if (in instanceof class_7472) { return "play.CommandExecution"; }
        if (in instanceof class_2840) { return "play.CraftRequest"; }
        if (in instanceof class_2873) { return "play.CreativeInventoryAction"; }
        if (in instanceof class_9179) { return "play.DebugSampleSubscription"; }
        if (in instanceof class_2879) { return "play.HandSwing"; }
        if (in instanceof class_5194) { return "play.JigsawGenerating"; }
        if (in instanceof class_7640) { return "play.MessageAcknowledgment"; }
        if (in instanceof class_2846) { return "play.PlayerAction"; }
        if (in instanceof class_2851) { return "play.PlayerInput"; }
        if (in instanceof class_2885) { return "play.PlayerInteractBlock"; }
        if (in instanceof class_2824) { return "play.PlayerInteractEntity"; }
        if (in instanceof class_2886) { return "play.PlayerInteractItem"; }
        if (in instanceof class_2828) { return "play.PlayerMove"; }
        if (in instanceof class_7861) { return "play.PlayerSession"; }
        if (in instanceof class_2795) { return "play.QueryBlockNbt"; }
        if (in instanceof class_2822) { return "play.QueryEntityNbt"; }
        if (in instanceof class_2853) { return "play.RecipeBookData"; }
        if (in instanceof class_5427) { return "play.RecipeCategoryOptions"; }
        if (in instanceof class_2855) { return "play.RenameItem"; }
        if (in instanceof class_2805) { return "play.RequestCommandCompletions"; }
        if (in instanceof class_2863) { return "play.SelectMerchantTrade"; }
        if (in instanceof class_8875) { return "play.SlotChangedState"; }
        if (in instanceof class_2884) { return "play.SpectatorTeleport"; }
        if (in instanceof class_2793) { return "play.TeleportConfirm"; }
        if (in instanceof class_2866) { return "play.UpdateBeacon"; }
        if (in instanceof class_2870) { return "play.UpdateCommandBlock"; }
        if (in instanceof class_2871) { return "play.UpdateCommandBlockMinecart"; }
        if (in instanceof class_4210) { return "play.UpdateDifficulty"; }
        if (in instanceof class_4211) { return "play.UpdateDifficultyLock"; }
        if (in instanceof class_3753) { return "play.UpdateJigsaw"; }
        if (in instanceof class_2842) { return "play.UpdatePlayerAbilities"; }
        if (in instanceof class_2868) { return "play.UpdateSelectedSlot"; }
        if (in instanceof class_2877) { return "play.UpdateSign"; }
        if (in instanceof class_2875) { return "play.UpdateStructureBlock"; }
        if (in instanceof class_2833) { return "play.VehicleMove"; }

        if (in instanceof class_2935) { return "query.QueryPing"; }
        if (in instanceof class_2937) { return "query.QueryRequest"; }

        if (in instanceof class_6373) { return "common.CommonPing"; }
        if (in instanceof class_9088) { return "common.CookieRequest"; }
        if (in instanceof class_2658) { return "common.CustomPayload"; }
        if (in instanceof class_9814) { return "common.CustomReportDetails"; }
        if (in instanceof class_2661) { return "common.Disconnect"; }
        if (in instanceof class_2670) { return "common.KeepAlive"; }
        if (in instanceof class_9053) { return "common.ResourcePackRemove"; }
        if (in instanceof class_2720) { return "common.ResourcePackSend"; }
        if (in instanceof class_9815) { return "common.ServerLinks"; }
        if (in instanceof class_9151) { return "common.ServerTransfer"; }
        if (in instanceof class_9150) { return "common.StoreCookie"; }
        if (in instanceof class_2790) { return "common.SynchronizeTags"; }

        if (in instanceof class_8734) { return "config.DynamicRegistries"; }
        if (in instanceof class_7832) { return "config.Features"; }
        if (in instanceof class_8733) { return "config.Ready"; }
        if (in instanceof class_9448) { return "config.ResetChat"; }
        if (in instanceof class_9250) { return "config.SelectKnownPacks"; }

        if (in instanceof class_2907) { return "login.LoginCompression"; }
        if (in instanceof class_2909) { return "login.LoginDisconnect"; }
        if (in instanceof class_2905) { return "login.LoginHello"; }
        if (in instanceof class_2899) { return "login.LoginQueryRequest"; }
        if (in instanceof class_2901) { return "login.LoginSuccess"; }

        if (in instanceof class_2779) { return "play.AdvancementUpdate"; }
        if (in instanceof class_2620) { return "play.BlockBreakingProgress"; }
        if (in instanceof class_2622) { return "play.BlockEntityUpdate"; }
        if (in instanceof class_2623) { return "play.BlockEvent"; }
        if (in instanceof class_2626) { return "play.BlockUpdate"; }
        if (in instanceof class_2629) { return "play.BossBar"; }
        if (in instanceof class_9093) { return "play.BundleDelimiter"; }
        if (in instanceof class_8042) { return "play.Bundle"; }
        if (in instanceof class_7438) { return "play.ChatMessage"; }
        if (in instanceof class_7597) { return "play.ChatSuggestions"; }
        if (in instanceof class_8212) { return "play.ChunkBiomeData"; }
        if (in instanceof class_2672) { return "play.ChunkData"; }
        if (in instanceof class_2637) { return "play.ChunkDeltaUpdate"; }
        if (in instanceof class_4273) { return "play.ChunkLoadDistance"; }
        if (in instanceof class_4282) { return "play.ChunkRenderDistanceCenter"; }
        if (in instanceof class_8738) { return "play.ChunkSent"; }
        if (in instanceof class_5888) { return "play.ClearTitles+"; }
        if (in instanceof class_2645) { return "play.CloseScreen"; }
        if (in instanceof class_2639) { return "play.CommandSuggestions"; }
        if (in instanceof class_2641) { return "play.CommandTree"; }
        if (in instanceof class_2656) { return "play.CooldownUpdate"; }
        if (in instanceof class_2695) { return "play.CraftFailedResponse"; }
        if (in instanceof class_8043) { return "play.DamageTilt"; }
        if (in instanceof class_5892) { return "play.DeathMessage"; }
        if (in instanceof class_9178) { return "play.DebugSample"; }
        if (in instanceof class_2632) { return "play.Difficulty"; }
        if (in instanceof class_5890) { return "play.EndCombat"; }
        if (in instanceof class_5891) { return "play.EnterCombat"; }
        if (in instanceof class_8588) { return "play.EnterReconfiguration"; }
        if (in instanceof class_2716) { return "play.EntitiesDestroy"; }
        if (in instanceof class_2616) { return "play.EntityAnimation"; }
        if (in instanceof class_2740) { return "play.EntityAttach"; }
        if (in instanceof class_2781) { return "play.EntityAttributes"; }
        if (in instanceof class_8143) { return "play.EntityDamage"; }
        if (in instanceof class_2744) { return "play.EntityEquipmentUpdate"; }
        if (in instanceof class_2752) { return "play.EntityPassengersSet"; }
        if (in instanceof class_2777) { return "play.EntityPosition"; }
        if (in instanceof class_2684) { return "play.Entity"; }
        if (in instanceof class_2726) { return "play.EntitySetHeadYaw"; }
        if (in instanceof class_2604) { return "play.EntitySpawn"; }
        if (in instanceof class_2783) { return "play.EntityStatusEffect"; }
        if (in instanceof class_2663) { return "play.EntityStatus"; }
        if (in instanceof class_2739) { return "play.EntityTrackerUpdate"; }
        if (in instanceof class_2743) { return "play.EntityVelocityUpdate"; }
        if (in instanceof class_2748) { return "play.ExperienceBarUpdate"; }
        if (in instanceof class_2606) { return "play.ExperienceOrbSpawn"; }
        if (in instanceof class_2664) { return "play.Explosion"; }
        if (in instanceof class_2678) { return "play.GameJoin"; }
        if (in instanceof class_7439) { return "play.GameMessage"; }
        if (in instanceof class_2668) { return "play.GameStateChange"; }
        if (in instanceof class_2749) { return "play.HealthUpdate"; }
        if (in instanceof class_2649) { return "play.Inventory"; }
        if (in instanceof class_2775) { return "play.ItemPickupAnimation"; }
        if (in instanceof class_2676) { return "play.LightUpdate"; }
        if (in instanceof class_2707) { return "play.LookAt"; }
        if (in instanceof class_2683) { return "play.MapUpdate"; }
        if (in instanceof class_2774) { return "play.NbtQueryResponse"; }
        if (in instanceof class_2648) { return "play.OpenHorseScreen"; }
        if (in instanceof class_3944) { return "play.OpenScreen"; }
        if (in instanceof class_3895) { return "play.OpenWrittenBook"; }
        if (in instanceof class_5894) { return "play.OverlayMessage"; }
        if (in instanceof class_2675) { return "play.Particle"; }
        if (in instanceof class_2696) { return "play.PlayerAbilities"; }
        if (in instanceof class_4463) { return "play.PlayerActionResponse"; }
        if (in instanceof class_2772) { return "play.PlayerListHeader"; }
        if (in instanceof class_2703) { return "play.PlayerList"; }
        if (in instanceof class_2708) { return "play.PlayerPositionLook"; }
        if (in instanceof class_7828) { return "play.PlayerRemove"; }
        if (in instanceof class_2724) { return "play.PlayerRespawn"; }
        if (in instanceof class_2759) { return "play.PlayerSpawnPosition"; }
        if (in instanceof class_2765) { return "play.PlaySoundFromEntity"; }
        if (in instanceof class_2767) { return "play.PlaySound"; }
        if (in instanceof class_7827) { return "play.ProfilelessChatMessageS2CPacket"; }
        if (in instanceof class_9632) { return "play.ProjectilePower"; }
        if (in instanceof class_2718) { return "play.RemoveEntityStatusEffect"; }
        if (in instanceof class_7617) { return "play.RemoveMessage"; }
        if (in instanceof class_2736) { return "play.ScoreboardDisplay"; }
        if (in instanceof class_2751) { return "play.ScoreboardObjectiveUpdate"; }
        if (in instanceof class_9006) { return "play.ScoreboardScoreReset"; }
        if (in instanceof class_2757) { return "play.ScoreboardScoreUpdate"; }
        if (in instanceof class_2651) { return "play.ScreenHandlerPropertyUpdate"; }
        if (in instanceof class_2653) { return "play.ScreenHandlerSlotUpdate"; }
        if (in instanceof class_2729) { return "play.SelectAdvancementTab"; }
        if (in instanceof class_7495) { return "play.ServerMetadata"; }
        if (in instanceof class_2734) { return "play.SetCameraEntity"; }
        if (in instanceof class_3943) { return "play.SetTradeOffers"; }
        if (in instanceof class_2693) { return "play.SignEditorOpen"; }
        if (in instanceof class_6682) { return "play.SimulationDistance"; }
        if (in instanceof class_8739) { return "play.StartChunkSend"; }
        if (in instanceof class_2617) { return "play.Statistics"; }
        if (in instanceof class_2770) { return "play.StopSound"; }
        if (in instanceof class_5903) { return "play.Subtitles"; }
        if (in instanceof class_2788) { return "play.SynchronizeRecipes"; }
        if (in instanceof class_5900) { return "play.Team"; }
        if (in instanceof class_8914) { return "play.TickStep"; }
        if (in instanceof class_5905) { return "play.TitleFade"; }
        if (in instanceof class_5904) { return "play.Title"; }
        if (in instanceof class_2666) { return "play.UnloadChunks"; }
        if (in instanceof class_2735) { return "play.UpdateSelectedSlot"; }
        if (in instanceof class_8913) { return "play.UpdateTickRate"; }
        if (in instanceof class_2692) { return "play.VehicleMove"; }
        if (in instanceof class_5895) { return "play.WorldBorderCenterChanged"; }
        if (in instanceof class_5889) { return "play.WorldBorderInitialize"; }
        if (in instanceof class_5896) { return "play.WorldBorderInterpolateSize"; }
        if (in instanceof class_5897) { return "play.WorldBorderSizeChanged"; }
        if (in instanceof class_5899) { return "play.WorldBorderWarningBlocksChanged"; }
        if (in instanceof class_5898) { return "play.WorldBorderWarningTimeChanged"; }
        if (in instanceof class_2673) { return "play.WorldEvent"; }
        if (in instanceof class_2761) { return "play.WorldTimeUpdate"; }

        if (in instanceof class_2923) { return "query.PingResult"; }
        if (in instanceof class_2924) { return "query.QueryResponse"; }

        return "??? Packet";

    }
}
