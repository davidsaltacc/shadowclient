package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_238;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.util.EntityUtils;

@EventListener({PreTickEvent.class})
public class Parkour extends Module {

    public final NumberSetting EDGE_DIST = new NumberSetting(TranslatableString.of("setting.module.shadowclient.parkour.edge_distance"), 0.001f, 0.25f, 0.001f, 3, MathUtils.Easing.EASE_IN_QUADRATIC);

    public Parkour() {
        super("parkour", ModuleCategory.MOVEMENT, new String[]{"parkour", "autojump", "auto jump", "auto parkour"});

        addSettings(EDGE_DIST);
    }

    @Override
    public void onEvent(Event event) {

        if (!mc.field_1724.method_24828() || mc.field_1690.field_1903.method_1434()) {
            return;
        }

        if (mc.field_1724.method_5715() || mc.field_1690.field_1832.method_1434()) {
            return;
        }

        class_238 box = mc.field_1724.method_5829();
        class_238 adjustedBox = box.method_1012(0, -0.5, 0).method_1009(-EDGE_DIST.floatValueEased(), 0, -EDGE_DIST.floatValueEased());

        if (!mc.field_1687.method_8587(mc.field_1724, adjustedBox)) {
            return;
        }

        mc.field_1724.method_6043();
        EntityUtils.setOnGround(mc.field_1724, false);

    }
}
