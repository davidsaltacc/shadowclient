package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.util.EntityCullingFix;
import net.justacoder.shadowclient.mixin.LightmapTextureManagerAccessor;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_7923;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.*;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

@DoNotSaveState
@EventListener({SetOpaqueCubeEvent.class, GetAmbientOcclusionLightLevelEvent.class, ShouldDrawSideEvent.class, RenderBlockEntityEvent.class})
public class Xray extends Module {

    public EnumSetting<Mode> MODE = new EnumSetting<>("Mode", Mode.All);

    public Xray() {
        super("xray", ModuleCategory.RENDER, new String[]{"xray", "x ray", "ore render", "mine help", "finder", "ore vision"});

        Collections.sort(Mode.All.blocks);
        Collections.sort(Mode.Ores.blocks);
        Collections.sort(Mode.Functional.blocks);
        Collections.sort(Mode.NaturallySpawning.blocks);

        addSetting(MODE);

        MODE.addChangeCallback((n, o) -> mc.field_1769.method_3279());
    }

    @Override
    public void onEvent(Event event) {
        if (event instanceof SetOpaqueCubeEvent) {
            event.cancel();
            return;
        }
        if (event instanceof GetAmbientOcclusionLightLevelEvent evt) {
            evt.setLightLevel(1);
            return;
        }
        if (event instanceof ShouldDrawSideEvent evt) {
            evt.setRendered(visible(evt.state.method_26204()));
            return;
        }
        if (event instanceof RenderBlockEntityEvent evt) {
            class_2338 pos = evt.blockEntity.method_11016();
            if (!visible(mc.field_1687.method_8320(pos).method_26204())) {
                event.cancel();
            }
        }
    }

    @Override
    public void onEnable() {
        if (mc.field_1773 == null) {
            return;
        }
        EntityCullingFix.disableCull();
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
        ((LightmapTextureManagerAccessor) mc.field_1773.method_22974()).markDirty(true);
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.field_1773 == null) {
            return;
        }
        EntityCullingFix.enableCull();
        if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
        }
        ((LightmapTextureManagerAccessor) mc.field_1773.method_22974()).markDirty(true);
        super.onDisable();
    }


    public boolean visible(class_2248 block) {
        if (MODE.getEnumValue() == Mode.No_GroundBlocks) {
            AtomicBoolean found = new AtomicBoolean(false);
            List.of("minecraft:dirt", "minecraft:stone", "minecraft:deepslate", "minecraft:netherrack", "minecraft:endstone", "minecraft:diorite", "minecraft:granite", "minecraft:andesite").forEach(stoneType -> {
                if (Objects.equals(class_7923.field_41175.method_10221(block).toString(), stoneType)) {
                    found.set(true);
                }
            });
            return !found.get();
        }
        return Collections.binarySearch(MODE.getEnumValue().blocks, class_7923.field_41175.method_10221(block).toString()) >= 0;
    }

    public enum Mode {
        All(
            new ArrayList<>(List.of(
                "minecraft:ancient_debris", "minecraft:chest",
                "minecraft:coal_block", "minecraft:coal_ore",
                "minecraft:copper_ore", "minecraft:deepslate_coal_ore",
                "minecraft:deepslate_copper_ore", "minecraft:deepslate_diamond_ore",
                "minecraft:deepslate_emerald_ore", "minecraft:deepslate_gold_ore",
                "minecraft:deepslate_iron_ore", "minecraft:deepslate_lapis_ore",
                "minecraft:deepslate_redstone_ore", "minecraft:diamond_block",
                "minecraft:diamond_ore", "minecraft:emerald_block", "minecraft:emerald_ore",
                "minecraft:glowstone", "minecraft:gold_block", "minecraft:gold_ore",
                "minecraft:iron_block", "minecraft:iron_ore", "minecraft:lapis_block",
                "minecraft:lapis_ore", "minecraft:nether_gold_ore", "minecraft:nether_portal",
                "minecraft:nether_quartz_ore", "minecraft:raw_copper_block",
                "minecraft:raw_gold_block", "minecraft:raw_iron_block", "minecraft:redstone_block",
                "minecraft:redstone_ore", "minecraft:suspicious_gravel",
                "minecraft:suspicious_sand", "minecraft:tnt", "minecraft:water", "minecraft:lava",
                "minecraft:brewing_stand", "minecraft:crafting_table", "minecraft:furnace",
                "minecraft:blast_furnace", "minecraft:smoker", "minecraft:anvil",
                "minecraft:chipped_anvil", "minecraft:damaged_anvil",
                "minecraft:sculk", "minecraft:sculk_sensor", "minecraft:sculk_shrieker",
                "minecraft:bell", "minecraft:beacon", "minecraft:end_portal_frame",
                "minecraft:enchanting_table", "minecraft:command_block",
                "minecraft:chain_command_block", "minecraft:repeating_command_block",
                "minecraft:item_frame", "minecraft:glow_item_frame",
                "minecraft:small_amethyst_bud", "minecraft:medium_amethyst_bud",
                "minecraft:large_amethyst_bud", "minecraft:amethyst_cluster",
                "minecraft:budding_amethyst", "minecraft:respawn_anchor",
                "minecraft:mossy_stone_bricks", "minecraft:spawner",
                "minecraft:mob_spawner", "minecraft:nether_bricks",
                "minecraft:obsidian", "minecraft:stone_bricks",
                "minecraft:cracked_stone_bricks", "minecraft:mossy_stone_bricks",
                "minecraft:chiseled_stone_bricks", "minecraft:infested_stone",
                "minecraft:infested_cobblestone", "minecraft:infested_stone_bricks",
                "minecraft:infested_cracked_stone_bricks", "minecraft:infested_mossy_stone_bricks",
                "minecraft:infested_chiseled_stone_bricks", "minecraft:infested_deepslate",
                "minecraft:oak_log", "minecraft:spruce_log", "minecraft:birch_log",
                "minecraft:jungle_log", "minecraft:acacia_log", "minecraft:dark_oak_log",
                "minecraft:mangrove_log", "minecraft:cherry_log", "minecraft:crimson_stem",
                "minecraft:warped_stem", "minecraft:oak_planks", "minecraft:spruce_planks",
                "minecraft:birch_planks", "minecraft:jungle_planks", "minecraft:acacia_planks",
                "minecraft:dark_oak_planks", "minecraft:mangrove_planks", "minecraft:cherry_planks",
                "minecraft:bamboo_planks", "minecraft:crimson_planks", "minecraft:warped_planks",
                "minecraft:bamboo", "minecraft:slime_block", "minecraft:glass", "minecraft:glass_pane",
                "minecraft:ladder", "minecraft:bed", "minecraft:white_bed", "minecraft:orange_bed",
                "minecraft:magenta_bed", "minecraft:light_blue_bed", "minecraft:yellow_bed",
                "minecraft:lime_bed", "minecraft:pink_bed", "minecraft:gray_bed",
                "minecraft:light_gray_bed", "minecraft:cyan_bed", "minecraft:purple_bed",
                "minecraft:blue_bed", "minecraft:brown_bed", "minecraft:green_bed",
                "minecraft:red_bed", "minecraft:black_bed"
            ))
        ), Ores(
            new ArrayList<>(List.of(
                "minecraft:ancient_debris", "minecraft:coal_block", "minecraft:coal_ore",
                "minecraft:copper_ore", "minecraft:deepslate_coal_ore",
                "minecraft:deepslate_copper_ore", "minecraft:deepslate_diamond_ore",
                "minecraft:deepslate_emerald_ore", "minecraft:deepslate_gold_ore",
                "minecraft:deepslate_iron_ore", "minecraft:deepslate_lapis_ore",
                "minecraft:deepslate_redstone_ore", "minecraft:diamond_block",
                "minecraft:diamond_ore", "minecraft:emerald_block", "minecraft:emerald_ore",
                "minecraft:gold_block", "minecraft:gold_ore",
                "minecraft:iron_block", "minecraft:iron_ore", "minecraft:lapis_block",
                "minecraft:lapis_ore", "minecraft:nether_gold_ore", "minecraft:nether_quartz_ore",
                "minecraft:raw_copper_block", "minecraft:raw_gold_block", "minecraft:raw_iron_block",
                "minecraft:redstone_block", "minecraft:redstone_ore", "minecraft:suspicious_gravel",
                "minecraft:suspicious_sand", "minecraft:lava", "minecraft:water"
            ))
        ), Functional(
            new ArrayList<>(List.of(
                "minecraft:chest", "minecraft:glowstone", "minecraft:nether_portal",
                "minecraft:tnt", "minecraft:water", "minecraft:lava",
                "minecraft:brewing_stand", "minecraft:crafting_table", "minecraft:furnace",
                "minecraft:blast_furnace", "minecraft:smoker", "minecraft:anvil",
                "minecraft:chipped_anvil", "minecraft:damaged_anvil",
                "minecraft:bell", "minecraft:beacon", "minecraft:end_portal_frame",
                "minecraft:enchanting_table", "minecraft:command_block",
                "minecraft:chain_command_block", "minecraft:repeating_command_block",
                "minecraft:item_frame", "minecraft:glow_item_frame", "minecraft:respawn_anchor",
                "minecraft:spawner", "minecraft:mob_spawner", "minecraft:slime_block",
                "minecraft:ladder", "minecraft:bed", "minecraft:white_bed", "minecraft:orange_bed",
                "minecraft:magenta_bed", "minecraft:light_blue_bed", "minecraft:yellow_bed",
                "minecraft:lime_bed", "minecraft:pink_bed", "minecraft:gray_bed",
                "minecraft:light_gray_bed", "minecraft:cyan_bed", "minecraft:purple_bed",
                "minecraft:blue_bed", "minecraft:brown_bed", "minecraft:green_bed",
                "minecraft:red_bed", "minecraft:black_bed"
            ))
        ), NaturallySpawning(
            new ArrayList<>(List.of(
                "minecraft:chest", "minecraft:glowstone", "minecraft:end_portal_frame",
                "minecraft:suspicious_gravel", "minecraft:suspicious_sand", "minecraft:anvil",
                "minecraft:chipped_anvil", "minecraft:damaged_anvil",
                "minecraft:sculk", "minecraft:sculk_sensor", "minecraft:sculk_shrieker",
                "minecraft:small_amethyst_bud", "minecraft:medium_amethyst_bud",
                "minecraft:large_amethyst_bud", "minecraft:amethyst_cluster",
                "minecraft:budding_amethyst", "minecraft:mossy_stone_bricks", "minecraft:spawner",
                "minecraft:mob_spawner", "minecraft:nether_bricks", "minecraft:obsidian", "minecraft:stone_bricks",
                "minecraft:cracked_stone_bricks", "minecraft:mossy_stone_bricks",
                "minecraft:chiseled_stone_bricks", "minecraft:infested_stone",
                "minecraft:infested_cobblestone", "minecraft:infested_stone_bricks",
                "minecraft:infested_cracked_stone_bricks", "minecraft:infested_mossy_stone_bricks",
                "minecraft:infested_chiseled_stone_bricks", "minecraft:infested_deepslate",
                "minecraft:oak_log", "minecraft:spruce_log", "minecraft:birch_log",
                "minecraft:jungle_log", "minecraft:acacia_log", "minecraft:dark_oak_log",
                "minecraft:mangrove_log", "minecraft:cherry_log", "minecraft:crimson_stem",
                "minecraft:warped_stem", "minecraft:oak_planks", "minecraft:spruce_planks",
                "minecraft:birch_planks", "minecraft:jungle_planks", "minecraft:acacia_planks",
                "minecraft:dark_oak_planks", "minecraft:glass", "minecraft:glass_pane",
                "minecraft:ladder", "minecraft:bed", "minecraft:white_bed", "minecraft:orange_bed",
                "minecraft:magenta_bed", "minecraft:light_blue_bed", "minecraft:yellow_bed",
                "minecraft:lime_bed", "minecraft:pink_bed", "minecraft:gray_bed",
                "minecraft:light_gray_bed", "minecraft:cyan_bed", "minecraft:purple_bed",
                "minecraft:blue_bed", "minecraft:brown_bed", "minecraft:green_bed",
                "minecraft:red_bed", "minecraft:black_bed"
            ))
        ),
        No_GroundBlocks(
            new ArrayList<>()
        );

        public final List<String> blocks;

        Mode(List<String> blocks) {
            this.blocks = blocks;
        }
    }
}
