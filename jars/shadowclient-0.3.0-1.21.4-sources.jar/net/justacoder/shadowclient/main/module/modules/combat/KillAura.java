package net.justacoder.shadowclient.main.module.modules.combat;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.util.RotationUtils;
import net.justacoder.shadowclient.main.util.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_465;

@EventListener({PreTickEvent.class})
public class KillAura extends Module {

    public final BooleanSetting LEGIT = new BooleanSetting("Legit", true);

    public KillAura() {
        super("killaura", ModuleCategory.COMBAT, new String[]{"killaura", "kill aura", "auto kill", "auto hit"});
        addSetting(LEGIT);
    }

    @Override
    public void onEvent(Event event) {

        mc.field_1687.method_18112().forEach(entity -> {
            if (entity == mc.field_1724) {
                return;
            }
            if (entity instanceof class_1309) {
                if (mc.field_1724.method_5739(entity) <= 6.2173613f) {
                    if (entity.method_5805()) {
                        if (LEGIT.booleanValue()) {
                            if (WorldUtils.lineOfSight(mc.field_1724, entity) && !(mc.field_1755 instanceof class_465<?>)) {
                                RotationUtils.rotatePlayerToVec3d(entity.method_19538());
                                mc.field_1761.method_2918(mc.field_1724, entity);
                                mc.field_1724.method_6104(class_1268.field_5808);
                            }
                        } else {
                            mc.field_1761.method_2918(mc.field_1724, entity);
                            mc.field_1724.method_6104(class_1268.field_5808);
                        }
                    }
                }
            }
        });
    }
}
