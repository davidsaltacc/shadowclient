package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.util.EntityCullingFix;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;

@DoNotSaveState
public class EntitiesESP extends Module {

    public final BooleanSetting drawPlayerEntityOutlines = new BooleanSetting("Players", true);
    public final BooleanSetting drawHostileEntityOutlines = new BooleanSetting("Hostiles", true);
    public final BooleanSetting drawPassiveEntityOutlines = new BooleanSetting("Passives", false);
    public final BooleanSetting drawOtherEntityOutlines = new BooleanSetting("Others", false);
    public final BooleanSetting drawAmbientEntityOutlines = new BooleanSetting("Ambient", true);

    public EntitiesESP() {
        super("entitiesesp", ModuleCategory.RENDER, new String[]{"entitiesesp", "esp", "entity esp", "entities esp", "wallhack", "wall hack"});

        addSettings(drawPlayerEntityOutlines, drawHostileEntityOutlines, drawPassiveEntityOutlines, drawOtherEntityOutlines, drawAmbientEntityOutlines);
    }

    public int[] getColor(class_1297 entity) {
        int[] color;
        if (entity instanceof class_1657) {
            color = new int[]{255, 0, 0};
        } else if (entity instanceof class_1569) {
            color = new int[]{255, 127, 0};
        } else if (entity instanceof class_1296) {
            color = new int[]{0, 255, 0};
        } else if (entity instanceof class_1421) {
            color = new int[]{0, 0, 255};
        } else {
            color = new int[]{0, 255, 255};
        }
        return color;
    }

    @Override
    public void onEnable() {

        EntityCullingFix.disableCull();

        super.onEnable();
    }

    @Override
    public void onDisable() {

        EntityCullingFix.enableCull();

        super.onDisable();
    }
}
