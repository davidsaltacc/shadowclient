package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.util.EntityCullingFix;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;

@DoNotSaveState
@SearchTags({"entitiesesp", "esp", "entity esp", "entities esp", "wallhack", "wall hack"})
public class EntitiesESP extends Module {

    public final BooleanSetting DrawPlayerEntityOutlines = new BooleanSetting("Players", true);
    public final BooleanSetting DrawHostileEntityOutlines = new BooleanSetting("Hostiles", true);
    public final BooleanSetting DrawPassiveEntityOutlines = new BooleanSetting("Passives", false);
    public final BooleanSetting DrawOtherEntityOutlines = new BooleanSetting("Others", false);
    public final BooleanSetting DrawAmbientEntityOutlines = new BooleanSetting("Ambient", true);

    public EntitiesESP() {
        super("entitiesesp", ModuleCategory.RENDER);

        addSettings(DrawPlayerEntityOutlines, DrawHostileEntityOutlines, DrawPassiveEntityOutlines, DrawOtherEntityOutlines, DrawAmbientEntityOutlines);
    }

    public int[] getColor(class_1297 entity) {
        int[] color;
        if (entity instanceof class_1657) {
            color = new int[]{255, 0, 0};
        } else if (entity instanceof class_1569) {
            color = new int[]{255, 127, 0};
        } else if (entity instanceof class_1296) {
            color = new int[]{0, 255, 0};
        } else if (entity instanceof class_1421) {
            color = new int[]{0, 0, 255};
        } else {
            color = new int[]{0, 255, 255};
        }
        return color;
    }

    @Override
    public void onEnable() {

        EntityCullingFix.disableCull();

        super.onEnable();
    }

    @Override
    public void onDisable() {

        EntityCullingFix.enableCull();

        super.onDisable();
    }
}
