package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;

@EventListener({PreTickEvent.class})
public class Fly extends Module {
    private int toggle = 0;
    private double acceleration = 0.2;

    public final NumberSetting SPEED = new NumberSetting("Speed", 0.1f, 5f, 1f, 1, MathUtils.Easing.EASE_IN_QUADRATIC);

    public Fly() {
        super("fly", ModuleCategory.MOVEMENT, new String[]{"flyhack", "fly", "flying"});

        addSetting(SPEED);
    }

    @Override
    public void onEvent(Event event) {
        if (mc.field_1724.method_24828()) {
            acceleration = 0.2;
            return;
        }

        boolean jumpPressed = mc.field_1690.field_1903.method_1434();
        boolean forwardPressed = mc.field_1690.field_1903.method_1434();
        boolean leftPressed = mc.field_1690.field_1903.method_1434();
        boolean rightPressed = mc.field_1690.field_1903.method_1434();
        boolean backPressed = mc.field_1690.field_1903.method_1434();

        class_1297 entity = mc.field_1724.method_5765() ? mc.field_1724.method_5854() : mc.field_1724;

        class_243 vel = entity.method_18798();
        class_243 newvel = new class_243(vel.field_1352, -0.04, vel.field_1350);

        if (jumpPressed) {
            if (forwardPressed) {
                newvel = mc.field_1724.method_5720().method_1021(acceleration);
            }
            if (leftPressed && !mc.field_1724.method_5765()) {
                newvel = mc.field_1724.method_5720().method_1021(acceleration).method_1024(3.1415927f / 2);
                newvel = new class_243(newvel.field_1352, 0, newvel.field_1350);
            }
            if (rightPressed && !mc.field_1724.method_5765()) {
                newvel = mc.field_1724.method_5720().method_1021(acceleration).method_1024(-3.1415927f / 2);
                newvel = new class_243(newvel.field_1352, 0, newvel.field_1350);
            }
            if (backPressed) {
                newvel = mc.field_1724.method_5720().method_22882().method_1021(acceleration);
            }

            newvel = new class_243(newvel.field_1352, (toggle == 0 && newvel.field_1351 > 0.04) ? 0.04 : newvel.field_1351, newvel.field_1350);
            newvel = newvel.method_1021(-1);
            entity.method_18799(newvel);

            if (forwardPressed || leftPressed || rightPressed || backPressed) {
                if (acceleration < SPEED.floatValueEased()) {
                    acceleration += 0.1;
                }
            } else if (acceleration > 0.2) {
                acceleration -= 0.2;
            }

        }

        if (toggle == 0 || newvel.field_1351 <= -0.04) {
            toggle = 40;
        }
        toggle -= 1;

    }
}
