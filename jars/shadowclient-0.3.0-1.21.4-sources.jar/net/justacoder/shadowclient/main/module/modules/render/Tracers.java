package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.setting.settings.ColorSetting;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.setting.settings.PaddingSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.util.ColorUtils;
import net.justacoder.shadowclient.main.util.RotationUtils;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.RenderEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import org.joml.Quaternionf;

@EventListener({RenderEvent.class})
public class Tracers extends Module {

    public final BooleanSetting drawPlayerEntityTracers = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.players"), true);
    public final BooleanSetting drawHostileEntityTracers = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.hostiles"), false);
    public final BooleanSetting drawPassiveEntityTracers = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.passives"), false);
    public final BooleanSetting drawAmbientEntityTracers = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.ambients"), false);
    public final BooleanSetting drawOtherEntityTracers = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.others"), true);

    public final ColorSetting playerTracerColor = new ColorSetting(new TranslatableString("setting.module.shadowclient.tracers.players_color"), -65536);
    public final ColorSetting hostileTracerColor = new ColorSetting(new TranslatableString("setting.module.shadowclient.tracers.hostiles_color"), -33024);
    public final ColorSetting passiveTracerColor = new ColorSetting(new TranslatableString("setting.module.shadowclient.tracers.passives_color"), -16711936);
    public final ColorSetting ambientTracerColor = new ColorSetting(new TranslatableString("setting.module.shadowclient.tracers.ambients_color"), -16776999);
    public final ColorSetting otherTracerColor = new ColorSetting(new TranslatableString("setting.module.shadowclient.tracers.others_color"), -16711681);

    public final BooleanSetting drawNames = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.show_names"), true);
    public final BooleanSetting drawDistance = new BooleanSetting(new TranslatableString("setting.module.shadowclient.tracers.show_distance"), true);

    public final NumberSetting startDistance = new NumberSetting(new TranslatableString("setting.module.shadowclient.tracers.text_distance"), 0.1, 20, 2, 1);

    public Tracers() {
        super("tracers", ModuleCategory.RENDER, new String[]{"tracers", "lines", "entity tracers", "esp"});

        addSettings(
                drawPlayerEntityTracers, drawHostileEntityTracers, drawPassiveEntityTracers, drawAmbientEntityTracers, drawOtherEntityTracers,
                new PaddingSetting(),
                playerTracerColor, hostileTracerColor, passiveTracerColor, ambientTracerColor, otherTracerColor,
                new PaddingSetting(),
                drawNames, drawDistance, startDistance
        );
    }

    public float[] getColor(class_1297 entity) {
        return switch (entity) {
            case PlayerEntity ignored -> ColorUtils.int2RGBAfloat(playerTracerColor.colorValue());
            case Monster ignored -> ColorUtils.int2RGBAfloat(hostileTracerColor.colorValue());
            case PassiveEntity ignored -> ColorUtils.int2RGBAfloat(passiveTracerColor.colorValue());
            case AmbientEntity ignored -> ColorUtils.int2RGBAfloat(ambientTracerColor.colorValue());
            case null, default -> ColorUtils.int2RGBAfloat(otherTracerColor.colorValue());
        };
    }

    @Override
    public void onEvent(Event event) {

        RenderEvent evt = (RenderEvent) event;

        class_243 tracerStart = new class_243(0, 0, startDistance.floatValueEased()).method_1037(-(float) Math.toRadians(mc.field_1773.method_19418().method_19329())).method_1024(-(float) Math.toRadians(mc.field_1773.method_19418().method_19330())).method_1019(mc.field_1773.method_19418().method_19326());

        for (class_1297 entity : mc.field_1687.method_18112()) {

            if (
                    (entity == mc.field_1724 && !ModuleManager.FreecamModule.enabled) ||
                    (ModuleManager.FreecamModule.enabled && entity == ModuleManager.FreecamModule.getFreecamEntity())
            ) {
                continue;
            }

            if (entity instanceof class_1657 && !drawPlayerEntityTracers.booleanValue()) { continue;
            } else if (entity instanceof class_1569 && !drawHostileEntityTracers.booleanValue()) { continue;
            } else if (entity instanceof class_1296 && !drawPassiveEntityTracers.booleanValue()) { continue;
            } else if (entity instanceof class_1421 && !drawAmbientEntityTracers.booleanValue()) { continue;
            } else if (
                    !(entity instanceof class_1657) && !(entity instanceof class_1569) && !(entity instanceof class_1296) && !(entity instanceof class_1421) &&
                    !drawOtherEntityTracers.booleanValue()) { continue;
            }

            float[] col = getColor(entity);

            class_243 vec = entity.method_19538().method_1020(evt.renderer.getInterpolationOffset(entity));

            evt.renderer.drawLine(tracerStart.field_1352, tracerStart.field_1351, tracerStart.field_1350, vec.field_1352, vec.field_1351, vec.field_1350, col, false);
            evt.renderer.drawLine(vec.field_1352, vec.field_1351, vec.field_1350, vec.field_1352, vec.field_1351 + entity.method_17682(), vec.field_1350, col, false);

            if (drawNames.booleanValue() || drawDistance.booleanValue()) {

                class_243 diff = vec.method_1020(tracerStart);
                class_243 pointOnTracer = tracerStart.method_1019(diff.method_1029().method_1021(Math.min(diff.method_1033() / 20, 1)));
                class_243 textPos = pointOnTracer.method_1031(0, (pointOnTracer.field_1351 - tracerStart.field_1351) < 0 ? 0.1 : -0.1, 0);

                evt.renderer.drawLine(pointOnTracer.field_1352, pointOnTracer.field_1351, pointOnTracer.field_1350, textPos.field_1352, textPos.field_1351, textPos.field_1350, col, false);

                float[] textRot = RotationUtils.rotationAwayF(textPos, mc.field_1773.method_19418().method_19326());

                float offsetY = (pointOnTracer.field_1351 - tracerStart.field_1351) < 0 ? (-evt.renderer.getTextHeight() * (drawNames.booleanValue() && drawDistance.booleanValue() ? 2 : 1) - 1f) : 1f;

                if (drawNames.booleanValue()) {
                    String name = entity.method_5477().getString();
                    evt.renderer.drawText(name, textPos.field_1352, textPos.field_1351, textPos.field_1350, new Quaternionf().rotationYXZ(-(float) Math.toRadians(textRot[0]), (float) Math.toRadians(textRot[1]), 0f), -1, -evt.renderer.getTextWidth(name) / 2f, offsetY);
                    offsetY += evt.renderer.getTextHeight();
                }

                if (drawDistance.booleanValue()) {
                    String distance = (int) Math.floor(mc.field_1724.method_19538().method_1022(entity.method_19538())) + "m";
                    evt.renderer.drawText(distance, textPos.field_1352, textPos.field_1351, textPos.field_1350, new Quaternionf().rotationYXZ(-(float) Math.toRadians(textRot[0]), (float) Math.toRadians(textRot[1]), 0f), -1, -evt.renderer.getTextWidth(distance) / 2f, offsetY);
                    offsetY += evt.renderer.getTextHeight();
                }

            }

        }

        // TODO make something like a facePlayer thing (much easier in the future)

    }

}
