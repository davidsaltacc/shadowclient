package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;

public class PowderSnowWalk extends Module {
    public PowderSnowWalk() {
        super("powdersnowwalk", ModuleCategory.MOVEMENT, new String[]{"snow walk", "powder snow walk", "leather boots walk", "anti snow sink", "no snow sinking", "snowwalk"});
    }
}
