package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;

@EventListener({PreTickEvent.class})
public class BoatFly extends Module {

    NumberSetting SPEED = new NumberSetting("Speed", 0.02f, 10, 0.4,  2, MathUtils.Easing.EASE_IN_QUADRATIC);

    public BoatFly() {
        super("boatfly", ModuleCategory.MOVEMENT, new String[]{"boat fly", "boatfly", "fly hack", "flyhack"});

        addSetting(SPEED);
    }

    @Override
    public void onEvent(Event event) {
        if (!mc.field_1724.method_5765()) {
            return;
        }

        float speed = SPEED.floatValueEased();

        class_1297 entity = mc.field_1724.method_5854();
        class_243 vel = entity.method_18798();
        double x = vel.field_1352;
        double y = 0;
        double z = vel.field_1350;
        if (mc.field_1690.field_1903.method_1434()) {
            y = speed;
        } else if (mc.field_1690.field_1867.method_1434()) {
            y = vel.field_1351;
        }

        if (mc.field_1690.field_1894.method_1434()) {
            float yr = entity.method_36454() * class_3532.field_29847;

            x = class_3532.method_15374(-yr) * speed;
            z = class_3532.method_15362(yr) * speed;
        }

        entity.method_18800(x, y, z);
    }
}
