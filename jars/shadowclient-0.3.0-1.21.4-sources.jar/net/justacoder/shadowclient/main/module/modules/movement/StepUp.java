package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.minecraft.class_5134;

@EventListener({PreTickEvent.class})
public class StepUp extends Module {

    public final NumberSetting HEIGHT = new NumberSetting("Height", 1, 10, 1, 0);

    public StepUp() {
        super("stepup", ModuleCategory.MOVEMENT, new String[]{"stepup", "step up", "step"});

        addSetting(HEIGHT);
    }

    public void setStepHeight(float height) {
        mc.field_1724.method_6127().method_45329(class_5134.field_47761).method_6192(height);
    }

    @Override
    public void onEvent(Event event) {

        mc.field_1724.method_5857(mc.field_1724.method_5829().method_989(0, HEIGHT.floatValueEased(), 0));
        setStepHeight(HEIGHT.floatValueEased());
        mc.field_1724.method_5857(mc.field_1724.method_5829().method_989(0, -HEIGHT.floatValueEased(), 0));

    }

    @Override
    public void onEnable() {
        ModuleManager.SafeWalkModule.setDisabled(true, false); // incompatible
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 != null) {
            setStepHeight(0.6f);
        }
        super.onDisable();
    }
}
