package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

public class HideShield extends Module {

    public HideShield() {
        super("hideshield", ModuleCategory.RENDER, new String[]{"lower shield", "lowershield", "hideshield", "low shield", "no shield", "hide shield", "lowshield", "hidden shield"});
    }

    public static void processItem(class_1799 item, class_742 player, CallbackInfo ci) {

        if (item.method_7909() instanceof class_1819 && player.method_6014() <= 0) {
            ci.cancel();
        }

    }
}
