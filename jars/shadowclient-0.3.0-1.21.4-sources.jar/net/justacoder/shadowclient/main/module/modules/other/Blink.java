package net.justacoder.shadowclient.main.module.modules.other;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.event.events.PacketSentEvent;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PacketReceivedEvent;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.mixininterface.IClientConnection;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

@EventListener({PacketReceivedEvent.class, PacketSentEvent.class, PreTickEvent.class})
@DoNotSaveState
public class Blink extends Module {

    public Blink() {
        super("blink", ModuleCategory.OTHER, new String[]{"blink", "lagging"});
        addSetting(DELAY);
    }

    private long lastBlink;

    private final NumberSetting DELAY = new NumberSetting(new TranslatableString("setting.module.shadowclient.blink.delay"), 0.1, 2, 2, 1);

    private final Queue<class_2596<?>> outgoingPacketQueue = new ConcurrentLinkedQueue<>();

    @Override
    public void onEvent(Event event) {
        if (event instanceof PacketSentEvent evt && evt.packet instanceof class_2828) {
            outgoingPacketQueue.add(evt.packet);
            evt.cancel();
        }
        if (event instanceof PreTickEvent && System.currentTimeMillis() - lastBlink > DELAY.longValue() * 1000) {
            processQueuedPackets();
            lastBlink = System.currentTimeMillis();
        }
    }

    @Override
    public boolean onDisable() {
        if (mc.field_1687 != null) {
            processQueuedPackets();
        }
        return super.onDisable();
    }

    @Override
    public boolean onEnable() {
        lastBlink = System.currentTimeMillis();
        return super.onEnable();
    }

    @SuppressWarnings("unchecked")
    private <T extends class_2547> void processQueuedPackets() {

        ((IClientConnection) mc.field_1724.field_3944.method_48296()).createEventsForOutgoing(false);
        while (!outgoingPacketQueue.isEmpty()) {
            class_2596<T> packet = (class_2596<T>) outgoingPacketQueue.poll();
            try {
                mc.field_1724.field_3944.method_48296().method_10743(packet);
            } catch (Exception ignored) {}
        }
        ((IClientConnection) mc.field_1724.field_3944.method_48296()).createEventsForOutgoing(true);

    }

}
