package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.*;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.util.ChatUtils;
import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_243;
import net.minecraft.class_5498;
import net.minecraft.class_6335;

@DoNotSaveState
@EventListener({DamageEvent.class, PreTickEvent.class, MouseClickedEvent.class, MouseMoveEvent.class})
public class Freecam extends Module {

    public NumberSetting SPEED = new NumberSetting("Speed", 0.05f, 8, 1, 2, MathUtils.Easing.EASE_IN_QUADRATIC);

    public Freecam() {
        super("freecam", ModuleCategory.RENDER, new String[]{"freecam", "camera fly", "free cam"});
        addSetting(SPEED);
    }

    private class_1297 freecamEntity = null;

    @Override
    public void onEnable() {

        if (mc.field_1724 == null) {
            return;
        }

        mc.field_1690.method_31043(class_5498.field_26664);

        freecamEntity = new class_6335(class_1299.field_33456, mc.field_1687); // marker entity is the closest thing to an "empty" entity
        freecamEntity.method_33574(mc.field_1724.method_19538().method_1019(new class_243(0, mc.field_1724.method_17682() + 1f, 0)));
        freecamEntity.method_36456(mc.field_1724.method_36454());
        freecamEntity.method_36456(mc.field_1724.method_36455());
        freecamEntity.method_22862();

        mc.method_1504(freecamEntity);

        super.onEnable();
    }

    @Override
    public void onDisable() {

        if (freecamEntity == null) {
            return;
        }

        freecamEntity.method_5650(class_1297.class_5529.field_26999);
        freecamEntity = null;

        mc.method_1504(mc.field_1724);

        super.onDisable();
    }

    @Override
    public void onEvent(Event event) {

        if (event instanceof DamageEvent) {
            setDisabled(true, false);
            ChatUtils.sendMessageClient("Toggled freecam because you took damage.");
        }

        if (event instanceof MouseClickedEvent && mc.field_1755 == null) {
            event.cancel();
        }

        if (event instanceof PreTickEvent) {

            float directionLR = 0f;
            float directionFB = 0f;
            float directionUD = 0f;

            if (mc.field_1690.field_1894.method_1434()) { directionFB += 1; }
            if (mc.field_1690.field_1881.method_1434()) { directionFB -= 1; }
            if (mc.field_1690.field_1913.method_1434()) { directionLR += 1; }
            if (mc.field_1690.field_1849.method_1434()) { directionLR -= 1; }
            if (mc.field_1690.field_1903.method_1434()) { directionUD += 1; }
            if (mc.field_1690.field_1832.method_1434()) { directionUD -= 1; }

            if (directionLR != 0f || directionFB != 0f || directionUD != 0f) {
                freecamEntity.method_33574(freecamEntity.method_19538().method_1019(new class_243(directionLR, directionUD, directionFB).method_1024((float) Math.toRadians(-freecamEntity.method_36454())).method_1029().method_1021(SPEED.floatValueEased() * (mc.field_1690.field_1867.method_1434() ? 4 : 1))));
                freecamEntity.method_22862();
            }

        }

        if (event instanceof MouseMoveEvent evt) {

            freecamEntity.method_36456(freecamEntity.method_36454() + (float) evt.getDeltaX());
            freecamEntity.method_36457(freecamEntity.method_36455() + (float) evt.getDeltaY());
            freecamEntity.method_22862();

            evt.cancel();

        }

    }

    public class_1297 getFreecamEntity() {
        return freecamEntity;
    }

}
