package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_5498;
import net.justacoder.shadowclient.main.annotations.DoNotSaveState;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.DamageEvent;
import net.justacoder.shadowclient.main.event.events.KeyPressEvent;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.ui.clickgui.ClickGUI;
import net.justacoder.shadowclient.main.util.ChatUtils;
import net.justacoder.shadowclient.main.util.FakePlayerEntity;
import org.joml.Vector2d;
import org.joml.Vector3d;

@DoNotSaveState
@SearchTags({"freecam", "camera fly", "free cam"})
@EventListener({PreTickEvent.class, KeyPressEvent.class, DamageEvent.class})
public class Freecam extends Module {

    public NumberSetting SPEED = new NumberSetting("Speed", 0.05f, 4, 0.5, 2, MathUtils.Easing.EASE_IN_QUADRATIC);

    public Freecam() {
        super("freecam", ModuleCategory.RENDER);

        addSetting(SPEED);
    }

    public boolean forward;
    public boolean backward;
    public boolean left;
    public boolean right;
    public boolean up;
    public boolean down;

    public Vector3d pos = new Vector3d();
    public Vector2d rot = new Vector2d();

    public double fovEffectScale;
    public boolean bobView;

    public FakePlayerEntity fakePlayer;

    @Override
    public void onEnable() {

        class_4184 cam = mc.field_1773.method_19418();
        class_243 cpos = cam.method_19326();
        pos.x = cpos.field_1352;
        pos.y = cpos.field_1351;
        pos.z = cpos.field_1350;

        rot.x = mc.field_1724.method_36454();
        rot.y = mc.field_1724.method_36455();

        mc.field_1690.field_1894.method_23481(false);
        mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1913.method_23481(false);
        mc.field_1690.field_1903.method_23481(false);
        mc.field_1690.field_1832.method_23481(false);

        fovEffectScale = mc.field_1690.method_42454().method_41753();
        bobView = mc.field_1690.method_42448().method_41753();
        mc.field_1690.method_42454().method_41748(0d);
        mc.field_1690.method_42448().method_41748(false);

        fakePlayer = new FakePlayerEntity();
        fakePlayer.spawn();

        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.field_1690.method_42454().method_41748(fovEffectScale);
        mc.field_1690.method_42448().method_41748(bobView);

        if (fakePlayer != null) {
            fakePlayer.resetPlayerPosition();
            fakePlayer.despawn();
        }

        forward = false;
        backward = false;
        left = false;
        right = false;
        up = false;
        down = false;

        super.onDisable();
    }

    @Override
    public void onEvent(Event event) {

        if (event instanceof KeyPressEvent) {
            if (mc.field_1755 == null || mc.field_1755 instanceof ClickGUI) {

                int keyCode = ((KeyPressEvent) event).keyCode;

                boolean cancel = false;

                if (mc.field_1690.field_1894.method_1417(keyCode, 0)) {
                    forward = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1894.method_23481(false);
                    cancel = true;
                }
                if (mc.field_1690.field_1881.method_1417(keyCode, 0)) {
                    backward = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1881.method_23481(false);
                    cancel = true;
                }
                if (mc.field_1690.field_1849.method_1417(keyCode, 0)) {
                    right = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1849.method_23481(false);
                    cancel = true;
                }
                if (mc.field_1690.field_1913.method_1417(keyCode, 0)) {
                    left = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1913.method_23481(false);
                    cancel = true;
                }
                if (mc.field_1690.field_1903.method_1417(keyCode, 0)) {
                    up = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1903.method_23481(false);
                    cancel = true;
                }
                if (mc.field_1690.field_1832.method_1417(keyCode, 0)) {
                    down = ((KeyPressEvent) event).action != 0;
                    mc.field_1690.field_1832.method_23481(false);
                    cancel = true;
                }

                if (cancel) {
                    event.cancel();
                }
            }
            return;
        }

        if (event instanceof DamageEvent) {
            setDisabled(true, false);
            ChatUtils.sendMessageClient("Toggled freecam because you took damage.");
            return;
        }

        if (mc.field_1719.method_5757()) {
            mc.method_1560().field_5960 = true;
        }
        if (!mc.field_1690.method_31044().method_31034()) {
            mc.field_1690.method_31043(class_5498.field_26664);
        }

        class_243 forward = class_243.method_1030(0f, (float) rot.x);
        class_243 right = class_243.method_1030(0f, (float) rot.x + 90f);
        double velX = 0;
        double velY = 0;
        double velZ = 0;

        double s = 0.5;
        if (mc.field_1690.field_1867.method_1434()) {
            s = 1;
        }

        s *= SPEED.doubleValue();

        boolean a = false;
        if (this.forward) {
            velX += forward.field_1352 * s;
            velZ += forward.field_1350 * s;
            a = true;
        }
        if (this.backward) {
            velX -= forward.field_1352 * s;
            velZ -= forward.field_1350 * s;
            a = true;
        }

        boolean b = false;
        if (this.right) {
            velX += right.field_1352 * s;
            velZ += right.field_1350 * s;
            b = true;
        }
        if (this.left) {
            velX -= right.field_1352 * s;
            velZ -= right.field_1350 * s;
            b = true;
        }

        if (a && b) {
            double d = 1 / Math.sqrt(2);
            velX *= d;
            velZ *= d;
        }

        if (this.up) {
            velY += s;
        }
        if (this.down) {
            velY -= s;
        }

        pos.x += velX;
        pos.y += velY;
        pos.z += velZ;
    }

    public void lookDirection(double dx, double dy) {
        rot.x += dx;
        rot.y = class_3532.method_15350(rot.y + dy, -90, 90);
    }

    public double getX() {
        return pos.x;
    }
    public double getY() {
        return pos.y;
    }
    public double getZ() {
        return pos.z;
    }

    public double getYaw() {
        return rot.x;
    }
    public double getPitch() {
        return rot.y;
    }
}
