package net.justacoder.shadowclient.main.module.modules.combat;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.util.RotationUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_746;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@EventListener({PreTickEvent.class})
@SearchTags({"auto crystal", "auto detonate", "crystal aura", "autocrystal"})
public class AutoCrystal extends Module {

    public final BooleanSetting FACE_CRYSTALS = new BooleanSetting("Face Crystals", false);

    public AutoCrystal() {
        super("autocrystal", ModuleCategory.COMBAT);

        addSetting(FACE_CRYSTALS);
    }

    @Override
    public void onEvent(Event event) {

        ArrayList<class_1297> crystals = getNearbyCrystals();

        if (!crystals.isEmpty()) {
            detonate(crystals);
        }
    }

    private void detonate(ArrayList<class_1297> crystals) {
        for (class_1297 e : crystals) {
            if (FACE_CRYSTALS.booleanValue()) {
                RotationUtils.rotatePlayerToVec3d(e.method_5829().method_1005());
            }
            mc.field_1761.method_2918(mc.field_1724, e);
        }

        if (!crystals.isEmpty()) {
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    public ArrayList<class_1297> getNearbyCrystals() {
        class_746 player = mc.field_1724;
        double rangeSq = 36;

        Comparator<class_1297> furthestFromPlayer = Comparator.<class_1297>comparingDouble(e -> mc.field_1724.method_5858(e)).reversed();

        return StreamSupport.stream(mc.field_1687.method_18112().spliterator(), true).filter(e -> e instanceof class_1511).filter(e -> !e.method_31481()).filter(e -> player.method_5858(e) <= rangeSq).sorted(furthestFromPlayer).collect(Collectors.toCollection(ArrayList::new));
    }
}
