package net.justacoder.shadowclient.main.module.modules.combat;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_1268;
import net.minecraft.class_239;
import net.minecraft.class_3966;

@EventListener(PreTickEvent.class)
public class AutoHit extends Module {

    public AutoHit() {
        super("autohit", ModuleCategory.COMBAT, new String[]{"AutoHit", "automatic hit", "automatic damage", "auto entity hit"});
    }

    @Override
    public void onEvent(Event event) {

        if (mc.field_1765 == null || mc.field_1765.method_17783() != class_239.class_240.field_1331 || mc.field_1724 == null) {
            return;
        }

        mc.field_1761.method_2918(mc.field_1724, ((class_3966) mc.field_1765).method_17782());
        mc.field_1724.method_6104(class_1268.field_5808);

    }
}
