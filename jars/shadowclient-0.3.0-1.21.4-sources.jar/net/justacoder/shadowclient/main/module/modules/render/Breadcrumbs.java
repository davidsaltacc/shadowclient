package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.event.events.RenderEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.setting.settings.ColorSetting;
import net.justacoder.shadowclient.main.setting.settings.NumberSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.util.ColorUtils;
import net.justacoder.shadowclient.main.util.MathUtils;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import java.util.ArrayDeque;
import java.util.Iterator;

@EventListener({RenderEvent.class, PreTickEvent.class})
public class Breadcrumbs extends Module {

    public final BooleanSetting DEPTH_TEST = new BooleanSetting(new TranslatableString("setting.module.shadowclient.breadcrumbs.depth_test"), true);
    public final NumberSetting MIN_SEGMENT_LEN = new NumberSetting(new TranslatableString("setting.module.shadowclient.breadcrumbs.min_length"), 0.01f, 5.f, 0.5f, 2, MathUtils.Easing.EASE_IN_CUBIC);
    public final NumberSetting MAX_POSITIONS = new NumberSetting(new TranslatableString("setting.module.shadowclient.breadcrumbs.max_crumbs"), 2, 8000, 2000, 0);
    public final ColorSetting CRUMBS_COLOR = new ColorSetting(new TranslatableString("setting.module.shadowclient.breadcrumbs.color"), -1);

    private final ArrayDeque<class_243> positions = new ArrayDeque<>(MAX_POSITIONS.intValueEased());

    public Breadcrumbs() {
        super("breadcrumbs", ModuleCategory.RENDER, new String[]{"breadcrumbs", "trails", "player trails"});

        addSettings(DEPTH_TEST, MIN_SEGMENT_LEN, MAX_POSITIONS, CRUMBS_COLOR);

        MAX_POSITIONS.addChangeCallback((newValue, oldValue) -> {
            if ((double) newValue < (double) oldValue) {
                while (positions.size() > (double) newValue) {
                    positions.pollFirst();
                }
            }
        });
    }

    @Override
    public void onEvent(Event event) {

        if (event instanceof PreTickEvent) {

            float minSegLenSq = class_3532.method_27285(MIN_SEGMENT_LEN.floatValueEased());
            if (positions.isEmpty() || positions.peekLast().method_1025(mc.field_1724.method_19538()) > minSegLenSq) {
                if (positions.size() == MAX_POSITIONS.intValueEased()) {
                    positions.pollFirst();
                }
                positions.addLast(mc.field_1724.method_19538());
            }

        } else if (event instanceof RenderEvent evt) {

            Iterator<class_243> iter = positions.iterator();

            if (iter.hasNext()) {
                class_243 pos1 = iter.next();
                while (iter.hasNext()) {
                    class_243 pos2 = iter.next();
                    evt.renderer.drawLine(pos1.field_1352, pos1.field_1351, pos1.field_1350, pos2.field_1352, pos2.field_1351, pos2.field_1350, ColorUtils.int2RGBAfloat(CRUMBS_COLOR.colorValue()), DEPTH_TEST.booleanValue());
                    pos1 = pos2;
                }
            }

        }
    }

    @Override
    public boolean onDisable() {
        positions.clear();
        return super.onDisable();
    }
}
