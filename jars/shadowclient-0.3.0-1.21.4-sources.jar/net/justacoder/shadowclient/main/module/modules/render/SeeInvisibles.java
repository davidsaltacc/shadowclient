package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1588;
import net.minecraft.class_1657;

@SearchTags({"see invisibles", "anti invisible", "seeinvisibles"})
public class SeeInvisibles extends Module {

    public final BooleanSetting SeePlayerEntities = new BooleanSetting("Players", true);
    public final BooleanSetting SeeHostileEntities = new BooleanSetting("Hostiles", false);
    public final BooleanSetting SeePassiveEntities = new BooleanSetting("Passives", false);
    public final BooleanSetting SeeAmbientEntities = new BooleanSetting("Ambients", false);
    public final BooleanSetting SeeOtherEntities = new BooleanSetting("Others", false);

    public SeeInvisibles() {
        super("seeinvisibles", ModuleCategory.RENDER);

        addSettings(SeePlayerEntities, SeeHostileEntities, SeePassiveEntities, SeeAmbientEntities, SeeOtherEntities);
    }

    public boolean visible(class_1297 entity) {
        if (!enabled) {
            return false;
        }
        if (entity instanceof class_1657 && SeePlayerEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1588 && SeeHostileEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1296 && SeePassiveEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1421 && SeeAmbientEntities.booleanValue()) {
            return true;
        }
        return SeeOtherEntities.booleanValue();
    }
}
