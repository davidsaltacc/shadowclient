package net.justacoder.shadowclient.main.module.modules.render;

import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1421;
import net.minecraft.class_1588;
import net.minecraft.class_1657;

public class SeeInvisibles extends Module {

    public final BooleanSetting seePlayerEntities = new BooleanSetting("Players", true);
    public final BooleanSetting seeHostileEntities = new BooleanSetting("Hostiles", false);
    public final BooleanSetting seePassiveEntities = new BooleanSetting("Passives", false);
    public final BooleanSetting seeAmbientEntities = new BooleanSetting("Ambients", false);
    public final BooleanSetting seeOtherEntities = new BooleanSetting("Others", false);

    public SeeInvisibles() {
        super("seeinvisibles", ModuleCategory.RENDER, new String[]{"see invisibles", "anti invisible", "seeinvisibles"});

        addSettings(seePlayerEntities, seeHostileEntities, seePassiveEntities, seeAmbientEntities, seeOtherEntities);
    }

    public boolean visible(class_1297 entity) {
        if (!enabled) {
            return false;
        }
        if (entity instanceof class_1657 && seePlayerEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1588 && seeHostileEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1296 && seePassiveEntities.booleanValue()) {
            return true;
        }
        if (entity instanceof class_1421 && seeAmbientEntities.booleanValue()) {
            return true;
        }
        return seeOtherEntities.booleanValue();
    }
}
