package net.justacoder.shadowclient.main.module.modules.movement;

import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.minecraft.class_243;

@EventListener({PreTickEvent.class})
@SearchTags({"spider", "wallclimb", "climb walls", "wall climb"})
public class Spider extends Module {

    public Spider() {
        super("spider", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEvent(Event event) {
        if (!mc.field_1724.field_5976) {
            return;
        }

        class_243 velocity = mc.field_1724.method_18798();

        if (velocity.field_1351 >= 0.2) {
            return;
        }

        mc.field_1724.method_18800(velocity.field_1352, 0.2, velocity.field_1350);

    }
}
