package net.justacoder.shadowclient.main.event.events;

import net.justacoder.shadowclient.main.event.Event;
import net.minecraft.class_2596;

public class PacketReceivedEvent extends Event {
    public final class_2596<?> packet;
    public PacketReceivedEvent(class_2596<?> packet) {
        this.packet = packet;
    }
}
