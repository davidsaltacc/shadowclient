package net.justacoder.shadowclient.main.util;

import net.minecraft.class_4587;

public abstract class MixinSharedValues { // public static members are not allowed in mixins

    public static boolean ignoreSolidBlocksRaycasting = false;

    public static class_4587 worldRendererStack;
    public static float worldRendererDelta;

}
