package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_243;

public abstract class PlayerUtils {
    public static class_243 getHandOffset(class_1268 hand, double yaw) {
        class_1306 arm = ShadowClientMain.mc.field_1690.method_42552().method_41753();

        boolean right = arm == class_1306.field_6183 && hand == class_1268.field_5808 || arm == class_1306.field_6182 && hand == class_1268.field_5810;

        double sideMul = right ? -1 : 1;
        double offX = Math.cos(yaw) * 0.16 * sideMul;
        double offY = ShadowClientMain.mc.field_1724.method_5751() - 0.1;
        double offZ = Math.sin(yaw) * 0.16 * sideMul;

        return new class_243(offX, offY, offZ);
    }
}
