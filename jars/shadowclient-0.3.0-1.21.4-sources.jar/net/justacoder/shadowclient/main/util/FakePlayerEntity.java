package net.justacoder.shadowclient.main.util;

import com.mojang.authlib.GameProfile;
import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_1297;
import net.minecraft.class_2945;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_746;
import java.util.UUID;

public class FakePlayerEntity extends class_745 {

    public class_746 player = ShadowClientMain.mc.field_1724;
    public class_638 world = ShadowClientMain.mc.field_1687;

    public FakePlayerEntity() {
        super(ShadowClientMain.mc.field_1687, new GameProfile(UUID.randomUUID(), ShadowClientMain.mc.field_1724.method_7334().getName()));

        method_7334().getProperties().putAll(ShadowClientMain.mc.field_1724.method_7334().getProperties());

        method_5719(player);
        copyInventory();
        copyPlayerModel(player, this);
        copyRotation();
    }

    public void copyInventory() {
        method_31548().method_7377(player.method_31548());
    }

    public void copyPlayerModel(class_1297 from, class_1297 to) {
        class_2945 fromT = from.method_5841();
        class_2945 toT = to.method_5841();
        Byte playerModel = fromT.method_12789(field_7518);
        toT.method_12778(field_7518, playerModel);
    }

    public void copyRotation() {
        field_6241 = player.field_6241;
        field_6283 = player.field_6283;
    }

    public void spawn() {
        world.method_53875(this);
    }

    public void despawn() {
        method_31472();
    }

    public void resetPlayerPosition() {
        player.method_5808(method_23317(), method_23318(), method_23321(), method_36454(), method_36455());
    }
}
