package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_2828;

public abstract class BypassUtils {

    public static void sendFiveMovementPackets() {
        for (int i = 0; i < 5; i++) {
            ShadowClientMain.mc.method_1562().method_52787(new class_2828.class_2829(ShadowClientMain.mc.field_1724.method_23317(), ShadowClientMain.mc.field_1724.method_23318(), ShadowClientMain.mc.field_1724.method_23321(), true, ShadowClientMain.mc.field_1724.field_5976));
        }
    }

}
