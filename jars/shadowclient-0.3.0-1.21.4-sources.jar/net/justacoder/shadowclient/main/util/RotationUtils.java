package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.joml.Quaternionf;

public abstract class RotationUtils {

    public static void rotatePlayerToVec3d(class_243 vec3d) {
        class_746 player = ShadowClientMain.mc.field_1724;
        float[] needed = RotationUtils.rotationTowardsF(player.method_33571(), vec3d);

        float currentWrapped = class_3532.method_15393(player.method_36454());
        float intendedWrapped = class_3532.method_15393(needed[0]);

        float change = class_3532.method_15393(intendedWrapped - currentWrapped);

        float yaw = player.method_36454() + change;
        float pitch = needed[1];

        ShadowClientMain.mc.field_1724.field_3944.method_52787(new class_2828.class_2831(yaw, pitch, ShadowClientMain.mc.field_1724.method_24828(), ShadowClientMain.mc.field_1724.field_5976));
    }

    public static Quaternionf rotationTowardsQ(class_243 start, class_243 towards) {
        float[] rot = rotationTowardsF(start, towards);
        return new Quaternionf().rotationYXZ((float) Math.toRadians(rot[0]), (float) Math.toRadians(rot[1]), 0f);
    }

    public static Quaternionf rotationAwayQ(class_243 start, class_243 towards) {
        float[] rot = rotationAwayF(start, towards);
        return new Quaternionf().rotationYXZ((float) Math.toRadians(rot[0]), (float) Math.toRadians(rot[1]), 0f);
    }

    public static class_243 rotationTowardsV(class_243 start, class_243 towards) {
        float[] rot = rotationTowardsF(start, towards);
        return class_243.method_1030(rot[0], rot[1]);
    }

    public static class_243 rotationAwayV(class_243 start, class_243 towards) {
        float[] rot = rotationAwayF(start, towards);
        return class_243.method_1030(rot[0], rot[1]);
    }

    public static float[] rotationTowardsF(class_243 start, class_243 end) {
        class_243 direction = end.method_1020(start);
        if (direction.method_1027() == 0) {
            return new float[] {0f, 0f};
        }
        direction = direction.method_1029();
        float yaw = (float) Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.asin(direction.field_1351));
        return new float[] {yaw, pitch};
    }

    public static float[] rotationAwayF(class_243 start, class_243 end) {
        class_243 direction = end.method_1020(start).method_22882();
        if (direction.method_1027() == 0) {
            return new float[] {0f, 0f};
        }
        direction = direction.method_1029();
        float yaw = (float) Math.toDegrees(Math.atan2(direction.field_1350, direction.field_1352)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.asin(direction.field_1351));
        return new float[] {yaw, pitch};
    }

}
