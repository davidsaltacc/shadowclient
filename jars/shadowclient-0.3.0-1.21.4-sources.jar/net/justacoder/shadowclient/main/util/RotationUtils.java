package net.justacoder.shadowclient.main.util;

import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public abstract class RotationUtils {

    private static final class_310 mc = class_310.method_1551();

    public static void rotateToVec3d(class_243 vec3d) {
        float[] needed = RotationUtils.getNeededRotations(vec3d);
        class_746 player = mc.field_1724;

        float currentWrapped = class_3532.method_15393(player.method_36454());
        float intendedWrapped = class_3532.method_15393(needed[0]);

        float change = class_3532.method_15393(intendedWrapped - currentWrapped);

        float yaw = player.method_36454() + change;
        float pitch = needed[1];

        mc.field_1724.field_3944.method_52787(new class_2828.class_2831(yaw, pitch, mc.field_1724.method_24828(), mc.field_1724.field_5976));
    }

    public static float[] getNeededRotations(class_243 vec) {
        class_243 eyesPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318() + mc.field_1724.method_18381(mc.field_1724.method_18376()), mc.field_1724.method_23321());

        double diffX = vec.field_1352 - eyesPos.field_1352;
        double diffY = vec.field_1351 - eyesPos.field_1351;
        double diffZ = vec.field_1350 - eyesPos.field_1350;

        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        return new float[]{yaw, pitch};
    }

}
