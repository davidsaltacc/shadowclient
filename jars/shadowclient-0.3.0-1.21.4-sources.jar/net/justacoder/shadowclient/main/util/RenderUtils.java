package net.justacoder.shadowclient.main.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import net.minecraft.client.render.*;
import net.justacoder.shadowclient.mixininterface.IGameRenderer;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public abstract class RenderUtils {

    public static class_243 getInterpolationOffset(class_1297 e) {
        if (class_310.method_1551().method_1493()) {
            return class_243.field_1353;
        }

        double tickDelta = class_310.method_1551().method_61966().method_60637(false);
        return new class_243(e.method_23317() - class_3532.method_16436(tickDelta, e.field_6038, e.method_23317()), e.method_23318() - class_3532.method_16436(tickDelta, e.field_5971, e.method_23318()), e.method_23321() - class_3532.method_16436(tickDelta, e.field_5989, e.method_23321()));
    }

    public static void drawLine(double x1, double y1, double z1, double x2, double y2, double z2, float[] color, float width, boolean depthTest) {

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        class_4587 matrices = matrixFrom(x1, y1, z1);

        class_289 tessellator = class_289.method_1348();

        if (depthTest) {
            RenderSystem.enableDepthTest();
        } else {
            RenderSystem.disableDepthTest();
        }
        RenderSystem.disableCull();
        RenderSystem.setShader(class_10142.field_53864);
        RenderSystem.lineWidth(width);

        class_287 builder = tessellator.method_60827(class_293.class_5596.field_27377, class_290.field_29337);
        vertexLine(matrices, builder, 0f, 0f, 0f, (float) (x2 - x1), (float) (y2 - y1), (float) (z2 - z1), color);
        class_286.method_43433(builder.method_60800());

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    public static void drawLine(double x1, double y1, double z1, double x2, double y2, double z2, float[] color, float width) {
        drawLine(x1, y1, z1, x2, y2, z2, color, width, false);
    }

    public static void vertexLine(class_4587 matrices, class_4588 vertexConsumer, float x1, float y1, float z1, float x2, float y2, float z2, float[] lineColor) {
        class_4587.class_4665 entry = matrices.method_23760();

        Vector3f normalVec = getNormal(x1, y1, z1, x2, y2, z2);

        vertexConsumer.method_56824(entry, x1, y1, z1).method_22915(lineColor[0], lineColor[1], lineColor[2], lineColor[3]).method_60831(entry, normalVec.x(), normalVec.y(), normalVec.z());
        vertexConsumer.method_56824(entry, x2, y2, z2).method_22915(lineColor[0], lineColor[1], lineColor[2], lineColor[3]).method_60831(entry, normalVec.x(), normalVec.y(), normalVec.z());
    }

    public static Vector3f getNormal(float x1, float y1, float z1, float x2, float y2, float z2) {
        float xNormal = x2 - x1;
        float yNormal = y2 - y1;
        float zNormal = z2 - z1;
        float normalSqrt = class_3532.method_15355(xNormal * xNormal + yNormal * yNormal + zNormal * zNormal);

        return new Vector3f(xNormal / normalSqrt, yNormal / normalSqrt, zNormal / normalSqrt);
    }

    public static class_4587 matrixFrom(double x, double y, double z) {
        class_4587 matrices = new class_4587();

        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));

        matrices.method_22904(x - camera.method_19326().field_1352, y - camera.method_19326().field_1351, z - camera.method_19326().field_1350);

        return matrices;
    }

    public static void loadShader(@Nullable class_2960 id) {
        ((IGameRenderer) class_310.method_1551().field_1773).loadShader(id);
    }

    public static void drawOutlinedBox(class_238 box, class_4587 matrices) {

        Matrix4f matrix = matrices.method_23760().method_23761();
        class_289 tessellator = RenderSystem.renderThreadTesselator();
        class_287 bufferBuilder = tessellator.method_60827(class_293.class_5596.field_29344, class_290.field_1592);
        RenderSystem.setShader(class_10142.field_53875);

        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1321); // TODO someone please fucking optimize this for me
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1322, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1321);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1320, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1324);
        bufferBuilder.method_22918(matrix, (float) box.field_1323, (float) box.field_1325, (float) box.field_1321);

        class_286.method_43433(bufferBuilder.method_60800());
    }
}