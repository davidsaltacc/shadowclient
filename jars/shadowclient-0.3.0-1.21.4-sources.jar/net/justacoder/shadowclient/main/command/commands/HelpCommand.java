package net.justacoder.shadowclient.main.command.commands;

import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.command.Command;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public class HelpCommand extends Command {
    @Override
    public void OnExecute(String... args_) {

        class_310.method_1551().field_1724.method_7353(class_2561.method_30163(SCMain.createHelp()), false);

    }

    public HelpCommand() {
        this.CommandName = "help";
    }
}
