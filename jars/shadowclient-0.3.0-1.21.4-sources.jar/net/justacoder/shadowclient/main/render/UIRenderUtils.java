package net.justacoder.shadowclient.main.render;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_332;

public abstract class UIRenderUtils {

    public static float disableGuiScaleFactor() {
        return 1f / enableGuiScaleFactor();
    }

    public static float enableGuiScaleFactor() {
        return (float) ShadowClientMain.mc.method_22683().method_4495();
    }

    public static void beforeUIRender(class_332 context) {
        float scaleFac = disableGuiScaleFactor();
        context.method_51448().method_22905(scaleFac, scaleFac, 1);
    }

    public static void afterUIRender(class_332 context) {
        float scaleFac = enableGuiScaleFactor();
        context.method_51448().method_22905(scaleFac, scaleFac, 1);
    }

}
