package net.justacoder.shadowclient.main.render;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.minecraft.class_332;

public abstract class UIRenderUtils {

    public static float guiScaleDivisor() {
        return 1f / guiScaleFactor();
    }

    public static float guiScaleFactor() {
        return (float) ShadowClientMain.mc.method_22683().method_4495();
    }

    public static void beforeUIRender(class_332 context) {
        float scaleFac = guiScaleDivisor();
        context.method_51448().method_22905(scaleFac, scaleFac, 1);
    }

    public static void afterUIRender(class_332 context) {
        float scaleFac = guiScaleFactor();
        context.method_51448().method_22905(scaleFac, scaleFac, 1);
    }

}
