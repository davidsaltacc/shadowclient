package net.justacoder.shadowclient.main.render;

import java.util.function.Function;
import net.minecraft.class_10142;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

public abstract class RenderingTypes { // this is kind of inspired by vanilla's RenderLayer, except that one caused multiple issues as well as the need for many accesswidener uses

    private static final RenderingType LINES = RenderingType.create(
            "lines",
            class_290.field_1576,
            class_293.class_5596.field_29344,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53876)
                    .culling(RenderingType.CULLING_DISABLED)
                    .blendFunc(RenderingType.DEFAULT_BLEND_FUNCTION)
                    .depthTest(RenderingType.NORMAL_DEPTH_TEST)
                    .lineWidth(RenderingType.LINE_WIDTH.apply(1))
                    .build()
    );

    private static final RenderingType LINES_NO_DEPTH_TEST = RenderingType.create(
            "lines_no_depth_test",
            class_290.field_1576,
            class_293.class_5596.field_29344,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53876)
                    .culling(RenderingType.CULLING_DISABLED)
                    .blendFunc(RenderingType.DEFAULT_BLEND_FUNCTION)
                    .depthTest(RenderingType.NO_DEPTH_TEST)
                    .lineWidth(RenderingType.LINE_WIDTH.apply(1))
                    .build()
    );

    private static final RenderingType LINES_STRIP = RenderingType.create(
            "lines_strip",
            class_290.field_1576,
            class_293.class_5596.field_29345,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53876)
                    .culling(RenderingType.CULLING_DISABLED)
                    .blendFunc(RenderingType.DEFAULT_BLEND_FUNCTION)
                    .depthTest(RenderingType.NORMAL_DEPTH_TEST)
                    .lineWidth(RenderingType.LINE_WIDTH.apply(1))
                    .build()
    );

    private static final RenderingType LINES_STRIP_NO_DEPTH_TEST = RenderingType.create(
            "lines_strip_no_depth_test",
            class_290.field_1576,
            class_293.class_5596.field_29345,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53876)
                    .culling(RenderingType.CULLING_DISABLED)
                    .blendFunc(RenderingType.DEFAULT_BLEND_FUNCTION)
                    .depthTest(RenderingType.NO_DEPTH_TEST)
                    .lineWidth(RenderingType.LINE_WIDTH.apply(1))
                    .build()
    );

    private static final Function<class_2960, RenderingType> TEXT = id -> RenderingType.create(
            "text_" + id.toString(),
            class_290.field_1575,
            class_293.class_5596.field_27382,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53880)
                    .texture(new RenderingType.Texture(id, true))
                    .blendFunc(RenderingType.TRANSPARENCY_BLEND_FUNCTION)
                    .build()
    );

    private static final Function<class_2960, RenderingType> TEXT_NO_DEPTH_TEST = id -> RenderingType.create(
            "text_no_depth_test_" + id.toString(),
            class_290.field_1575,
            class_293.class_5596.field_27382,
            RenderingType.Settings.builder()
                    .program(class_10142.field_53880)
                    .texture(new RenderingType.Texture(id, true))
                    .blendFunc(RenderingType.TRANSPARENCY_BLEND_FUNCTION)
                    .depthTest(RenderingType.NO_DEPTH_TEST)
                    .build()
    );

    public static RenderingType getLines(boolean depthTest) {
        return depthTest ? LINES : LINES_NO_DEPTH_TEST;
    }

    public static RenderingType getLinesStrip(boolean depthTest) {
        return depthTest ? LINES_STRIP : LINES_STRIP_NO_DEPTH_TEST;
    }

    public static RenderingType getText(class_2960 textureId, boolean depthTest) {
        return (depthTest ? TEXT : TEXT_NO_DEPTH_TEST).apply(textureId);
    }
}
