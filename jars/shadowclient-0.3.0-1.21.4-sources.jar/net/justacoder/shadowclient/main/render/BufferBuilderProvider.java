package net.justacoder.shadowclient.main.render;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_287;

public class BufferBuilderProvider {

    private BufferBuilderProvider() {}

    private static BufferBuilderProvider instance = null;

    public static BufferBuilderProvider getInstance() {
        if (instance == null) {
            instance = new BufferBuilderProvider();
        }
        return instance;
    }

    private Map<RenderingType, class_287> bufferBuilders = new HashMap<>();

    public class_287 getBufferBuilder(RenderingType type) {
        return bufferBuilders.computeIfAbsent(type, t -> type._getBuffer());
    }

    public void draw() {
        bufferBuilders.forEach(RenderingType::draw);
        bufferBuilders.clear();
    }

}
