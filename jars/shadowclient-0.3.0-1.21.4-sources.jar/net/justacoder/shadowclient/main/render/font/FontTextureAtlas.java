package net.justacoder.shadowclient.main.render.font;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class FontTextureAtlas {

    private static final int ATLAS_SIZE = 2048;
    private final Map<Character, Glyph> glyphMap = new HashMap<>();
    private final class_1043 texture;
    private final class_2960 textureId;
    private final Font font;
    private int currentX = 0;
    private int currentY = 0;
    private int lineHeight = 0;

    public FontTextureAtlas(Font font) {
        this.font = font;
        this.texture = new class_1043(ATLAS_SIZE, ATLAS_SIZE, true);
        this.textureId = class_2960.method_60654("scfont_" + font.getSize());
        class_310.method_1551().method_1531().method_4616(textureId, texture);
        initializeTexture();
        for (int c = 0; c < 256; c++) {
            getGlyph((char) c);
        }
    }

    private void initializeTexture() {
        class_1011 image = texture.method_4525();
        image.method_4326(0, 0, ATLAS_SIZE, ATLAS_SIZE, 0x00000000);
        texture.method_4524();
    }

    public Glyph getGlyph(char c) {
        return glyphMap.computeIfAbsent(c, this::createGlyph);
    }

    private Glyph createGlyph(char c) {
        BufferedImage charImage = renderCharacter(c);

        int width;
        int height;

        if (charImage != null) {
            width = charImage.getWidth();
            height = charImage.getHeight();
        } else {
            width = 0;
            height = 0;
        }

        if (currentX + width >= ATLAS_SIZE) {
            currentX = 0;
            currentY += lineHeight;
            lineHeight = 0;
        }

        if (currentY + height >= ATLAS_SIZE) {
            throw new RuntimeException("Font atlas is full");
        }

        class_1011 atlasImage = texture.method_4525();
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int argb = charImage.getRGB(x, y);
                atlasImage.method_61941(currentX + x, currentY + y, argb);
            }
        }
        texture.method_4524();

        if (charImage == null) {
            return new Glyph(0, 0, 0, 0, width, height);
        }

        Glyph glyph = new Glyph(
                (float) currentX / ATLAS_SIZE,
                (float) currentY / ATLAS_SIZE,
                (float) (currentX + width) / ATLAS_SIZE,
                (float) (currentY + height) / ATLAS_SIZE,
                width,
                height
        );

        currentX += width;
        lineHeight = Math.max(lineHeight, height);
        return glyph;
    }

    private BufferedImage renderCharacter(char c) {
        BufferedImage image = new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = image.createGraphics();
        g.setFont(font);
        FontMetrics metrics = g.getFontMetrics();
        int width = metrics.charWidth(c);
        int height = metrics.getHeight();
        g.dispose();

        if (width <= 0 || height <= 0) {
            return null;
        }

        image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_LCD_HRGB);
        g.setFont(font);
        g.setColor(new Color(255, 255, 255, 0));
        g.fillRect(0, 0, width, height);
        g.setColor(Color.WHITE);
        g.drawString(String.valueOf(c), 0, metrics.getAscent());
        g.dispose();
        return image;
    }

    public class_2960 getTextureId() {
        return textureId;
    }

    public static class Glyph {
        public final float u0, v0, u1, v1;
        public final int width, height;

        public Glyph(float u0, float v0, float u1, float v1, int width, int height) {
            this.u0 = u0;
            this.v0 = v0;
            this.u1 = u1;
            this.v1 = v1;
            this.width = width;
            this.height = height;
        }
    }

}
