package net.justacoder.shadowclient.main.render.font;

import net.justacoder.shadowclient.main.render.BufferBuilderProvider;
import net.justacoder.shadowclient.main.render.RenderingTypes;
import net.justacoder.shadowclient.mixin.DrawContextAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class FontRenderer {

    private final Map<Integer, FontTextureAtlas> atlases = new HashMap<>();
    private final Font baseFont;

    public FontRenderer(Font baseFont) {
        this.baseFont = baseFont;
    }


    public void drawText(class_332 context, String text, float x, float y, int fontSize, int color) {
        drawText(((DrawContextAccessor) context).getVertexConsumers(), context.method_51448(), text, x, y, fontSize, color);
    }

    public void drawText(class_4597 provider, class_4587 matrices, String text, float x, float y, int fontSize, int color) {
        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        drawText(provider.getBuffer(class_1921.method_23028(atlas.getTextureId())), matrices.method_23760().method_23761(), text, x, y, fontSize, color);
    }

    public void drawText(BufferBuilderProvider provider, class_4587 matrices, String text, float x, float y, int fontSize, int color, boolean depthTest) {
        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        drawText(provider.getBufferBuilder(RenderingTypes.getText(atlas.getTextureId(), depthTest)), matrices.method_23760().method_23761(), text, x, y, fontSize, color);
    }

    public void drawText(BufferBuilderProvider provider, class_4587 matrices, String text, float x, float y, int fontSize, int color) {
        drawText(provider, matrices, text, x, y, fontSize, color, false);
    }

    private void drawText(class_4588 consumer, Matrix4f matrix, String text, float x, float y, int fontSize, int color) {

        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        FontTextureAtlas.Glyph glyph;

        float r = (color >> 16 & 255) / 255f;
        float g = (color >> 8 & 255) / 255f;
        float b = (color & 255) / 255f;
        float a = (color >> 24 & 255) / 255f;

        float cursorX = x;
        for (char c : text.toCharArray()) {
            glyph = atlas.getGlyph(c); // so we basically just fill the font atlas over time and hope it never runs out of space. great. love me the lack of optimization

            consumer.method_22918(matrix, cursorX, y, 0).method_22915(r, g, b, a).method_22913(glyph.u0, glyph.v0).method_60803(15728880); // apparently the maximum value
            consumer.method_22918(matrix, cursorX, y + glyph.height, 0).method_22915(r, g, b, a).method_22913(glyph.u0, glyph.v1).method_60803(15728880);
            consumer.method_22918(matrix, cursorX + glyph.width, y + glyph.height, 0).method_22915(r, g, b, a).method_22913(glyph.u1, glyph.v1).method_60803(15728880);
            consumer.method_22918(matrix, cursorX + glyph.width, y, 0).method_22915(r, g, b, a).method_22913(glyph.u1, glyph.v0).method_60803(15728880);

            cursorX += glyph.width;
        }

    }

    public FontTextureAtlas getAtlasForSize(int size) {
        return atlases.computeIfAbsent(size, s ->
                new FontTextureAtlas(baseFont.deriveFont((float) s))
        );
    }

}
