package net.justacoder.shadowclient.main.render.font;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.render.BufferBuilderProvider;
import net.justacoder.shadowclient.main.render.RenderingTypes;
import net.justacoder.shadowclient.mixin.DrawContextAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class FontRenderer {

    private final Map<Integer, FontTextureAtlas> atlases = new HashMap<>();
    private final String fontPath;

    public FontRenderer(String fontPath) {
        this.fontPath = fontPath;
    }


    public void drawText(class_332 context, String text, float x, float y, int fontSize, int color) {
        drawText(((DrawContextAccessor) context).getVertexConsumers(), context.method_51448(), text, x, y, fontSize, color);
    }

    public void drawText(class_4597 provider, class_4587 matrices, String text, float x, float y, int fontSize, int color) {
        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        drawText(provider.getBuffer(class_1921.method_23028(atlas.getTextureId())), matrices.method_23760().method_23761(), text, x, y, fontSize, color);
    }

    public void drawText(BufferBuilderProvider provider, class_4587 matrices, String text, float x, float y, int fontSize, int color, boolean depthTest) {
        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        drawText(provider.getBufferBuilder(RenderingTypes.getText(atlas.getTextureId(), depthTest)), matrices.method_23760().method_23761(), text, x, y, fontSize, color);
    }

    public void drawText(BufferBuilderProvider provider, class_4587 matrices, String text, float x, float y, int fontSize, int color) {
        drawText(provider, matrices, text, x, y, fontSize, color, false);
    }

    private void drawText(class_4588 consumer, Matrix4f matrix, String text, float x, float y, int fontSize, int color) {

        FontTextureAtlas atlas = getAtlasForSize(fontSize);
        FontTextureAtlas.Glyph glyph;

        float r = (color >> 16 & 255) / 255f;
        float g = (color >> 8 & 255) / 255f;
        float b = (color & 255) / 255f;
        float a = (color >> 24 & 255) / 255f;

        float advX = x;

        for (char c : text.toCharArray()) {
            glyph = atlas.getGlyph(c);

            consumer.method_22918(matrix, advX + glyph.bearingX(), y - glyph.bearingY(), 0).method_22915(r, g, b, a).method_22913(glyph.u0(), glyph.v0()).method_60803(15728880); // x0 y0
            consumer.method_22918(matrix, advX + glyph.bearingX(), y - glyph.bearingY() + glyph.height(), 0).method_22915(r, g, b, a).method_22913(glyph.u0(), glyph.v1()).method_60803(15728880); // x0 y1
            consumer.method_22918(matrix, advX + glyph.bearingX() + glyph.width(), y - glyph.bearingY() + glyph.height(), 0).method_22915(r, g, b, a).method_22913(glyph.u1(), glyph.v1()).method_60803(15728880); // x1 y1
            consumer.method_22918(matrix, advX + glyph.bearingX() + glyph.width(), y - glyph.bearingY(), 0).method_22915(r, g, b, a).method_22913(glyph.u1(), glyph.v0()).method_60803(15728880); // x1 y0

            advX += glyph.advance();
        }

    }

    public FontTextureAtlas getAtlasForSize(int size) {
        if (!net.justacoder.shadowclient.main.ui.font.Font.isFontSizeRegistered(size)) {
            throw new RuntimeException("Tried to get a font atlas for a size that was not registered and generated on launch (" + size + ")! (Registered: " + net.justacoder.shadowclient.main.ui.font.Font.getRegisteredFontSizes() + ")");
        }
        return atlases.computeIfAbsent(size, s ->
                {
                    try {
                        return new FontTextureAtlas(fontPath, s);
                    } catch (IOException e) {
                        ShadowClientMain.error("Failed to load font atlas");
                        throw new RuntimeException(e);
                    }
                }
        );
    }

}
