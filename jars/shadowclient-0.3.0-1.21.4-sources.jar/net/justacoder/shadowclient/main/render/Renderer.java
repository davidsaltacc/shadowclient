package net.justacoder.shadowclient.main.render;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.ui.font.Font;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7833;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.List;

public class Renderer { // IntelliJ says this can be converted to a record. it's right, but I don't feel comfortable doing that. like, not at all.

    private final BufferBuilderProvider bufferBuilderProvider;
    private final class_4587 matrices;
    private final float tickDelta;

    public Renderer(BufferBuilderProvider bufferBuilderProvider, class_4587 matrices, float tickDelta) {
        this.bufferBuilderProvider = bufferBuilderProvider;
        this.matrices = matrices;
        this.tickDelta = tickDelta;
    }

    public float getTickDelta() {
        return tickDelta;
    }

    public BufferBuilderProvider getBufferBuilderProvider() {
        return bufferBuilderProvider;
    }

    public class_4587 getMatrices() {
        return matrices;
    }

    public class_243 getInterpolationOffset(class_1297 e) {
        return class_310.method_1551().method_1493() ? class_243.field_1353 : new class_243(e.method_23317() - class_3532.method_16436(tickDelta, e.field_6038, e.method_23317()), e.method_23318() - class_3532.method_16436(tickDelta, e.field_5971, e.method_23318()), e.method_23321() - class_3532.method_16436(tickDelta, e.field_5989, e.method_23321()));
    }

    public void matricesToWorldSpace() {
        class_4184 camera = ShadowClientMain.mc.field_1773.method_19418();
        matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180f));
        matrices.method_22904(-camera.method_19326().field_1352, -camera.method_19326().field_1351, -camera.method_19326().field_1350);
    }

    public void drawLine(double x1, double y1, double z1, double x2, double y2, double z2, float[] color) {
        drawLine(x1, y1, z1, x2, y2, z2, color, true);
    }

    public void drawLine(float x1, float y1, float z1, float x2, float y2, float z2, float[] color) {
        drawLine(x1, y1, z1, x2, y2, z2, color, true);
    }

    public void drawLine(double x1, double y1, double z1, double x2, double y2, double z2, float[] color, boolean depthTest) {
        drawLine((float) x1, (float) y1, (float) z1, (float) x2, (float) y2, (float) z2, color, depthTest);
    }

    public void drawLine(float x1, float y1, float z1, float x2, float y2, float z2, float[] color, boolean depthTest) {
        class_4588 consumer = bufferBuilderProvider.getBufferBuilder(RenderingTypes.getLines(depthTest));
        matrices.method_22903();
        matricesToWorldSpace();
        Matrix4f posMat = matrices.method_23760().method_23761();
        consumer.method_22918(posMat, x1, y1, z1).method_22915(color[0], color[1], color[2], color[3]);
        consumer.method_22918(posMat, x2, y2, z2).method_22915(color[0], color[1], color[2], color[3]);
        matrices.method_22909();
    }

    public void drawLineList(List<class_243> points, float[] color) {
        drawLineList(points, color, true);
    }

    public void drawLineList(List<class_243> points, float[] color, boolean depthTest) {
        if (points.size() < 2) {
            return;
        }
        class_4588 consumer = bufferBuilderProvider.getBufferBuilder(RenderingTypes.getLinesStrip(depthTest));
        matrices.method_22903();
        matricesToWorldSpace();
        Matrix4f posMat = matrices.method_23760().method_23761();
        class_243 firstPoint = points.getFirst();
        class_243 lastPoint = points.getLast();
        consumer.method_22918(posMat, (float) firstPoint.field_1352, (float) firstPoint.field_1351, (float) firstPoint.field_1350).method_22915(0f, 0f, 0f, 0f); // hacky, but like, cry about it or something
        points.forEach(point -> consumer.method_22918(posMat, (float) point.field_1352, (float) point.field_1351, (float) point.field_1350).method_22915(color[0], color[1], color[2], color[3]));
        consumer.method_22918(posMat, (float) lastPoint.field_1352, (float) lastPoint.field_1351, (float) lastPoint.field_1350).method_22915(0f, 0f, 0f, 0f);
        matrices.method_22909();
    }

    private static final int FONT_SIZE = 28;

    public int getTextWidth(String text) {
        return Font.getWidth(text, FONT_SIZE);
    }

    public int getTextHeight() {
        return Font.getHeight(FONT_SIZE);
    }

    public void drawText(String text, float x, float y, float z, Quaternionf rotation, int color, float offsetX, float offsetY) {
        matrices.method_22903();
        matricesToWorldSpace();
        matrices.method_46416(x, y, z);
        matrices.method_22907(rotation);
        matrices.method_22905(-0.0025f, -0.0025f, 0.0025f);
        Font.renderString(bufferBuilderProvider, matrices, text, offsetX, offsetY, color, FONT_SIZE);
        matrices.method_22909();
    }

    public void drawText(String text, float x, float y, float z, Quaternionf rotation, int color) {
        drawText(text, x, y, z, rotation, color, 0, 0);
    }

    public void drawText(class_2561 text, float x, float y, float z, Quaternionf rotation, int color) {
        drawText(text.getString(), x, y, z, rotation, color, 0f, 0f);
    }

    public void drawText(String text, double x, double y, double z, Quaternionf rotation, int color) {
        drawText(text, (float) x, (float) y, (float) z, rotation, color, 0f, 0f);
    }

    public void drawText(class_2561 text, double x, double y, double z, Quaternionf rotation, int color) {
        drawText(text.getString(), x, y, z, rotation, color);
    }

    public void drawText(class_2561 text, float x, float y, float z, Quaternionf rotation, int color, float offsetX, float offsetY) {
        drawText(text.getString(), x, y, z, rotation, color, offsetX, offsetY);
    }

    public void drawText(String text, double x, double y, double z, Quaternionf rotation, int color, float offsetX, float offsetY) {
        drawText(text, (float) x, (float) y, (float) z, rotation, color, offsetX, offsetY);
    }

    public void drawText(class_2561 text, double x, double y, double z, Quaternionf rotation, int color, float offsetX, float offsetY) {
        drawText(text.getString(), x, y, z, rotation, color, offsetX, offsetY);
    }

}