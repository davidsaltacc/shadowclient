package net.justacoder.shadowclient.main.setting.settings;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.mixin.KeyBindingAccessor;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class KeySetting extends Setting {

    private final class_304 keyBinding;

    public KeySetting(TranslatableString name, class_304 keyBinding) {
        super(name);
        this.keyBinding = keyBinding;
    }

    public int keyValue() {
        return ((KeyBindingAccessor) keyBinding).getBoundKey().method_1444();
    }

    public void setKeyValue(int key) {
        int old = this.keyValue();
        this.keyBinding.method_1422(class_3675.class_307.field_1668.method_1447(key));
        class_304.method_1426();
        ShadowClientMain.mc.field_1690.method_1640();
        callCallbacks(this.keyValue(), old);
    }

    @Override
    public void reset() {
        setKeyValue(keyBinding.method_1429().method_1444());
    }
}
