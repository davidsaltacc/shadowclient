package net.justacoder.shadowclient.main.setting.settings;

import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.mixin.KeyBindingAccessor;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class KeySetting extends Setting {

    private static int id = 0;

    private class_304 keyBinding;

    public KeySetting(String name, class_304 keyBinding) {
        super(name);
        this.keyBinding = keyBinding;
    }

    public KeySetting(String name, int defaultKey) {
        super(name);
        this.keyBinding = new class_304("key.shadowclient.keybind_setting." + id + "_" + name, defaultKey, "category.shadowclient.clientcategory");
        id += 1;
    }

    public int keyValue() {
        return ((KeyBindingAccessor) keyBinding).getBoundKey().method_1444();
    }

    public void setKeyValue(int key) {
        int old = this.keyValue();
        this.keyBinding.method_1422(class_3675.class_307.field_1668.method_1447(key));
        class_304.method_1426();
        callCallbacks(this.keyValue(), old);
    }

}
