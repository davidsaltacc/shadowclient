package net.justacoder.shadowclient.main.ui.clickgui.settings.modules;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.annotations.NotKeybindable;
import net.justacoder.shadowclient.main.config.ShadowClientSettings;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.render.UIRenderUtils;
import net.justacoder.shadowclient.main.setting.Setting;
import net.justacoder.shadowclient.main.setting.settings.BooleanSetting;
import net.justacoder.shadowclient.main.setting.settings.ButtonSetting;
import net.justacoder.shadowclient.main.setting.settings.KeySetting;
import net.justacoder.shadowclient.main.setting.settings.PaddingSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.ui.ShadowClientScreen;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;
import net.justacoder.shadowclient.main.ui.font.Font;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import org.joml.Vector2i;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public class SettingsScreen extends class_437 implements ShadowClientScreen {

    public final Module module;
    public final List<SettingComponent> components = new ArrayList<>();

    public static final int titleFontSize = 16;

    private int overlayWidth;
    private int overlayHeight;
    private int overlayStartX;
    private int overlayStartY;
    private int contentStartX;
    private int contentStartY;
    private int contentEndX;
    private int contentEndY;
    private int contentActualHeight;

    private int padding = 10;
    private int titleOffset = 9 + Font.getHeight(titleFontSize);

    private float scrollY = 0;
    private float scrollSpeed = 10;

    public SettingComponent.KeybindingSettingComponent toggleModuleKeybindComponent = null;
    public BooleanSetting enabledSetting;

    public SettingsScreen(Module module) {
        super(class_2561.method_30163(module.name.getTranslation()));
        this.module = module;

        enabledSetting = new BooleanSetting(new TranslatableString("name.shadowclient.enabled"), module.enabled);
        components.add(SettingComponent.ofSetting(enabledSetting, new Vector2i()));
        enabledSetting.addChangeCallback((newValue, ignored) -> {
            if ((boolean) newValue) { module.setEnabled(); }
            else { module.setDisabled(); }
        });

        if (!module.getClass().isAnnotationPresent(NotKeybindable.class)) {
            toggleModuleKeybindComponent = (SettingComponent.KeybindingSettingComponent) SettingComponent.ofSetting(new KeySetting(new TranslatableString("name.shadowclient.keybind"), module.keyBinding), new Vector2i());
            components.add(toggleModuleKeybindComponent);
        }

        components.add(SettingComponent.ofSetting(new ButtonSetting(new TranslatableString("name.shadowclient.reset_all_settings"), () -> module.getSettings().forEach(Setting::reset)), new Vector2i()));

        components.add(SettingComponent.ofSetting(new PaddingSetting(), new Vector2i()));

        for (Setting setting : module.getSettings()) {
            components.add(SettingComponent.ofSetting(setting, new Vector2i()));
        }
    }

    @Override
    protected void method_25426() {
        rescale();
        updateComponents();
        components.forEach(SettingComponent::init);
    }

    @Override
    public boolean capturesKeypress(int key) {
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            return true;
        }
        boolean intercept = false;
        for (SettingComponent component : components) {
            if (component.interceptKeypresses()) {
                intercept = true;
            }
        }
        return intercept;
    }

    private void updateComponents() {
        int offset = 0;
        for (SettingComponent component : components) {
            component.updatePosition(new Vector2i(contentStartX, contentStartY + titleOffset + offset));
            offset += component.getHeight();
        }
        contentActualHeight = offset;
    }

    public void rescale() {
        overlayWidth = (int) Math.min(1000, field_22789 * UIRenderUtils.guiScaleFactor() - 100);
        overlayHeight = (int) Math.min(700, field_22790 * UIRenderUtils.guiScaleFactor() - 100);
        overlayStartX = (int) (field_22789 * UIRenderUtils.guiScaleFactor() / 2 - (float) overlayWidth / 2);
        overlayStartY = (int) (field_22790 * UIRenderUtils.guiScaleFactor() / 2 - (float) overlayHeight / 2);
        contentStartX = overlayStartX + padding;
        contentStartY = overlayStartY + padding;
        contentEndX = overlayStartX + overlayWidth - padding;
        contentEndY = overlayStartY + overlayHeight - padding;
        scrollY = 0f;
    }

    @Override
    public void method_25410(class_310 client, int width, int height) {

        super.method_25410(client, width, height);

        rescale();
        updateComponents();

    }

    @Override
    public void method_25394(class_332 context, int scaledMouseX, int scaledMouseY, float delta) {

        this.method_57734();

        float disableScaleFactor = UIRenderUtils.guiScaleFactor(); // ClickGUI#L47
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor);

        UIRenderUtils.beforeUIRender(context);

        context.method_25294(overlayStartX, overlayStartY, overlayStartX + overlayWidth, overlayStartY + overlayHeight, Colors.MODULE_BUTTON_NORMAL.color);

        Font.renderString(context, module.name, contentStartX, contentStartY, Colors.TEXT_NORMAL.color, titleFontSize);
        context.method_25292(contentStartX, contentEndX, contentStartY + Font.getHeight(titleFontSize) + 4, Colors.HORIZONTAL_LINE.color);

        context.method_44379(contentStartX, contentStartY + titleOffset, contentEndX, contentEndY);
        context.method_51448().method_22903();
        context.method_51448().method_46416(0f, scrollY, 0f);
        components.forEach(component -> component.render(context, mouseX, mouseY, mouseX > contentStartX && mouseX < contentEndX && mouseY > contentStartY && mouseY < contentEndY, delta));
        context.method_51448().method_22909();
        context.method_44380();

        UIRenderUtils.afterUIRender(context);

    }

    @Override
    public boolean method_25401(double scaledMouseX, double scaledMouseY, double horizontalAmount, double verticalAmount) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor) - (int) scrollY;
        int mouseYScreen = mouseY + (int) scrollY;

        boolean canScroll = true;
        for (SettingComponent component : components) {
            if (!component.mayScrollContainer(mouseX, mouseY, mouseX > contentStartX && mouseX < contentEndX && mouseYScreen > contentStartY + titleOffset && mouseYScreen < contentEndY)) {
                canScroll = false;
            }
            component.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount, mouseX > contentStartX && mouseX < contentEndX && mouseYScreen > contentStartY + titleOffset && mouseYScreen < contentEndY);
        }

        if (canScroll && contentActualHeight > contentEndY - contentStartY && mouseX > contentStartX && mouseX < contentEndX && mouseYScreen > contentStartY + titleOffset && mouseYScreen < contentEndY) {
            scrollY = (float) Math.clamp(scrollY + Math.signum(verticalAmount) * class_3532.method_33723(verticalAmount) * scrollSpeed, Math.min(0f, -(contentActualHeight - (contentEndY - contentStartY - titleOffset))), 0f);
        }

        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            boolean configuring = false;
            for (SettingComponent component : components) {
                if (component instanceof SettingComponent.KeybindingSettingComponent settingComponent && settingComponent.isConfiguring()) {
                    configuring = true;
                }
            }
            if (!configuring) {
                field_22787.method_1507(ShadowClientMain.clickGui);
            }
        }

        components.forEach(component -> component.keyPressed(keyCode, scanCode, modifiers));

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25402(double scaledMouseX, double scaledMouseY, int button) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor) - (int) scrollY;
        int mouseYScreen = mouseY + (int) scrollY;

        components.forEach(component -> component.mouseClicked(mouseX, mouseY, button, mouseX > contentStartX && mouseX < contentEndX && mouseYScreen > contentStartY + titleOffset && mouseYScreen < contentEndY));

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double scaledMouseX, double scaledMouseY, int button) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor) - (int) scrollY;
        int mouseYScreen = mouseY + (int) scrollY;

        components.forEach(component -> component.mouseReleased(mouseX, mouseY, button, mouseX > contentStartX && mouseX < contentEndX && mouseYScreen > contentStartY + titleOffset && mouseYScreen < contentEndY));

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    protected void method_57734() {
        if (ShadowClientSettings.BlurBackground.booleanValue()) {
            super.method_57734();
        }
    }

}
