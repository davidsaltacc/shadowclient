package net.justacoder.shadowclient.main.ui.clickgui;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.module.ModuleManager;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.ui.clickgui.settings.clickgui.components.TextSetting;
import net.justacoder.shadowclient.main.ui.clickgui.text.TextField;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainClickGUI extends ClickGUI {

    public final class_310 mc = class_310.method_1551();

    public MainClickGUI() {
        super("ClickGUI");

        for (ModuleCategory category : ModuleCategory.values()) {
            if (category.hiddenFromMain) {
                continue;
            }
            frames.add(Frame.create(category, 0, 0, 200, 26));
        }

        searchFrame = Frame.createWithoutAddingModules(ModuleCategory.SEARCH, 0, 0, 200, 26);
        frames.add(searchFrame);
        searchFrame.children.add(new TextField(searchFrame, 24, "textfield.placeholder.find_module"));
    }

    public void repositionFramesProperly() {

        int width = mc.method_22683().method_20831().method_1614(mc.method_22683().method_4511()).method_1668(); // why is this so hard???? anyway it works now

        int columns = (int) Math.floor((float) (width / 2.) / 210);

        int[] columnsY = new int[columns];
        Arrays.fill(columnsY, 10);

        for (int index = 0; index < frames.size(); index++) {
            int xCol = index % columns;
            Frame frame = frames.get(index);
            if (columnsY[xCol] == 10) {
                frame.y = columnsY[xCol];
                columnsY[xCol] += frame.getHeight() + 10;
                frame.x = 10 + xCol * 210;
            } else {
                int minY = (int) 1e7;
                int minYIndex = -1;
                for (int ind = 0; ind < columns; ind++) {
                    int newY = columnsY[ind] + frame.getHeight();
                    if (newY < minY) {
                        minY = newY;
                        minYIndex = ind;
                    }
                }
                frame.y = columnsY[minYIndex];
                columnsY[minYIndex] += frame.getHeight() + 10;
                frame.x = 10 + minYIndex * 210;
            }
        }
    }

    @Override
    public boolean method_25422() {
        if (ModuleManager.isConfiguringKeyBinds()) {
            return false;
        }
        return super.method_25422();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {

        if (ModuleManager.isConfiguringKeyBinds()) {
            if (ShadowClientMain.ToggleGUIKeyBinding.method_1417(keyCode, scanCode)) {
                ModuleManager.endKeybindConfiguration();
                ModuleManager.ConfigureKeybindingsModule.setDisabled();
                ShadowClientMain.mc.method_1507(null);
                return true;
            }
            if (ModuleManager.getConfiguringKeyBinding() != null) {
                int code = keyCode == GLFW.GLFW_KEY_ESCAPE ? GLFW.GLFW_KEY_UNKNOWN : keyCode;
                ModuleManager.getConfiguringKeyBinding().method_1422(class_3675.class_307.field_1668.method_1447(code));
                ModuleManager.getConfiguringKeyBindingModule().reloadKeybindTranslation();
                class_304.method_1426();
                ModuleManager.setConfiguringKeyBinding(null, null);
            }
            return super.method_25404(keyCode, scanCode, modifiers);
        }

        for (Frame frame : frames) {
            frame.keyPressed(keyCode, scanCode, modifiers);
        }

        searching = !((TextField) searchFrame.children.get(0)).getText().isEmpty();

        if (searching) {
            searchingFor = ((TextField) searchFrame.children.get(0)).getText();
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public List<FrameChild> getAllTextFields() {
        List<FrameChild> textFields = new ArrayList<>();
        for (Frame frame : frames) {
            textFields.addAll(frame.getAllTextFields());
        }
        return textFields;
    }

    public boolean isAnyTextFieldCapturing() {
        List<FrameChild> allTextFields = getAllTextFields();
        for (FrameChild textField : allTextFields) {
            if (textField.getClass() == TextField.class) {
                if (((TextField) textField).captureKeyPresses) {
                    return true;
                }
            }
            if (textField.getClass() == TextSetting.class) {
                if (((TextSetting) textField).captureKeyPresses) {
                    return true;
                }
            }
        }
        return false;
    }
}
