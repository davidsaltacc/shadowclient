package net.justacoder.shadowclient.main.ui.clickgui.text;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.ui.font.Font;
import net.justacoder.shadowclient.mixin.KeyBindingAccessor;
import net.minecraft.class_332;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;
import net.justacoder.shadowclient.main.ui.clickgui.Frame;
import net.justacoder.shadowclient.main.ui.clickgui.FrameChild;
import org.lwjgl.glfw.GLFW;

public class FrameTextField extends FrameChild {

    private final Frame frameParent;
    private String text;
    private final TranslatableString placeholder;

    public int offset;
    public boolean captureKeyPresses;

    public FrameTextField(Frame parent, int offset, TranslatableString placeholder) {
        this.frameParent = parent;
        this.offset = offset;
        this.text = "";
        this.placeholder = placeholder;
        captureKeyPresses = false;
    }

    public Frame getParentFrame() {
        return frameParent;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX > getParentFrame().x && mouseX < getParentFrame().x + getParentFrame().width && mouseY > getParentFrame().y + offset && mouseY < getParentFrame().y + offset + getParentFrame().height;
    }

    public void render(class_332 context, int mouseX, int mouseY, float delta) {
        if (isHovered(mouseX, mouseY)) {
            context.method_25294(getParentFrame().x, getParentFrame().y + offset, getParentFrame().x + getParentFrame().width, getParentFrame().y + offset + getParentFrame().height, Colors.MODULE_BUTTON_HOVERED.color);
        } else {
            context.method_25294(getParentFrame().x, getParentFrame().y + offset, getParentFrame().x + getParentFrame().width, getParentFrame().y + offset + getParentFrame().height, Colors.MODULE_BUTTON_NORMAL.color);
        }
        int textOffset = (int) ((float) getParentFrame().height / 2 - (float) Font.getHeight() / 2);
        Font.renderString(context, text.isEmpty() ? placeholder.getTranslation() : text.toLowerCase(), getParentFrame().x + textOffset, getParentFrame().y + offset + textOffset, text.isEmpty() ? Colors.TEXT_DISABLED.color : Colors.TEXT_NORMAL.color);
    }

    @Override
    public void mouseClicked(double mouseX, double mouseY, int button) {
        captureKeyPresses = isHovered(mouseX, mouseY);
    }

    @Override
    public void keyPressed(int keyCode, int scanCode, int modifiers) {
        if (captureKeyPresses) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                if (!text.isEmpty()) {
                    text = text.substring(0, text.length() - 1);
                }
                return;
            }
            if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == ((KeyBindingAccessor) ShadowClientMain.toggleGUIKeyBinding).getBoundKey().method_1444() || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                captureKeyPresses = false;
                return;
            }
            text += (char) keyCode;
        }
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


    @Override
    public int getHeight() {
        return getParentFrame().height;
    }

}
