package net.justacoder.shadowclient.main.ui.clickgui;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.config.ShadowClientSettings;
import net.justacoder.shadowclient.main.render.UIRenderUtils;
import net.justacoder.shadowclient.main.ui.ShadowClientScreen;
import net.justacoder.shadowclient.main.ui.clickgui.text.FrameTextField;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends class_437 implements ShadowClientScreen {

    public final List<Frame> frames;

    public Frame searchFrame;
    public boolean searching;
    public String searchingFor;

    public ClickGUI(String title) {
        super(class_2561.method_30163(title));

        frames = new ArrayList<>();
        searching = false;
        searchingFor = "";
        searchFrame = null;

    }

    @Override
    protected void method_57734() {
        if (ShadowClientSettings.BlurBackground.booleanValue()) {
            super.method_57734();
        }
    }

    @Override
    public void method_25394(class_332 context, int scaledMouseX, int scaledMouseY, float delta) {

        this.method_57734();

        float disableScaleFactor = UIRenderUtils.guiScaleFactor(); // technically we disable, but we use enable() because we need to multiply the coordinates instead of downscaling
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor);

        UIRenderUtils.beforeUIRender(context);

        for (Frame frame : frames) {
            frame.render(context, mouseX, mouseY, delta);
            frame.updatePosition(mouseX, mouseY);
        }
        for (Frame frame : frames) {
            frame.renderDescriptions(context, mouseX, mouseY, delta);
        }

        UIRenderUtils.afterUIRender(context);

    }

    @Override
    public boolean method_25402(double scaledMouseX, double scaledMouseY, int button) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor(); // see render() for reason of using enable...()
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor);

        for (Frame frame : frames) {
            frame.mouseClicked(mouseX, mouseY, button);
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double scaledMouseX, double scaledMouseY, int button) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor);

        for (Frame frame : frames) {
            frame.mouseReleased(mouseX, mouseY, button);
        }

        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return this instanceof MainClickGUI;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            if (!(this instanceof MainClickGUI)) {
                field_22787.method_1507(ShadowClientMain.clickGui);
            }
        }

        for (Frame frame : frames) {
            frame.keyPressed(keyCode, scanCode, modifiers);
        }

        searching = !((FrameTextField) searchFrame.children.getFirst()).getText().isEmpty();

        if (searching) {
            searchingFor = ((FrameTextField) searchFrame.children.getFirst()).getText();
        }

        return super.method_25404(keyCode, scanCode, modifiers);
    }

    public List<FrameChild> getAllModuleTextFields() {
        List<FrameChild> textFields = new ArrayList<>();
        for (Frame frame : frames) {
            textFields.addAll(frame.getAllTextFields());
        }
        return textFields;
    }

    public boolean isAnyTextFieldCapturing() {
        List<FrameChild> allTextFields = getAllModuleTextFields();
        for (FrameChild textField : allTextFields) {
            if (textField.getClass() == FrameTextField.class) {
                if (((FrameTextField) textField).captureKeyPresses) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean capturesKeypress(int key) {
        return key == GLFW.GLFW_KEY_ESCAPE || isAnyTextFieldCapturing();
    }
}
