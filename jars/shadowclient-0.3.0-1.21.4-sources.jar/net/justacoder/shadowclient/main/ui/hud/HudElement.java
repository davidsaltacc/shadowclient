package net.justacoder.shadowclient.main.ui.hud;

import net.justacoder.shadowclient.main.ui.font.Font;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.ui.clickgui.Colors;

public class HudElement {
    public boolean shouldBeRendered;
    private String textContent;
    private final class_310 mc = ShadowClientMain.mc;

    public HudElement(boolean rendered, String text) {
        this.shouldBeRendered = rendered;
        this.textContent = text;
    }

    public void shouldBeRendered(boolean rendered) {
        this.shouldBeRendered = rendered;
    }

    public void setTextContent(String text) {
        this.textContent = text;
    }

    public void render(class_332 context, float tickDelta, int offset) {
        context.method_25294(0, offset, Font.getWidth(this.textContent) + 6, offset + Font.getHeight() + 6, Colors.HUD_ELEMENT_BACKGROUND.color);
        Font.renderString(context, this.textContent, 3, offset + 3, Colors.HUD_ELEMENT_TEXT.color);
    }

    public void render(class_332 context, float tickDelta, int offset, boolean rightSide) {
        if (!rightSide) {
            render(context, tickDelta, offset);
            return;
        }
        int width = context.method_51421();
        context.method_25294(width - 6 - mc.field_1772.method_1727(this.textContent), 4 + offset, width - 4, 4 + offset + Font.getHeight(), Colors.HUD_ELEMENT_BACKGROUND.color);
        Font.renderString(context, this.textContent, width - mc.field_1772.method_1727(this.textContent) - 4, 6 + offset, Colors.HUD_ELEMENT_TEXT.color);
    }

    public int getHeight() {
        return Font.getHeight() + 6;
    }
}
