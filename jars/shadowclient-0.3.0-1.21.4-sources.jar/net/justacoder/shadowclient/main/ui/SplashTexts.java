package net.justacoder.shadowclient.main.ui;

import java.util.List;
import net.minecraft.class_5819;

public abstract class SplashTexts {

    private static final class_5819 random = class_5819.method_43047();

    public static final List<String> TEXTS = List.of(
            "better than §5meteor§r...",
            "star shadowclient on github",
            "wurst worst client",
            "shadowclient best client",
            "justacoder the §4§lGOAT§r",
            "good utility client",
            "join the §1community§r!",
            "funny splash text here",
            "§lTechnoblade never dies!§r",
            "No hacks, just utility!",
            "No utility, just hacks!",
            "One does not simply §lfind§r diamonds.",
            "§l§cAlt+F4§r for a surprise!",
            "One block at a time!",
            "Unleash your inner Enderman!",
            "It's not X-ray, it's §ostrategy§r!",
            "You can't sleep here, monsters nearby!",
            "The cake is a lie!"
    );

    public static String getRandom() {
        return TEXTS.get(random.method_39332(0, TEXTS.size() - 1));
    }

}
