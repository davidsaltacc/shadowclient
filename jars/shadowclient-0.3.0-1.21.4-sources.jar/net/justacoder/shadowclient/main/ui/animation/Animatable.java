package net.justacoder.shadowclient.main.ui.animation;

import net.minecraft.class_310;

public interface Animatable {

    default void startAnimation() {
        setAnimProgress(animProgressesUp() ? 0 : 1);
    }

    default void progressAnimation() {
        if (getAnimProgress() != (animProgressesUp() ? 1 : 0)) {
            setAnimProgress(Math.clamp(getAnimProgress() + (animProgressesUp() ? 1 : -1) * (class_310.method_1551().method_61966().method_60638() / 10) / getAnimDuration(), 0, 1)); // WHY /10
        }
    }

    void setAnimProgress(double progress);
    double getAnimProgress();
    double getAnimDuration();
    boolean animProgressesUp();
    void setAnimProgressesUp(boolean up);

}
