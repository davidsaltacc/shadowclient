package net.justacoder.shadowclient.main.ui.settings;

import net.justacoder.shadowclient.main.ShadowClientMain;
import net.justacoder.shadowclient.main.config.ShadowClientSettings;
import net.justacoder.shadowclient.main.render.UIRenderUtils;
import net.justacoder.shadowclient.main.setting.settings.ColorSetting;
import net.justacoder.shadowclient.main.translations.TranslatableString;
import net.justacoder.shadowclient.main.ui.ShadowClientScreen;
import net.justacoder.shadowclient.main.ui.Colors;
import net.justacoder.shadowclient.main.ui.animation.Animatable;
import net.justacoder.shadowclient.main.ui.font.Font;
import net.justacoder.shadowclient.main.ui.text.TextField;
import net.justacoder.shadowclient.main.util.ColorUtils;
import net.justacoder.shadowclient.main.util.MathUtils;
import net.justacoder.shadowclient.mixin.DrawContextAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.lwjgl.glfw.GLFW;
import java.awt.Color;

public class ColorSelectionScreen extends class_437 implements ShadowClientScreen, Animatable {

    private ColorSetting setting;
    private class_437 parent;

    public ColorSelectionScreen(ColorSetting setting, class_437 parent) {
        super(class_2561.method_30163("Color Selection"));

        this.setting = setting;
        this.parent = parent;

        int[] colors = ColorUtils.int2RGBA(setting.colorValue());
        float[] hsv = Color.RGBtoHSB(colors[0], colors[1], colors[2], null);
        colorH = hsv[0];
        colorS = hsv[1];
        colorV = hsv[2];
    }

    @Override
    protected void method_57734() {
        if (ShadowClientSettings.BlurBackground.booleanValue()) {
            super.method_57734();
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25422() {
        return false;
    }

    private int contentStartX;
    private int contentStartY;
    private int contentEndX;
    private int contentEndY;
    private int padding;
    private int contentWidth;
    private int contentHeight;

    private float colorH;
    private float colorS;
    private float colorV;

    private int hueY = -1;
    private int saturationY = -1;
    private int brightnessY = -1;
    private int okayY = -1;

    private boolean slidingHue = false;
    private boolean slidingSaturation = false;
    private boolean slidingBrightness = false;

    private static final TranslatableString hueName = TranslatableString.of("name.shadowclient.color_selection.hue");
    private static final TranslatableString saturationName = TranslatableString.of("name.shadowclient.color_selection.saturation");
    private static final TranslatableString brightnessName = TranslatableString.of("name.shadowclient.color_selection.brightness");
    private static final TranslatableString colorName = TranslatableString.of("name.shadowclient.color_selection.color");
    private static final TranslatableString colorHexName = TranslatableString.of("name.shadowclient.color_selection.color_hex");
    private static final TranslatableString okayText = TranslatableString.of("name.shadowclient.color_selection.okay");

    private TextField colorField;

    private static final class_2960 HUE_GRADIENT = class_2960.method_60655("shadowclient", "textures/gui/hue_gradient.png");

    public double animProgress = 0;
    public double animDuration = 0.4;

    private void rescale() {
        contentWidth = 300;
        contentHeight = 235;
        padding = 5;
        contentStartX = (int) (field_22789 * UIRenderUtils.guiScaleFactor() / 2f - contentWidth / 2f);
        contentStartY = (int) (field_22790 * UIRenderUtils.guiScaleFactor() / 2f - contentHeight / 2f);
        contentEndX = (int) (field_22789 * UIRenderUtils.guiScaleFactor() / 2f + contentWidth / 2f);
        contentEndY = (int) (field_22790 * UIRenderUtils.guiScaleFactor() / 2f + contentHeight / 2f);
    }

    @Override
    public void method_49589() {
        startAnimation();
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        rescale();
        colorField = new TextField(this, String.format("#%06X", 0xFFFFFF & setting.colorValue()), colorHexName, new Vector2f(0, 0), new Vector2f(contentWidth, Font.getHeight() + 4), color -> {
            try {
                if (color.length() != 4 && color.length() != 7) {
                    throw new RuntimeException("");
                }
                if (color.length() == 4) {
                    color = "" + color.charAt(0) + color.charAt(1) + color.charAt(1) + color.charAt(2) + color.charAt(2) + color.charAt(3) + color.charAt(3);
                }
                Color decoded = Color.decode(color);
                float[] hsv = Color.RGBtoHSB(decoded.getRed(), decoded.getBlue(), decoded.getGreen(), null);
                colorH = hsv[0];
                colorS = hsv[1];
                colorV = hsv[2];
                setting.setColorValue(decoded.getRGB(), false);
            } catch (Exception ignored) {
                colorH = colorS = colorV = 0;
                setting.setColorValue(-16777216, false);
            }
        });
    }

    @Override
    public void method_25410(class_310 client, int width, int height) {
        super.method_25410(client, width, height);
        rescale();
    }

    private void fillGradientHorizontal(class_332 context, float startX, float startY, float endX, float endY, int colorStart, int colorEnd) {
        Matrix4f matrix4f = context.method_51448().method_23760().method_23761();
        class_4588 vertexConsumer = ((DrawContextAccessor) context).getVertexConsumers().getBuffer(class_1921.method_51784());
        vertexConsumer.method_22918(matrix4f, startX, startY, 0f).method_39415(colorStart);
        vertexConsumer.method_22918(matrix4f, startX, endY, 0f).method_39415(colorStart);
        vertexConsumer.method_22918(matrix4f, endX, endY, 0f).method_39415(colorEnd);
        vertexConsumer.method_22918(matrix4f, endX, startY, 0f).method_39415(colorEnd);
    }

    @Override
    public void method_25394(class_332 context, int scaledMouseX, int scaledMouseY, float delta) {

        this.method_57734();

        UIRenderUtils.beforeUIRender(context);

        context.method_51448().method_22903();
        if (animProgress < 1) {
            context.method_51448().method_22904(0, (1 - MathUtils.Easing.EASE_OUT_QUADRATIC.eased(animProgress)) * 35, 0);
        }

        context.method_25294(contentStartX - padding, contentStartY - padding, contentEndX + padding, contentEndY + padding, Colors.MODULE_BUTTON_NORMAL.color);

        int offset = 0;

        offset += 2;
        Font.renderString(context, hueName, contentStartX, contentStartY + offset, Colors.TEXT_NORMAL.color);
        offset += 2 + Font.getHeight();

        hueY = contentStartY + offset;
        context.method_25302(class_1921::method_62277, HUE_GRADIENT, contentStartX, contentStartY + offset, 0, 0, contentEndX - contentStartX, 20, 800, 1, 800, 1);
        context.method_49601((int) (contentStartX + colorH * (contentEndX - contentStartX)) - 2, contentStartY + offset, 4, 20, Colors.MODULE_BUTTON_NORMAL.color);
        offset += 20;

        offset += 2;
        Font.renderString(context, saturationName, contentStartX, contentStartY + offset, Colors.TEXT_NORMAL.color);
        offset += 2 + Font.getHeight();

        saturationY = contentStartY + offset;
        fillGradientHorizontal(context, contentStartX, contentStartY + offset, contentEndX, contentStartY + offset + 20f, Color.HSBtoRGB(colorH, 0, colorV), Color.HSBtoRGB(colorH, 1, colorV));
        context.method_49601((int) (contentStartX + colorS * (contentEndX - contentStartX)) - 2, contentStartY + offset, 4, 20, Colors.MODULE_BUTTON_NORMAL.color);
        offset += 20;

        offset += 2;
        Font.renderString(context, brightnessName, contentStartX, contentStartY + offset, Colors.TEXT_NORMAL.color);
        offset += 2 + Font.getHeight();

        brightnessY = contentStartY + offset;
        fillGradientHorizontal(context, contentStartX, contentStartY + offset, contentEndX, contentStartY + offset + 20f, Color.HSBtoRGB(colorH, colorS, 0), Color.HSBtoRGB(colorH, colorS, 1));
        context.method_49601((int) (contentStartX + colorV * (contentEndX - contentStartX)) - 2, contentStartY + offset, 4, 20, Colors.MODULE_BUTTON_NORMAL.color);
        offset += 20;

        offset += 2;
        Font.renderString(context, colorName, contentStartX, contentStartY + offset, Colors.TEXT_NORMAL.color);
        offset += 2 + Font.getHeight();

        context.method_25294(contentStartX, contentStartY + offset, contentEndX, contentStartY + offset + 40, setting.colorValue());
        offset += 40;

        offset += 2;
        colorField.setPosition(new Vector2f(contentStartX, contentStartY + offset));
        colorField.render(context);
        offset += 2;

        offset += 40;
        okayY = contentStartY + offset;
        context.method_25294(contentStartX, contentStartY + offset, contentEndX, contentStartY + offset + Font.getHeight() + 4, Colors.MODULE_BUTTON_NORMAL.color);
        String text = okayText.getTranslation();
        Font.renderString(context, text, contentStartX + (contentEndX - contentStartX) / 2f - Font.getWidth(text) / 2f, contentStartY + offset + 2, Colors.TEXT_NORMAL.color);
        offset += Font.getHeight() + 4;

        UIRenderUtils.afterUIRender(context);

        context.method_51448().method_22909();

        progressAnimation();

    }

    @Override
    public boolean method_25402(double scaledMouseX, double scaledMouseY, int button) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);
        int mouseY = (int) (scaledMouseY * disableScaleFactor);

        if (mouseX > contentStartX && mouseX < contentEndX && mouseY > contentStartY && mouseY < contentEndY) {
            if (mouseY > hueY && mouseY < hueY + 20) {
                slidingHue = true;
            } else if (mouseY > saturationY && mouseY < saturationY + 20) {
                slidingSaturation = true;
            } else if (mouseY > brightnessY && mouseY < brightnessY + 20) {
                slidingBrightness = true;
            } else if (mouseY > okayY && mouseY < okayY + Font.getHeight() + 4) {
                setting.setColorValue(Color.HSBtoRGB(colorH, colorS, colorV), true);
                ShadowClientMain.mc.method_1507(parent);
                return super.method_25402(scaledMouseX, scaledMouseY, button);
            }
            this.method_16014(scaledMouseX, scaledMouseY);
        } else {
            slidingHue = slidingSaturation = slidingBrightness = false;
        }

        colorField.mouseClicked(scaledMouseX, scaledMouseY, button);

        return super.method_25402(scaledMouseX, scaledMouseY, button);

    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {

        slidingHue = slidingSaturation = slidingBrightness = false;

        return super.method_25406(mouseX, mouseY, button);

    }

    @Override
    public void method_16014(double scaledMouseX, double scaledMouseY) {

        float disableScaleFactor = UIRenderUtils.guiScaleFactor();
        int mouseX = (int) (scaledMouseX * disableScaleFactor);

        float normalizedValue = Math.clamp((float) (mouseX - contentStartX) / (contentEndX - contentStartX), 0f, 1f);

        if (slidingHue) {
            colorH = normalizedValue;
        } else if (slidingSaturation) {
            colorS = normalizedValue;
        } else if (slidingBrightness) {
            colorV = normalizedValue;
        }

        if (slidingHue || slidingSaturation || slidingBrightness) {
            setting.setColorValue(Color.HSBtoRGB(colorH, colorS, colorV), false);
            colorField.setText(String.format("#%06X", 0xFFFFFF & setting.colorValue()));
        }

        super.method_16014(scaledMouseX, scaledMouseY);

    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            ShadowClientMain.mc.method_1507(parent);
        }

        colorField.keyPressed(keyCode, scanCode, modifiers);

        return super.method_25404(keyCode, scanCode, modifiers);

    }

    @Override
    public boolean method_25400(char chr, int modifiers) {

        colorField.charTyped(chr, modifiers);

        return super.method_25400(chr, modifiers);
    }

    @Override
    public boolean capturesKeypress(int key) {
        return colorField.capturesKeypress(key) || key == GLFW.GLFW_KEY_ESCAPE;
    }

    @Override
    public void setAnimProgress(double progress) {
        animProgress = progress;
    }

    @Override
    public double getAnimProgress() {
        return animProgress;
    }

    @Override
    public double getAnimDuration() {
        return animDuration;
    }

    @Override
    public boolean animProgressesUp() {
        return true;
    }

    @Override
    public void setAnimProgressesUp(boolean up) {}

}
