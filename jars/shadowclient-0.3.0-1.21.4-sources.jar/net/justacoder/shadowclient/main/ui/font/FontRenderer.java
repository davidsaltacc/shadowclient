package net.justacoder.shadowclient.main.ui.font;

import net.justacoder.shadowclient.mixin.DrawContextAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_332;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class FontRenderer {

    private final Map<Integer, FontTextureAtlas> atlases = new HashMap<>();
    private final Font baseFont;

    public FontRenderer(Font baseFont) {
        this.baseFont = baseFont;
    }

    public void drawText(class_332 context, String text, float x, float y, int fontSize, int color, int guiScale) {
        FontTextureAtlas atlas = getAtlasForSize(fontSize * guiScale);
        FontTextureAtlas.Glyph glyph;
        context.method_51448().method_22903();
        Matrix4f matrix = context.method_51448().method_23760().method_23761();
        class_4588 vertexConsumer = ((DrawContextAccessor) context).getVertexConsumers().getBuffer(
                class_1921.method_23028(atlas.getTextureId())
        );
        matrix.scale(1f / guiScale, 1f / guiScale, 1f);

        x *= guiScale;
        y *= guiScale;

        float r = (color >> 16 & 255) / 255f;
        float g = (color >> 8 & 255) / 255f;
        float b = (color & 255) / 255f;
        float a = (color >> 24 & 255) / 255f;

        float cursorX = x;
        for (char c : text.toCharArray()) {
            glyph = atlas.getGlyph(c); // so we basically just fill the font atlas over time and hope it never runs out of space. great.

            vertexConsumer.method_22918(matrix, cursorX, y, 0).method_22915(r, g, b, a).method_22913(glyph.u0, glyph.v0).method_60803(15728880); // minecraft uses this value. I don't know its purpose. Apparently it's the maximum value.
            vertexConsumer.method_22918(matrix, cursorX, y + glyph.height, 0).method_22915(r, g, b, a).method_22913(glyph.u0, glyph.v1).method_60803(15728880);
            vertexConsumer.method_22918(matrix, cursorX + glyph.width, y + glyph.height, 0).method_22915(r, g, b, a).method_22913(glyph.u1, glyph.v1).method_60803(15728880);
            vertexConsumer.method_22918(matrix, cursorX + glyph.width, y, 0).method_22915(r, g, b, a).method_22913(glyph.u1, glyph.v0).method_60803(15728880);

            cursorX += glyph.width;
        }

        context.method_51448().method_22909();
    }

    public FontTextureAtlas getAtlasForSize(int size) {
        return atlases.computeIfAbsent(size, s ->
                new FontTextureAtlas(baseFont.deriveFont((float) s))
        );
    }

}
