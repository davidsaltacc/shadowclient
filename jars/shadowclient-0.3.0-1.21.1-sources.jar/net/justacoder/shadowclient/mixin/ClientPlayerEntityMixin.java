package net.justacoder.shadowclient.mixin;

import com.mojang.authlib.GameProfile;
import net.justacoder.shadowclient.main.SCMain;
import net.justacoder.shadowclient.main.module.modules.player.Reach;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1294;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.justacoder.shadowclient.main.event.EventManager;
import net.justacoder.shadowclient.main.event.events.DamageEvent;
import net.justacoder.shadowclient.main.event.events.KnockbackEvent;
import net.justacoder.shadowclient.main.module.ModuleManager;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin extends class_742 {
    public ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Shadow
    @Final
    protected class_310 client;

    @Unique public class_437 crntScreen;
    @Unique public boolean hideItem;

    @Override
    public void method_5750(double x, double y, double z) {
        KnockbackEvent event = new KnockbackEvent(x, y, z);
        EventManager.fireEvent(event);
        super.method_5750(event.x, event.y, event.z);
    }

    @Override
    public boolean method_6059(class_6880<class_1291> effect) {

        if (effect == class_1294.field_5925 && (ModuleManager.NightVisionModule.enabled || ModuleManager.XrayModule.enabled)) {
            return true;
        }

        if (effect == class_1294.field_5902 && ModuleManager.NoLevitationModule.enabled) {
            return false;
        }

        if (effect == class_1294.field_5919 && ModuleManager.NoBlindModule.enabled) {
            return false;
        }

        if (effect == class_1294.field_38092 && ModuleManager.NoBlindModule.enabled) {
            return false;
        }

        return super.method_6059(effect);
    }

    @Inject(at = @At(value = "FIELD", target = "Lnet/minecraft/client/MinecraftClient;currentScreen:Lnet/minecraft/client/gui/screen/Screen;", opcode = Opcodes.GETFIELD, ordinal = 0), method = "tickNausea")
    private void beforeUpdateNausea(CallbackInfo ci) {
        if (!ModuleManager.PortalGUIModule.enabled) {
            return;
        }

        crntScreen = client.field_1755;
        client.field_1755 = null;
    }

    @Inject(at = @At(value = "FIELD", target = "Lnet/minecraft/client/network/ClientPlayerEntity;nauseaIntensity:F", opcode = Opcodes.GETFIELD, ordinal = 1), method = "tickNausea")
    private void afterUpdateNausea(CallbackInfo ci) {
        if (crntScreen == null) {
            return;
        }

        client.field_1755 = crntScreen;
        crntScreen = null;
    }

    @Override
    protected float method_6106() {
        return ModuleManager.HighJumpModule.increase(super.method_6106());
    }

    @Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z", ordinal = 0), method = "tickMovement")
    private void onTickMovementItemUse(CallbackInfo ci) {
        if (ModuleManager.NoSlowdownModule.enabled) {
            hideItem = true;
        }
    }

    @Inject(at = @At("HEAD"), method = "isUsingItem", cancellable = true)
    private void onIsUsingItem(CallbackInfoReturnable<Boolean> cir) {
        if (!hideItem) {
            return;
        }

        cir.setReturnValue(false);
        hideItem = false;
    }

    @Inject(at = @At(value = "FIELD", target = "Lnet/minecraft/client/network/ClientPlayerEntity;ticksToNextAutojump:I", opcode = Opcodes.GETFIELD, ordinal = 0), method = "tickMovement")
    private void afterIsUsingItem(CallbackInfo ci) {
        hideItem = false;
    }

    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(class_1282 source, float amount, CallbackInfoReturnable<Boolean> info) {
        if (method_37908().field_9236 && method_33190()) {
            DamageEvent evt = new DamageEvent(source, amount);
            EventManager.fireEvent(evt);
        }
    }


    @Override
    public double method_55754() {
        if (ModuleManager.ReachModule.enabled) {
            return ModuleManager.ReachModule.distance();
        }
        return super.method_55754();
    }

    @Override
    public double method_55755() {
        if (ModuleManager.ReachModule.enabled) {
            return ModuleManager.ReachModule.distance();
        }
        return super.method_55755();
    }

}
