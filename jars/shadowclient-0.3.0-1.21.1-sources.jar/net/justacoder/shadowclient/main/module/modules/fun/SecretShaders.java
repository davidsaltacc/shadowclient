package net.justacoder.shadowclient.main.module.modules.fun;

import net.justacoder.shadowclient.main.event.events.PerspectiveChangeEvent;
import net.justacoder.shadowclient.main.annotations.EventListener;
import net.justacoder.shadowclient.main.annotations.SearchTags;
import net.justacoder.shadowclient.main.event.Event;
import net.justacoder.shadowclient.main.event.events.PreTickEvent;
import net.justacoder.shadowclient.main.module.Module;
import net.justacoder.shadowclient.main.module.ModuleCategory;
import net.justacoder.shadowclient.main.setting.settings.EnumSetting;
import net.justacoder.shadowclient.main.util.RenderUtils;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

@EventListener({PreTickEvent.class, PerspectiveChangeEvent.class})
@SearchTags({"shaders", "effects", "vfx", "special effects", "super secret settings"})
public class SecretShaders extends Module {

    private class_437 currentScreen;

    public final EnumSetting<Shaders> SHADER = new EnumSetting<>("ID", Shaders.NONE);

    public SecretShaders() {
        super("secretshaders", ModuleCategory.FUN);

        SHADER.addChangeCallback((shader, old) -> updateShader());

        addSetting(SHADER);
    }

    @Override
    public void onEnable() {
        currentScreen = mc.field_1755;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mc.field_1773 != null) {
            RenderUtils.loadShader(null);
        }
        super.onDisable();
    }

    private void updateShader() {
        if (enabled) {
            RenderUtils.loadShader(SHADER.getEnumValue().getId());
        }
    }

    @Override
    public void onEvent(Event event) {
        if (event instanceof PreTickEvent) {
            if (currentScreen != mc.field_1755) {
                currentScreen = mc.field_1755;
                updateShader();
            }
        } else if (event instanceof PerspectiveChangeEvent) {
            updateShader();
        }
    }

    public enum Shaders { // they got removed in 1.21, so I added them back manually
        NONE("NONE", null),
        NOTCH("Notch", class_2960.method_60656("shaders/post/notch.json")),
        FXAA("FXAA", class_2960.method_60656("shaders/post/fxaa.json")),
        ART("Art", class_2960.method_60656("shaders/post/art.json")),
        BUMPY("Bumpy", class_2960.method_60656("shaders/post/bumpy.json")),
        BLOBS2("Blobs 2", class_2960.method_60656("shaders/post/blobs2.json")),
        PENCIL("Pencil", class_2960.method_60656("shaders/post/pencil.json")),
        COLOR_CONVOLVE("ColorConvolve", class_2960.method_60656("shaders/post/color_convolve.json")),
        DECONVERGE("Deconverge", class_2960.method_60656("shaders/post/deconverge.json")),
        FLIP("Flip", class_2960.method_60656("shaders/post/flip.json")),
        INVERT("Invert", class_2960.method_60656("shaders/post/invert.json")),
        NTSC("NTSC", class_2960.method_60656("shaders/post/ntsc.json")),
        OUTLINE("Outline", class_2960.method_60656("shaders/post/outline.json")),
        PHOSPHOR("Phosphor", class_2960.method_60656("shaders/post/phosphor.json")),
        SCAN_PINCUSHION("Scan Pincushion", class_2960.method_60656("shaders/post/scan_pincushion.json")),
        SOBEL("Sobel", class_2960.method_60656("shaders/post/sobel.json")),
        BITS("Bits", class_2960.method_60656("shaders/post/bits.json")),
        DESATURATE("Desaturate", class_2960.method_60656("shaders/post/desaturate.json")),
        GREEN("Green", class_2960.method_60656("shaders/post/green.json")),
        BLUR("Blur", class_2960.method_60656("shaders/post/blur.json")),
        WOBBLE("Wobble", class_2960.method_60656("shaders/post/wobble.json")),
        BLOBS("Blobs", class_2960.method_60656("shaders/post/blobs.json")),
        ANTIALIAS("AntiAlias", class_2960.method_60656("shaders/post/antialias.json")),
        CREEPER("Creeper", class_2960.method_60656("shaders/post/creeper.json")),
        SPIDER("Spider", class_2960.method_60656("shaders/post/spider.json"));

        final String name;
        final @Nullable class_2960 id;

        Shaders(String name, @Nullable class_2960 id) {
            this.name = name;
            this.id = id;
        }

        @Override
        public String toString() {
            return this.name;
        }
        public @Nullable class_2960 getId() {
            return this.id;
        }
    }
}
