package net.justacoder.shadowclient.main.util;

import net.justacoder.shadowclient.main.SCMain;
import net.minecraft.class_2828;

public abstract class BypassUtils {

    public static void sendFiveMovementPackets() {
        for (int i = 0; i < 5; i++) {
            SCMain.mc.method_1562().method_52787(new class_2828.class_2829(SCMain.mc.field_1724.method_23317(), SCMain.mc.field_1724.method_23318(), SCMain.mc.field_1724.method_23321(), true));
        }
    }

}
